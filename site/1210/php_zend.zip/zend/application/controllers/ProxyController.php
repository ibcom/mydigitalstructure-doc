<?php

class ProxyController extends Zend_Controller_Action
{
    public function init() {
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
    }
    
    private function getTime()
    {
        $a = explode (' ',microtime()); 
        return(double) $a[0] + $a[1];
    }
    
    public function indexAction()
    {        
        //if ($this->_request->isXmlHttpRequest()) {            
            $clean = array('target', 'ff_one_id', 'data'); //, 'sid');
            
            $target = $this->_request->getParam('target', null);            
            $ff_one_id = $this->_request->getParam('ff_one_id', 0);
            $sid = $this->_request->getParam('sid', 0);
            
            // Format
            $format = $this->_request->getParam('format', 'json');
            $beta = (bool) $this->_request->getParam('beta', false);

            $client = new Zend_Http_Client();
            
            $paramsPOST = $this->_request->getPost();
            $paramsGET = $this->_request->getParams();
            
            $params = array_merge($paramsGET, $paramsPOST);
            
            unset($params['controller']);
            unset($params['action']);
            unset($params['module']);
            unset($params['target']);
            unset($params['ff_one_id']);
            //unset($params['sid']);

            if($this->_request->getParam('data')) {
                $paramString = "";
                // Set the post params for the request
                foreach($params as $k => $v) {
                    if(!in_array($k, $clean)) {
                        $client->setParameterGet($k, ($v));
                    }
                }
                $client->setRawData($this->_request->getParam('data'));
            } else {

                // Set the post params for the request
                foreach($params as $k => $v) {
                    if(!in_array($k, $clean)) {
                        $client->setParameterPost($k, ($v));
                    }
                }
            }
            
            if($beta) {
                $target = str_replace('//secure.', '//beta.', $target);
            }
            

            $cookie_file = '/tmp/CURLCOOKIE_' . $ff_one_id;
           
            $config = array(
                'adapter' => 'Zend_Http_Client_Adapter_Curl',
                'curloptions' => array(
                    CURLOPT_RETURNTRANSFER => false,
                    CURLOPT_USERAGENT => $_SERVER['HTTP_USER_AGENT'],
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_SSL_VERIFYPEER => false
                )
            );
            
            
            
            $client->setUri($target);
            $client->setConfig($config);
            
            if(LOGGING_ENABLED) {
            	$logger = Zend_Registry::get('logger');
            	$logger->log('URI: ' . $target, Zend_Log::INFO);
            	$logger->log('Payload: ' . serialize($params), Zend_Log::INFO);
			}
            
            $proxyResponse = array('status' => 'ER', 'error' => array('errorcode' => 2, 'errornotes' => 'An error has occured'));
            $proxyReturnDataType = 'json';
            
            $time_start = $this->getTime();
            
            
            try {
                $response = $client->request("POST");
                if($response->isSuccessful()) {
                    $body = $response->getRawBody();
                    $body = preg_replace('/[^(\x20-\x7F)]*/','', $body);
                    $proxyResponse = $body;
                    
                    if(preg_match('/<\?xml(.*)/', $proxyResponse)) {
                        $proxyReturnDataType = 'xml';
                        // Its an xml response - make sure it HAS the </xml>
                        if(!preg_match('/<\/xml>/', $proxyResponse)) {
                            //$proxyResponse .= '</xml>';
                        }
                    }
                }
                
                if($this->_request->getParam('debug', false)) {
                    //Zend_Debug::dump($client);
                    print $target . '?' . http_build_query($params);
                    print "\n<br>\n";
                    print($proxyResponse);
                    exit();
                }
            } catch (Exception $e) { //Zend_HTTP_Client_Adapter_Exception
                $proxyResponse['error']['errorcode'] = 991;
                $proxyResponse['error']['errornotes'] = $e->getMessage();
            }
            
            $time_finish = $this->getTime();
            
            $time_execution = number_format($time_finish - $time_start, 2);
            if(LOGGING_ENABLED) {
	            $logger->log('Execution Time: ' . $time_execution . ' seconds', Zend_Log::INFO);
			}

            $this->getResponse()
                ->setHeader('Content-Type', ($proxyReturnDataType == 'xml' ? 'text/xml' : 'application/json'))
                ->appendBody($proxyResponse);
            /*
            print $proxyResponse;
             * 
             */
    }
}

