<?php

class HelpController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
        //$this->_helper->layout()->setLayout('firstfolio-one');
    }

    public function indexAction()
    {

        
    }
}

