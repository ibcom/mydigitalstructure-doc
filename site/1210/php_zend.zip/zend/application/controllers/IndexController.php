<?php

class IndexController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
        $this->_helper->layout()->setLayout('firstfolio-one');
        if(isset($_SESSION['UID'])) {
            $uid = $_SESSION['UID'];
        } else {
            $uid = $_SESSION['UID'] = rand(0,9999);
        }
        $this->view->uid = $uid;
    }

    public function indexAction()
    {
        // action body
        
        $trigger = $this->_request->getParam('trigger', false);
        
        if($trigger) {            
            $this->_helper->viewRenderer->setRender('index2');
            $this->_helper->layout()->setLayout('firstfolio-one-new');
        }
    }
    
    public function index2Action()
    {
        $this->_helper->layout()->setLayout('firstfolio-one2');
    }
    
    public function testingAction()
    {
		$this->_helper->layout->disableLayout();
		$this->_helper->viewRenderer->setRender('myapp');
    }
    
    public function adminAction()
    {
        //$this->_helper->layout->disableLayout();
        //$this->_helper->viewRenderer->setNoRender(true);
        
        
        
    }
}

