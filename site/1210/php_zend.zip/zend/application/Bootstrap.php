<?php

class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{
    protected function _initSession() {
        session_start();
    }
    
    protected function _initLogging() {
    	if(LOGGING_ENABLED) {
        	$writer = new Zend_Log_Writer_Stream(APPLICATION_PATH . '/logs/application.log');
        	$logger = new Zend_Log($writer);
        	Zend_Registry::set('logger', $logger);
		}
    }

}