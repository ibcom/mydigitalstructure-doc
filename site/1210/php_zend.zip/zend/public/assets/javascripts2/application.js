Backbone.emulateHTTP = true;
Backbone.emulateJSON = true;
window.myapp = {
	Views: {},
    Routers: {},
    Models: {},
    proxy: null,
    initialize: function() {
    	this.proxy = new mydd_proxy();
    	this.proxy.check_cookie();
    },
    init_application: function() {	
    	// Handle all application loading
    	myapp.Models.contactPeople = new myapp.Models.ContactPersonCollection();
    	myapp.Models.contactBusinesses = new myapp.Models.ContactBusinessesCollection();
    	
        new myapp.Routers.Application();
        new myapp.Routers.Contacts();
        Backbone.history.start();
        
        // Load in children
    	// Load in base models
		
		
		myapp.Models.contactPeople.rowLimit = 1000;
		myapp.Models.contactPeople.X4HSearch(
			myapp.Models.contactPeople.field_list,
			null, 
			null,
			[{name:'surname', direction:'asc'}, {name:'firstname', direction:'asc'}]
		);
		
		myapp.Models.contactBusinesses.rowLimit = 1000;
		myapp.Models.contactBusinesses.X4HSearch(
			myapp.Models.contactBusinesses.field_list,
			null,
			null,
			[{name:'tradename', direction:'asc'}]
		);
		
        /*
        
        
        // Tab Selection
		var selectedTab = 0;
		$('#contents-container li a').each(function(index) {
			if ($(this).attr('href').replace("#", "#contents-container-") == document.location.hash) {
				selectedTab = index;
			}
		});
		$('#contents-container').tabs({
			'select': function(event, ui) {
					document.location.hash = "" + ui.panel.id;
				},
			'selected' : selectedTab
		});
		
		$('.subpage li a').each(function(index) {
			if ($(this).attr('href') == document.location.hash) {
				selectedTab = index;
			}
		});
		$('.subpage').tabs({
			'select': function(event, ui){
					document.location.hash = "" + ui.panel.id;
				},
			'selected' : selectedTab
		});
        */
        
    },
    init_login: function() {
    	// Handle all login loading
    }
}
