myapp.Routers.Contacts = Backbone.Router.extend({
	initialize: function() {
		//var contact_window = new myapp.Views.Contacts({el: $('#contacts')}).render();
		if(typeof myapp.Views.contacts === 'undefined') {
			myapp.Views.contacts = new myapp.Views.Contacts({el: $('#contents')});
		}		
	},
    routes: {
    	"contacts"					: "index",
    	"contacts/people"			: "people",
    	"contacts/groups"			: "groups",
    	"contacts/businesses"		: "businesses"
    },

    index: function() {
    	this.people();
    },
    
    people: function() {
    	myapp.Views.contacts.render();
    	console.log('rendering the people');
    	new myapp.Views.ContactPeople({el: $('#content-contacts')}).render();
    },
    
    groups: function() {
    	myapp.Views.contacts.render();
    },
    
    businesses: function() {
    	myapp.Views.contacts.render();
    	new myapp.Views.ContactBusinesses({el: $('#content-contacts')}).render();
    }
});