myapp.Routers.Application = Backbone.Router.extend({
	initialize: function() {
		var application_window = new myapp.Views.ApplicationWindow({el: $('#application-container')}).render();
	},
    routes: {
    	""				: "index",
    	"dashboard" 	: "index"
    },

    index: function() {
    	console.log('tab: Dashboard');
    }
});