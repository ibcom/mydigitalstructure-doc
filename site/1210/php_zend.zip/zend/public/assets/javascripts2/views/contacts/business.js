myapp.Views.ContactBusinesses = Backbone.View.extend({
	pageCurrent: 1,
	pageLimit: 10,
	pageCount: 1,
	
	template: _.template($('#page-contact-business').html()),
	
    events: {
        /*"click button.prev" : "pagePrevious",
        "click button.next" : "pageNext",*/
    },
    initialize: function() {
		myapp.Models.contactBusinesses.bind('reset', this.paginate, this);
    },
    render: function() {
    	$(this.el).html(this.template);
    	return this;
    },
    addBusiness: function(business) {
    	var view = new myapp.Views.ContactBusinessItem({model: business});
    	this.$('#contact-businesses-list').append(view.render().el);
    },
    addBusinesses: function(businesses) {
    	//this.$('#contact-businesses-list').empty();
    	businesses.each(this.addBusiness);
    },
    paginate: function(objects) {
    	var startVal = (this.pageCurrent * this.pageLimit) - this.pageLimit;
    	var endVal = Math.min(objects.length, (this.pageCurrent * this.pageLimit));
    	
    	for(var i = startVal; i < endVal; i++) {
    		this.addBusiness(objects.models[i]);
    	}
    }
});

myapp.Views.ContactBusinessItem = Backbone.View.extend({
    className: "contact-business-row",
	template: _.template($('#contacts-business-item-view').html()),
	events: {
		'click span.edit'		: 'editBusiness',
		'click span.save'		: 'saveBusiness'
	},
	initialize: function() {
        this.model.bind('change', this.render, this);
        this.model.bind('destroy', this.remove, this);
	},
	render: function() {
		$(this.el).html(this.template(this.model.toJSON()));
		return this;
	},
	remove: function() {
		
	},
	editBusiness: function() {
		this.$('.detailsmode').addClass('hidden');
		this.$('.editmode').removeClass('hidden');
	},
	saveBusiness: function() {
		this.model.set({

		});
		this.model.save();
		this.$('.detailsmode').removeClass('hidden');
		this.$('.editmode').addClass('hidden');
	}
});
