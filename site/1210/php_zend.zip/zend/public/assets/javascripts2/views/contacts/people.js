myapp.Views.ContactPeople = Backbone.View.extend({
	pageCurrent: 1,
	pageLimit: 10,
	pageCount: 1,
	
	template: _.template($('#page-contact-people').html()),
    
    events: {
        /*"click button.prev" : "pagePrevious",
        "click button.next" : "pageNext",*/
    },
    initialize: function() {
		myapp.Models.contactPeople.bind('reset', this.paginate, this);
    },
    render: function() {
    	$(this.el).html(this.template);
    	return this;
    },
    addPerson: function(person) {
    	var view = new myapp.Views.ContactPersonItem({model: person});
    	this.$('#contact-people-list').append(view.render().el);
    },
    addPersons: function(persons) {
    	//this.$('#contact-people-list').empty();
    	persons.each(this.addPerson);
    },
    paginate: function(objects) {
    	var startVal = (this.pageCurrent * this.pageLimit) - this.pageLimit;
    	var endVal = Math.min(objects.length, (this.pageCurrent * this.pageLimit));
    	for(var i = startVal; i < endVal; i++) {
    		this.addPerson(objects.models[i]);
    	}
    }
});

myapp.Views.ContactPersonItem = Backbone.View.extend({
    className: "contact-person-row",
	template: _.template($('#contacts-person-item-view').html()),
	events: {
		'click span.edit'		: 'editPerson',
		'click span.save'		: 'savePerson'
	},
	initialize: function() {
        this.model.bind('change', this.render, this);
        this.model.bind('destroy', this.remove, this);
	},
	render: function() {
		$(this.el).html(this.template(this.model.toJSON()));
		return this;
	},
	remove: function() {
		
	},
	editPerson: function() {
		this.$('.detailsmode').addClass('hidden');
		this.$('.editmode').removeClass('hidden');
	},
	savePerson: function() {
		this.model.set({
			firstname: this.$('.input-firstname').val(),
			surname: this.$('.input-surname').val(),
			email: this.$('.input-email').val(),
			mobile: this.$('.input-mobile').val(),
			workphone: this.$('.input-workphone').val(),
			position: this.$('.input-position').val(),
			streetaddress1: this.$('.input-streetaddress1').val(),
			streetaddress2: this.$('.input-streetaddress2').val(),
			streetsuburb: this.$('.input-streetsuburb').val(),
			streetpostcode: this.$('.input-streetpostcode').val(),
			streetstate: this.$('.input-streetstate').val(),
			streetcountry: this.$('.input-streetcountry').val()
		});
		this.model.save();
		this.$('.detailsmode').removeClass('hidden');
		this.$('.editmode').addClass('hidden');
	}
});
