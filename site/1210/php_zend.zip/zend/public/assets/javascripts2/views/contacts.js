myapp.Views.Contacts = Backbone.View.extend({
	template: _.template($('#page-contact').html()),
    initialize: function() {
		//console.log("Initialized the contacts tab: Setting the first element selected and reseting all tabs");
		//$(this.el).tabs('select', 'contacts-people-tab');
    },
    render: function() {
    	$(this.el).html(this.template);
    	return this;
    }
});
