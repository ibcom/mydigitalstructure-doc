myapp.Models.ContactBusiness = X4HModel.extend({
	field_list: ['Tradename', 'Area', 'AreaText', 'Industry', 'IndustryText', 'Notes', 'OtherInfo', 'Reference', 'PhoneNumber', 'FaxNumber', 
		'Email', 'WebAddress', 'StreetAddressCombined', 'streetaddress1', 'streetaddress2', 'StreetSuburb', 'StreetPostCode', 'StreetState', 'StreetCountry', 'sq6966'],
	url: function() {
		var url =  myapp.proxy.buildUrl('/ondemand/contact/?method=CONTACT_BUSINESS_MANAGE');
		return url;
	},
	methodToUrl: {
		'read'		: '/ondemand/contact/?method=CONTACT_BUSINESS_SEARCH',
		'create'	: '/ondemand/contact/?method=CONTACT_BUSINESS_MANAGE',
		'update'	: '/ondemand/contact/?method=CONTACT_BUSINESS_MANAGE',
		'delete'	: '/ondemand/contact/?method=CONTACT_BUSINESS_MANAGE'
	}
});

myapp.Models.ContactBusinessesCollection = X4HCollection.extend({
	field_list: ['Tradename', 'Area', 'AreaText', 'Industry', 'IndustryText', 'Notes', 'OtherInfo', 'Reference', 'PhoneNumber', 'FaxNumber', 
		'Email', 'WebAddress', 'StreetAddressCombined', 'streetaddress1', 'streetaddress2', 'StreetSuburb', 'StreetPostCode', 'StreetState', 'StreetCountry', 'sq6966'],
	model: myapp.Models.ContactBusiness,
	url: function() {
		var url =  myapp.proxy.buildUrl('/ondemand/contact/?method=CONTACT_BUSINESS_SEARCH');
		return url;
	}
});
