myapp.Models.ContactGroup = X4HModel.extend({
	field_list: [],
	
	url: function() {
		var url =  myapp.proxy.buildUrl('/ondemand/contact/?method=CONTACT_PERSON_MANAGE');
		return url;
	},
	
	methodToUrl: {
		'read'		: '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
		'create'	: '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
		'update'	: '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
		'delete'	: '/ondemand/contact/?method=CONTACT_PERSON_MANAGE'
	}
});

myapp.Models.ContactPersonCollection = X4HCollection.extend({
	field_list: [],
	model: myapp.Models.ContactGroup,
	url: function() {
		var url =  myapp.proxy.buildUrl('/ondemand/contact/?method=CONTACT_PERSON_SEARCH');
		return url;
	}
});