// CONTACTS: COMPANY
  // Helper function to get a value from a Backbone object as a property
  // or as a function.
var getValue = function(object, prop) {
	if (!(object && object[prop])) return null;
	return _.isFunction(object[prop]) ? object[prop]() : object[prop];
};

window.X4HModel = Backbone.Model.extend({
	sync: function (method, model, options) {
	    var type = 'POST';
	
	    // Default JSON-request options.
	    var params = {type: type, dataType: 'json'};
	
	    // Ensure that we have a URL.
	    if (!options.url) {
	    	params.url = getValue(model, 'url') || urlError();

		    
	    	if(getValue(model, 'methodToUrl')) {
				if(model.methodToUrl[method] != undefined) {
					params.url = myapp.proxy.buildUrl(model.methodToUrl[method]); 
				}
	    	}
	    }
	    

	
	    // Ensure that we have the appropriate request data.
	    if (!options.data && model && (method == 'create' || method == 'update')) {
	      params.contentType = 'application/json';
	      params.data = JSON.stringify(model.toJSON());
	    }
	    // For older servers, emulate JSON by encoding the request into an HTML-form.
	    if (Backbone.emulateJSON) {
	      	params.contentType = 'application/x-www-form-urlencoded';
	      	if(method == 'read') {
				params.data = {
					advanced: 1, 
					data: new X4HASearch(model.field_list).addFilter('id', 'EQUAL_TO', model.id).getXML()
				};
	      	} else {
	      		params.data = params.data ? model.toJSON() : {};
	    	}
	    	
	    }

	    // For older servers, emulate HTTP by mimicking the HTTP method with `_method`
	    // And an `X-HTTP-Method-Override` header.
	    if (Backbone.emulateHTTP) {
	      if (type === 'PUT' || type === 'DELETE') {
	        if (Backbone.emulateJSON) params.data._method = type;
	        params.type = 'POST';
	        params.beforeSend = function(xhr) {
	          xhr.setRequestHeader('X-HTTP-Method-Override', type);
	        };
	      }
	    }
	
	    // Don't process data on a non-GET request.
	    if (params.type !== 'GET' && !Backbone.emulateJSON) {
	      params.processData = false;
	    }
	
	    // Make the request, allowing the user to override any Ajax options.
	    return $.ajax(_.extend(params, options));
	},
	
	parse: function(response, xhr) {
		// Switch based on the notes for the call
		var return_value = null;
		if(response.notes != "") {
			switch(response.notes) {
				case 'RETURNED': {
					if(response.data == undefined) {
						return_value = response;
					} else {
						return_value = response.data.rows[0];
					}
					break;
				}
				case 'CREATED':
				case 'UPDATED': {
					return_value = this.toJSON();
					break;
				}
				default: {
					return_value = response;
					break;
				}
			}
		} else {
			return_value = response;
		}
		return return_value;
	}
});

window.X4HCollection = Backbone.Collection.extend({
	rowStart: 0,
	rowLimit: 20,
	rowCount: 0,
	
	X4HSearch: function(fields, filters, options, sort) {
		if(fields == undefined) {
			fields = [];
		}
		if(filters == undefined) {
			filters = [];
		}
		if(options == undefined) {
			options = {startrow: this.rowStart, rows: this.rowLimit};
		}
		if(sort == undefined) {
			sort = [];
		}
		var oXML = new X4HASearch(fields, filters, options, sort).getXML();

		return this.fetch({
			data: {
				advanced: 1, 
				data: oXML
			},
			type: 'POST'
		});
	},
	parse: function(response) {
		if(typeof response.morerows !== 'undefined') {
			if(typeof response.summary !== 'undefined') {
				this.rowCount = response.summary.auditcount;
			}
		}
		if(typeof response.data !== 'undefined') {
			return _(response.data.rows).map(function(row) {
				return row;
			});
		}
		return array();
	},
	pageNext: function() {
		
	},
	pagePrev: function() {
		
	},
	
});

//_.defaults(ContactCompany.prototype.save, X4HModel.prototype.save); 
//_.extend();
//User.__super__.save.apply(this, arguments)
