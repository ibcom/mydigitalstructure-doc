function mydd_proxy() {
    this.site_id = 1320;
	this.site_url = 'https://firstfolio-test.1blankspace.com';
    this.proxy_host = 'http://firstfolio-one/proxy/';
    this.ff_one_id = 1;
    this.sid = 0;
    this.user = 0;
	
	this.save_cookie = function(sid, user) {
        $.cookie('mds_sid', sid);
        $.cookie('mds_user', user);
        
        this.sid = sid;
        this.user = user;
    }
    
    
    this.check_cookie = function(ff_user_id) {     
        proxy = this;
        this.ff_one_id = ff_user_id;
        this.sid = $.cookie('mds_sid');
        this.user = $.cookie('mds_user');
        
        var uri = 'http://firstfolio-test.1blankspace.com/ondemand/core/?method=CORE_GET_USER_DETAILS';
        $.getJSON(
            this.proxy_host,
            {
                target: uri,
                ff_one_id: this.ff_one_id,
                sid: this.sid
            }
        )
        .success(function(response) {
            if(response == null || response == '') {
                this.error_handler();
            } else {
                if(response.status != 'OK' || response.notes != 'RETURNED') {
                	proxy.login('roland.test@firstfolio.com.au', 'fftest2011');
                } else {
                	console.log('Logged in: Initializing App');
                    App.init_dashboard();
                }
            }
        })
        .error(function(response) {
        	proxy.login('roland.test@firstfolio.com.au', 'fftest2011');
        });
        
    }
    
    this.login = function(username, password) {
        $('#interfaceMasterLogonStatus').html("");
        if(username == '' || username == null) {

            return false;
        }
        
        if(password == '' || password == null) {
            return false;
        }
        
        
        x4hub = this;
        $.getJSON(
            this.proxy_host + '?target=http://firstfolio-test.1blankspace.com/ondemand/logon/',
            {
                logon: username, 
                password: password,
                ff_one_id: this.ff_one_id
            },
            function(data) {
                if( data.status == 'ER' ) {
                    // We have an error taking effecttime 
                    var errorMessage = '';
                    switch(data.error.errornotes) {
                        case 'LOGONFAILED': {
                            errorMessage = 'Invalid username and/or password';
                            break;
                        }
                        default: {
                            errorMessage = "Error: " + data.error.errornotes;
                            break;
                        }
                    }
                    console.log(errorMessage);
                } else if( data.status = 'OK' ) {
                    if(data.passwordStatus == 'OK') {
                        // Log the user in
                        x4hub.save_cookie(data.sid, data.user)
                        //document.location.reload();
                        console.log("Logged in now");
                        App.init_dashboard();
                    }
                }
            }
        );
    }
    
    this.buildUrl = function(target_url) {
    	return this.proxy_host + '?target=' + this.site_url + target_url + '&sid=' + this.sid + '&site=' + this.site_id;
    }
}
