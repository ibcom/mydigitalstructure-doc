$(function() {
	 // Router
	App.Routers.Contacts = Backbone.Router.extend({
		initialize: function(options) {
			new ContactsView().render();
		},
		
	    routes: {
	 		"contacts" : 						"index",
	 		"contacts/people" : 				"people",
	 		"contacts/business" : 				"business",
	 		"contacts/search/:type/:term" : 	"search"
	    },
	
	    index: function() {            
			this.people();
	    },
	
		people: function() {
			// Initialise the list of contacts (people) from X4Hub
			$('#app-tabs').tabs('select', 'contact');
			var view = new ContactsPeopleView({el: $('#contacts-tab')}).render();
		},
		
		business: function() {
			console.log('business');
		},
		
		search: function(type, term) {
			
		}
	});
});