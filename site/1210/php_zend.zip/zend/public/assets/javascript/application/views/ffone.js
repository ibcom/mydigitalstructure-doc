$(function() {
	window.FirstfolioOneView = Backbone.View.extend({
	    el: $('#application-container'),
	    events: {

	    },
	    initialize: function() {
			
	    },
	    render: function() {
	    	return this;
	    }
    });
 
});