$(function() {
	 // Router
	App.Routers.Application = Backbone.Router.extend({
	    routes: {
	    	"": "index",
	    	"dashboard" : "index"
	    },
	
	    index: function() {
	  		

			// Do the view for the user profile
			
	    }
	});
});