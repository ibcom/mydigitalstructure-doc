$(function() {
	window.ContactsCompaniesView = Backbone.View.extend({
		collection: null,
	    el: $('#contacts-companies-tab'),
		template: _.template($('#contacts-company').html()),
		events: {

	    },
	    initialize: function() {
			var companies = new ContactCompanyCollection();
			companies.bind('reset', this.addCompanies, this);
			companies.X4HSearch(
				['Tradename', 'Area', 'AreaText', 'Industry', 'IndustryText', 'Notes', 'OtherInfo', 'Reference', 'PhoneNumber', 'FaxNumber', 
				'Email', 'WebAddress', 'StreetAddressCombined', 'streetaddress1', 'streetaddress2', 'StreetSuburb', 'StreetPostCode', 'StreetState', 'StreetCountry', 'sq6966'],
				null, null, [{name:'tradename', direction:'asc'}]
			);
			
	    },
	    render: function() {
	    	console.log('rendering companies');
	    	$(this.el).html(this.template());
	    	return this;
	    },
	    addCompany: function(company) {
	    	var view = new ContactsCompanyItemView({model: company});
	    	this.$('.contact-company-list').append(view.render().el);
	    },
	    addCompanies: function(companies) {
	    	companies.each(this.addCompany);
	    }
    });
    
    
    
    window.ContactsCompanyItemView = Backbone.View.extend({
		tagName: "div",
        className: "company-row",
        template: _.template($('#contacts-company-item').html()),
        
        // Functions
        events: {
            "click span.edit"			: "toggleEdit",
            "click span.cancel"			: "toggleEdit",
            "click span.save"			: "saveCompany"
        },

        initialize: function() {
            this.model.bind('change', this.render, this);
            this.model.bind('destroy', this.remove, this);
        },

        render: function() {
        	$(this.el).html(this.template(this.model.toJSON()));
        	return this;
        },
        
        remove: function() {
        	
        },
        
        toggleEdit: function() {
        	this.$('.details > .basic').toggle();
        	this.$('.details > .edit').toggle();
        },
        
        saveCompany: function() {
        	this.model.set({
        		tradename: this.$('.input-tradename').val(),
        		email: this.$('.input-email').val(),
        		phonenumber: this.$('.input-phonenumber').val(),
        		webaddress: this.$('.input-webaddress').val(),
				streetaddress1: this.$('.input-streetaddress1').val(),
				streetaddress2: this.$('.input-streetaddress2').val(),
				streetsuburb: this.$('.input-streetsuburb').val(),
				streetstate: this.$('.input-streetstate').val(),
				streetpostcode: this.$('.input-streetpostcode').val(),
				streetcountry: this.$('.input-streetcountry').val()
        	});
        	
        	//console.log(this.model);
			this.model.save();
        	this.toggleEdit();
        }
        
    });
 
});