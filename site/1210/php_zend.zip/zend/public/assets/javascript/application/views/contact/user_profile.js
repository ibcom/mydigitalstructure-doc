$(function() {
	window.ContactUserProfileView = Backbone.View.extend({
		el: $('#contact-profile'),
		template: _.template($('#contact-profile-user').html()),    
	    events: {

	    },
	    initialize: function() {
			this.model.set('profile_image', null);
	    },
	    render: function() {
	    	$(this.el).html(this.template(this.model.toJSON()));
	    	return this;
	    },
    });
 
});