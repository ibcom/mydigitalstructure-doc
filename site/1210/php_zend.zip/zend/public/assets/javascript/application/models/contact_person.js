window.ContactPerson = X4HModel.extend({
	field_list: ['firstname', 'surname', 'email', 'homephone', 'workphone', 'position', 'mobile', 'contactbusiness', 'contactbusinesstext', 'fax', 
		'streetaddress1', 'streetaddress2', 'streetsuburb', 'streetstate', 'streetcountry', 'streetpostcode', 'dateofbirth','sq6861', 'sq6934', 'sq6856', 'sq6857', 'sq6858'],
	
	url: function() {
		var url =  myapp.proxy.buildUrl('/ondemand/contact/?method=CONTACT_PERSON_MANAGE');
		return url;
	},
	
	methodToUrl: {
		'read'		: '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
		'create'	: '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
		'update'	: '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
		'delete'	: '/ondemand/contact/?method=CONTACT_PERSON_MANAGE'
	}
});

window.ContactPersonCollection = X4HCollection.extend({
	model: ContactPerson,
	url: function() {
		var url =  myapp.proxy.buildUrl('/ondemand/contact/?method=CONTACT_PERSON_SEARCH');
		return url;
	}
});