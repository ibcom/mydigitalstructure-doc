$(function() {
	window.ContactsView = Backbone.View.extend({
		el: $('#contacts-tab'),
		template: _.template($('#contacts-tab-view').html()),    
	    events: {
	        /*"click button.prev" : "pagePrevious",
	        "click button.next" : "pageNext",*/
	    },
	    initialize: function() {
			console.log("Initialized the contacts tab");			
	    },
	    render: function() {
	    	$(this.el).html(this.template);
	    	return this;
	    }		
	});
});