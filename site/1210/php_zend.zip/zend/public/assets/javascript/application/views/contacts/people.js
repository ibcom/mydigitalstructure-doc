$(function() {
	window.ContactsPeopleView = Backbone.View.extend({
		el: $('#contacts-people-tab'),
	    events: {
	        /*"click button.prev" : "pagePrevious",
	        "click button.next" : "pageNext",*/
	    },
	    initialize: function() {
	    	globalContactPeople.bind('reset', this.addContacts, this);
			if(globalContactPeople.length == 0) {
				globalContactPeople.X4HSearch(
					['firstname', 'surname', 'email', 'homephone', 'workphone', 'position', 'mobile', 'contactbusiness', 'contactbusinesstext', 
					'fax', 'streetaddress1', 'streetaddress2', 'streetsuburb', 'streetstate', 'streetcountry', 'streetpostcode', 'dateofbirth', 
					'sq6861', 'sq6934', 'sq6856', 'sq6857', 'sq6858'],
					null, 
					null, //{startrow: 0, rows: 10000},
					[{name:'surname', direction:'asc'}, {name:'firstname', direction:'asc'}]
				);
			}
	    },
	    render: function() {
	    	return this;
	    },
	    addContact: function(contact) {
	    	var view = new ContactsPeopleItemView({model: contact});
	    	this.$('.contact-people-list').append(view.render().el);
	    },
	    addContacts: function(contacts) {
	    	contacts.each(this.addContact);
	    }
	});
	
	window.ContactsPeopleItemView = Backbone.View.extend({
		//el: $('#contact-people-list'),
        tagName: "div",
        className: "contact-row",
		template: _.template($('#contacts-people-item-view').html()),
	    events: {
	        /*"click button.prev" : "pagePrevious",
	        "click button.next" : "pageNext",*/
	    },
	    initialize: function() {
			console.log('making new contact person');
	    },
	    render: function() {
	    	$(this.el).html(this.template(this.model.toJSON()));
	    	return this;
	    }	
	});
});