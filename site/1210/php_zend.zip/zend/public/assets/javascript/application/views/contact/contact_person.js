$(function() {
	window.ContactsPersonsView = Backbone.View.extend({
		collection: null,
	    el: $('#contacts-people-tab'),
		template: _.template($('#contacts-person').html()),    
	    events: {
	        /*"click button.prev" : "pagePrevious",
	        "click button.next" : "pageNext",*/
	    },
	    initialize: function() {
			var contacts = new ContactPersonCollection();
			contacts.bind('reset', this.addContacts, this);
			contacts.X4HSearch(
				['firstname', 'surname', 'email', 'homephone', 'workphone', 'position', 'mobile', 'contactbusiness', 'contactbusinesstext', 
			'fax', 'streetaddress1', 'streetaddress2', 'streetsuburb', 'streetstate', 'streetcountry', 'streetpostcode', 'dateofbirth', 
			'sq6861', 'sq6934', 'sq6856', 'sq6857', 'sq6858'],
				null, null,[{name:'surname', direction:'asc'}, {name:'firstname', direction:'asc'}]
			);
			
			this.collection = contacts;
	    },
	    render: function() {
	    	$(this.el).html(this.template);
	    	return this;
	    },
	    addContact: function(contact) {
	    	var view = new ContactsPersonItemView({model: contact});
	    	this.$('.contact-people-list').append(view.render().el);
	    },
	    addContacts: function(contacts) {
	    	contacts.each(this.addContact);
	    },
	    showPagination: function(contacts) {
			
	    }
    });
    
    window.ContactsPersonItemView = Backbone.View.extend({
        tagName: "div",
        className: "contact-row",
        template: _.template($('#contacts-person-item').html()),
        preview_element: null,
        
        // Functions
        events: {
            //"dblclick": "togglePreview"
            "dblclick img.display-pic" 	: "toggleDetails",
            "click span.edit"			: "showEditBox",
            "click span.save"			: "saveEditBox",
            "click span.cancel"			: "hideEditBox"
        },

        initialize: function() {
            this.model.bind('change', this.render, this);
            this.model.bind('destroy', this.remove, this);
        },

        render: function() {
        	$(this.el).html(this.template(this.model.toJSON()));
        	return this;
        },
        
        remove: function() {
        	
        },
        
        showEditBox: function() {
			this.$('div.edit').show();
        	this.$('div.view').hide();

			if(!$(this.el).hasClass('selected-item')) {
        		$(this.el).addClass('selected-item');
        	}
        	this.$('.advanced').show();

        },
        
        hideEditBox: function() {
			this.$('div.edit').hide();
        	this.$('div.view').show();

			if($(this.el).hasClass('selected-item')) {
        		$(this.el).removeClass('selected-item');
        	}
        	this.$('.advanced').hide();
        },
        
		saveEditBox: function() {
			
			this.model.set({
				firstname: this.$('.input-firstname').val(),
				surname: this.$('.input-surname').val(),
				email: this.$('.input-email').val(),
				mobile: this.$('.input-mobile').val(),
				workphone: this.$('input-workphone').val(),
				position: this.$('.input-position').val(),
				streetaddress1: this.$('.input-streetaddress1').val(),
				streetaddress2: this.$('.input-streetaddress2').val(),
				streetsuburb: this.$('.input-streetsuburb').val(),
				streetpostcode: this.$('.input-streetpostcode').val(),
				streetstate: this.$('.input-streetstate').val(),
				streetcountry: this.$('.input-streetcountry').val()
			});	

			this.model.save();
			
			this.hideEditBox();
			this.render();
			// Set the values to the model
		},
        
        toggleDetails: function() {
        	if($(this.el).hasClass('selected-item')) {
        		$(this.el).removeClass('selected-item');
        		this.$('.advanced').hide();
        	} else {
        		$(this.el).addClass('selected-item');
        		this.$('.advanced').show();
        	}
        }
    });
});