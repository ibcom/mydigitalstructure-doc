var X4HAdminFunctions = {
    getObjectListCore: function() {
        var oXML = new X4HASearch(
            ['title'], 
            null, 
            [{rf: 'json', startrow: 0, rows: 100, returnparameters: true}],
            [{name: 'id', direction: 'desc'}]
        ).getXML();
        
        x4hubProxy.call(
            [this, 'getObjectListResponse', 'object-list-core'],
            '/ondemand/core/?method=CORE_OBJECT_SEARCH',
            {
                advanced: 1,
                data: oXML,
                rows: 1000
            }
        );
    },
    getObjectListCustom: function() {
        var oXML = new X4HASearch(
            ['title'], 
            null, 
            [{rf: 'json', startrow: 0, rows: 100, returnparameters: true}],
            [{name: 'id', direction: 'desc'}]
        ).getXML();
        
        x4hubProxy.call(
            [this, 'getObjectListResponse', 'object-list-custom'],
            //'/ondemand/core/?method=CORE_OBJECT_SEARCH',
            '/ondemand/setup/?method=SETUP_STRUCTURE_SEARCH',
            {
                advanced: 1,
                data: oXML,
                rows: 1000
            }
        );
    },    
    getObjectListResponse: function(response, container) {
        if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                $('#' + container)
                .append($('<div class="object-info">')
                    .html('<div>' + row.id + ' - ' + row.title + '<button class="object-edit id-' + row.id + '">edit</button><button class="object-delete id-' + row.id + '">delete</button></div>')
                );
            });
        }
        
        $('.object-edit').click(function() {            
            var tmp = $(this).attr('class').split(' ');
            $.each(tmp, function(i, class_name) {
                var id = myappmaster.find_id(class_name);
                if(id > 0) {
                    // Show edit window
                }
            });
        });
        
        $('.object-delete').click(function() {            
            var tmp = $(this).attr('class').split(' ');
            $.each(tmp, function(i, class_name) {
                var id = myappmaster.find_id(class_name);
                if(id > 0) {
                    var conf = confirm("Are you sure you wish to delete this object? (" + id + ")");
                    if(conf) {
                        // Delete teh item
                        X4HAdminFunctions.manageObject(id, null, null, null, null, 1);
                    }
                    
                }
            });            
        });
    },    
    createDocument: function(title, content, summary, keywords, url, is_public, type) {
        
    },
    createDocumentResponse: function(response, container) {
        
    },
    createDocumentFolder: function(title, parent_folder_id, advanced) {
        
    },
    createDocumentFolderResponse: function(response, container) {
        
    },
    
    // Ability to create/edit/delete objects 
    manageObject: function(id, title, type, description, status, remove) {
        var params = {};
        if(id != null) {
            params.id = id;
        }
        if(title != null) {
            params.title = title;
        }
        
        if(type != null) {
            params.type = type;
        }
        
        if(description != null) {
            params.description = description;
        }
        
        if(status != null) {
            params.status = status;
        }
        
        if(remove != null) {
            params.remove = 1;
        }
        
        x4hubProxy.call(
            [this, 'manageObjectResponse'],
            '/ondemand/setup/?method=SETUP_STRUCTURE_MANAGE',
            params
        );
    },
    manageObjectResponse: function(response, container) {
        console.log("Object Managed?");
        console.log(response);
        
        console.log("Reloading Objects");
        $('#object-list-custom').empty();
        this.getObjectListCustom();
    }
};