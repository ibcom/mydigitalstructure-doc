var X4HNews = {
    object_id: 19,
    object_name: 'News',
    
    //defaultFields: ['firstname', 'surname', 'email', 'homephone', 'position', 'workphone', 'mobile'],
    defaultFilters: [],
    //defaultOptions: [{rf: 'json', startrow: 0, rows: 20, returnparameters: true}],
    defaultSort: [{name: 'id', direction: 'desc'}],    
    
    available_groups: {},
    selected_groups: {},
    group_contacts : {},
    
    last_query: null,
    
    current_news_list : {}, selected_news : null,
    
    init: function() {        
        // Populate the list of available groups
        //if(this.available)
        //myappmaster.news.get_groups();
        //setTimeout(this.list_groups,6000);
        
        /* added to handle advance searching */
            if(X4HASearchWidget.widget_search){
                var filter = X4HASearchWidget.search_filter;
            }else{
                filter = null;
            }
        
        // Do a search for the current crop of newsletters
        this.search(null, filter, null, null, [{name: 'id', direction: 'desc'}]);

        //switch for tabs
        $('#edm-nav').tabs({
            show : function(event, ui){
				var tmp = ui.tab.hash.split('-');
                var tabindex = $(this).tabs("length")-1;
                if(ui.index!=tabindex){
                    if(tabindex>2) //default tab length
                    {
                            if(tmp != '#edmCreateNewsletter')
                            {
                                    //Remove Tiny MCE too
                                    tinyMCE.execCommand('mceRemoveControl', false, 'field-news-content');
                            }
                            //remove the last tab    
                            $(this).tabs("remove",tabindex);
                    }
                }
                
                if(ui.index==1){//Groups
                    console.log('Loading groups')
                    myappmaster.news.get_groups_preload();
                    myappmaster.news.get_groups();
                    $( '.show-create-contact-group').click(function(event) {
                        event.preventDefault();
                        $('#field-contact-group-name').val('');
                        $( '#contact-group-add').show();
                        
                    });
        
                    $( '.hide-create-contact-group').click(function(event) {
                        event.preventDefault();
                        $( '#contact-group-add').hide();
                    });
                    
                    $('#create-contact-group-btn').button({
                        create : function(){
                            $(this).click(function(){
                                if($('#field-contact-group-name').val()==''){
                                    alert('Please enter a group name.');
                                }else{
                                    console.log('Create new group');
                                    $( '#contact-group-add').hide();
                                    myappmaster.news.get_groups_preload();
                                    myappmaster.news.create_contact_group($('#field-contact-group-name').val());
                                }
                            });
                        }
                    });
                    
                }
                
                
            }
        });
	},
    list_groups: function() {
        //console.log(this.available_groups);
        if(this.available_groups.size > 0) {
            $.each(this.available_groups, function(group_id, group_name) {
                var rowcontent = this.generate_group_row({id: group_id, name: group_name});
                $('#edm-groups-list').append(rowcontent);
                console.log("binding the elements");
            });
        }
    },
    
    generate_group_row: function(row) {
        var rowcontent = ''
        + '<div id="contact-group-row-' + row.id + '" class="contact-group-row">'
        + '    <div class="contact-group-name"><span>' + row.title + '</span></div>'
        + '    <div class="contact-group-options"><span class="concat-group-edit-anchor"><a href="#">Edit</a></span></div>'
        + '    <div class="contact-group-members"><span>-</span></div>'
       
        + '</div>';
        
        return rowcontent;
    },
    
    get_groups_preload : function(){
      var preloader = $(
        '<div id="preloader-news-group">'
        +'<span><img src="/assets/images/preloader.gif" /><br  />loading</span>'
        +'</div>'
      );
          
      $('#edm-groups-list').html(preloader);    
    },
    
    // Gets all of the available groups for newsletters
    get_groups: function(callbackobj,callback) {
        if(callbackobj==undefined){
            callbackobj = myappmaster.news; 
        }
        
        if(callback==undefined){
            callback = 'get_groups_response'
        }
        x4hubProxy.call(
            [callbackobj, callback],
            '/ondemand/setup/?method=SETUP_CONTACT_PERSON_GROUP_SEARCH',
            {
                rows: 100
            }
        );
    },
    
    /*get_news_groups : function(news_id,callbackobj, callback){
        if(callbackobj==undefined){
            callbackobj = myappmaster.news; 
        }
        
        if(callback==undefined){
            callback = 'get_news_groups_response'
        }
        x4hubProxy.call(
            [callbackobj, callback],
            '/ondemand/news/?method=NEWS_PERSON_GROUP_SEARCH',
            {
                news : news_id,
                rows: 100
            }
        );
    },
    
    get_news_groups_response : function(response){
        if(response.data.rows.length>0){
            $.each(response.data.rows,function(key,row){
               console.log(row.group) 
            });
        }
    },*/
    
    get_groups_response: function(response) {
        if(response.data.rows.length > 0) {
            
            /* remove preloader */
            $('#edm-groups-list').html('');
            
            /* append header */
            var header = $(
                '<div class="contact-group-header">'
                +'  <div class="contact-group-name">Name</div>'
                +'  <div class="contact-group-options">Options</div>'
                +'  <div class="contact-group-members">Members</div>'
                +'</div>'
            );
                
            $('#edm-groups-list').html(header);    
            
            $.each(response.data.rows, function(key, row) {
                myappmaster.news.available_groups[row.id] = row.title;
                var rowcontent = myappmaster.news.generate_group_row(row);
                $('#edm-groups-list').append(rowcontent);
            });
            
            
            
            
            /* TEMP - get members list (muti-call) */
            /* clear any queue */
            ajaxQueue.clearQueue();
            ajaxQueue.stop();
            $.each(response.data.rows, function(key,row){
                myappmaster.news.get_contact_group_members(row);
            });
            
            
            /* bind details */
            $.each($('.contact-group-row'),function(key,group){
               $(group).find('.contact-group-members span').click(function(){
                   var group_id = myappmaster.find_id($(group).attr('id'));
                   /* prevent loading while member is still loading */
                   if($(group).find('.contact-group-members span').html()!=='-')
                   myappmaster.news.contact_groups.show(group_id, 'details');
               });
               
               $(group).find('.contact-group-name span').click(function(){
                   var group_id = myappmaster.find_id($(group).attr('id'));
                   /* prevent loading while member is still loading */
                   if($(group).find('.contact-group-members span').html()!=='-')
                   myappmaster.news.contact_groups.show(group_id, 'details');
               });
               
               $(group).find('.concat-group-edit-anchor a').click(function(){
                   var group_id = myappmaster.find_id($(group).attr('id'));
                   /* prevent loading while member is still loading */
                   if($(group).find('.contact-group-members span').html()!=='-')
                   myappmaster.news.contact_groups.show(group_id, 'edit');
               });
               
            });
            
            
            
        }else{
                $('#edm-groups-list').html('<p>There are no groups to display.</p>');
        }
    },
    
    // Gets the selected groups for a newsletter
    get_selected_groups: function(newsletter_id, populate) {        
        x4hubProxy.call(
            [myappmaster.news, 'get_selected_groups_response', populate], 
            '/ondemand/news/?method=NEWS_CONTACT_PERSON_GROUP_SEARCH',
            {
                news: newsletter_id, 
                rows: 100
            }
        );
    },
    get_selected_groups_response: function(response, populate) {
        myappmaster.news.selected_groups = {};
        if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                //if(myappmaster.news.selected_groups[row.group] == undefined) {
                    myappmaster.news.selected_groups[row.group] = row.grouptext;
                //}
            });
        }
        
        if(populate) {
            myappmaster.news.populate_groups();
        }
    },
    
    populate_groups: function() {
        var available = myappmaster.news.available_groups;
        var selected = myappmaster.news.selected_groups;
        $('.grouplist').find('option').remove().end();
        
        $.each(available, function(group_id, group_name) {
            if(selected[group_id] == undefined) {
                $('#list-newsletter-available-groups').append('<option value="' + group_id + '">' + group_name + '</option>');
            } else {
                $('#list-newsletter-selected-groups').append('<option value="' + group_id + '">' + group_name + '</option>');
            }
        });
        
    },
    
    // Add a group for a newsletter
    add_newsletter_group: function(newsletter_id, group_id, callbackobj, callback) {
        if(callbackobj==undefined){
            callbackobj = this;
        }
        
        if(callback==undefined){
            callback = 'add_newsletter_group_return'
        }
        
        
        x4hubProxy.call(
            [callbackobj, callback, group_id], 
            '/ondemand/news/?method=NEWS_PERSON_GROUP_MANAGE',
            {
                news: newsletter_id,
                group: group_id
            }
        );
        
    },
    add_newsletter_group_return: function(response, group_id) {
        if(response.notes=='ADDED'){
        myappmaster.add_message('Newsletter Group has been added.', 5);
        }
        myappmaster.news.selected_groups[group_id] = myappmaster.news.available_groups[group_id];
        myappmaster.news.populate_groups();
    },
    
    remove_newsletter_group: function(newsletter_id, group_id, callbackobj, callback) {
        if(callbackobj==undefined){
            callbackobj = this;
        }
        
        if(callback==undefined){
            callback = 'remove_newsletter_group_return'
        }
        
        x4hubProxy.call(
            [callbackobj, callback , group_id],
            '/ondemand/news/?method=NEWS_PERSON_GROUP_MANAGE',
            {
                news: newsletter_id,
                group: group_id,
                remove: 1                
            }
        );
    },
    remove_newsletter_group_return: function(response, group_id) {
        if(response.notes=='REMOVED'){
            myappmaster.add_message('Newsletter Group has been removed.', 5);
        }
        delete myappmaster.news.selected_groups[group_id];
        myappmaster.news.populate_groups();
    },   
    
    // Search Function
    search: function(fields, filters, options, sort) {
        if(fields == null) {
            fields = this.defaultFields;
        }
        if(filters == null) {
            filters = this.defaultFilters;
        }
        if(options == null) {
            options = this.defaultOptions;
        }
        if(sort == null) {
            sort = this.defaultSort;
        }
        
        var oXML = new X4HASearch(fields, filters, options, sort).getXML();
        this.last_query = {
            fields: fields,
            filters: filters,
            options: options,
            sort: sort
        };
       
        x4hubProxy.call(
            [X4HNews, 'search_return', 'newsletter-main-list'], 
            '/ondemand/news/?method=NEWS_SEARCH',
            {
                advanced: 1,
                data: oXML
            }
        );
            
        /* reset search flag */    
        if(X4HASearchWidget.widget_search){
            X4HASearchWidget.widget_search = false;
        }    
    },
    search_return: function(response, container) {
        $('#' + container).find('.newsletter-row').remove();
                
        if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                myappmaster.news.current_news_list[row.id]=row;
                var row = $(
                    '<div id="newsletter-row-' + row.id + '" class="newsletter-row">'
                        + '<div class="newsletter-subject">' + row.subject + '</div>'                        
                        + '<div class="newsletter-options"><span id="newsletter-edit-' + row.id + '" class="newsletter-edit-anchor">Edit</span></div>'
                        + '<div class="newsletter-subscribers" id="newsletter-subscribers-'+row.id+'">0</div>'
                        + 
                    '</div>'
                );
                $('#' + container).append(row);
						        $('#preloader-news').hide();

            });            
        }
        this.bind_element_triggers();
        
        // Get subscribers
        myappmaster.news.subscribers.get_subscribers();
    },
    load: function(newsletter_id) {
        x4hubProxy.call(
            [myappmaster.news, 'prefill_tab'], 
            '/ondemand/news/?method=NEWS_SEARCH',
            {
                id: newsletter_id
            }
        );
    },
    
    
    bind_element_triggers: function() {
	$('#create-newsletter-btn a').unbind('click').click(function(event) {            
            myappmaster.news.create_show_tab.init('Create Newsletter');
            myappmaster.news.selected_news = null;
	});
        $('.newsletter-edit-anchor').unbind('click').click(function(event) {  
            var newsletter_id = myappmaster.find_id($(this).attr('id'));
            myappmaster.news.create_show_tab.init('Edit Newsletter');
            myappmaster.news.load(newsletter_id);
        });
        
        $('body').delegate('#save-newsletter-btn a', 'click', function(event) {
                var news = new Object();
                if($('#field-news-id').val() != '')
                {
                        news.id = $('#field-news-id').val();
                }
                news.subject = $('#field-news-subject').val();
                news.startdate = $('#field-news-start').val();
                news.enddate = $('#field-news-end').val();
                news.fromemail = $('#field-news-from-email').val();
                news.summary = $('#field-news-summary').val();
                news.news = tinyMCE.get('field-news-content').getContent();

                X4HNews.save_news_item(news);
                $('#edm-nav').tabs('select', '#edmNewsletters');
        });
        
    },
    save_news_item: function(news_item, callbackobj, callback, params) {
        
        if(callbackobj==undefined){
            callbackobj = X4HNews;
        }
        
        if(callback==undefined){
            callback = 'save_news_item_return';
        }
        
        $.each(news_item, function(key, value) {
            if(value == null) {
                value = "";
            }
            news_item[key] = value;
        });
        
        
        // APPLY DEFAULTS IF NECESSARY
        // Default: Tracking allnot a
        if(typeof (news_item.tracking) === undefined || parseInt(news_item.tracking) < 1) {
            news_item.tracking = 4;
        }
        
        // Default HTML Format
        if(typeof (news_item.format) !== undefined || parseInt(news_item.format) < 1) {
            news_item.format = 2;
        }
        
        var options = [callbackobj, callback];
        
        if(params!==undefined){
            options.push(params);
        }
        
        x4hubProxy.call(
            options, 
            '/ondemand/news/?method=NEWS_MANAGE',
            news_item
        );
    },
    save_news_item_return: function(response) {
		myappmaster.add_message('Newsletter has been saved.', 5);
        this.search(null, null, null, null, [{name: 'id', direction: 'asc'}]);
        if(response.notes=='ADDED'){
            myappmaster.news.save_news_group(response.notes.id,'add_selected_group_response')
        }
    },
    
    // START SEND NEWS ITEM
    /* indexes to track group saved */
    selected_group_length : 0, saved_group_length : 0,
    
    send_news_item: function(newsletter_id) {
        
        /* modifiying workflow */
        if($('input[name="field-news-sendto"]:checked').val()==undefined){
            alert('Please select an item');
        }
        else if($('input[name="field-news-sendto"]:checked').val()!=1){
            var conf_send = confirm("Do you really want to send this newsletter?");
            
            if(conf_send) {
                /* save the news */
                if($('#field-news-subject').val()==''){
                    alert('Please add news details');
                }else{
                    var news = new Object();
                    if($('#field-news-id').val() != '')
                    {
                            news.id = $('#field-news-id').val();
                    }
                    news.subject = $('#field-news-subject').val();
                    news.startdate = $('#field-news-start').val();
                    news.enddate = $('#field-news-end').val();
                    news.fromemail = $('#field-news-from-email').val();
                    news.summary = $('#field-news-summary').val();
                    news.news = tinyMCE.get('field-news-content').getContent();
                    
                    
                    /* reset first */
                    myappmaster.news.selected_group_length = 0;
                    myappmaster.news.saved_group_length = 0;
                    /* get the length */
                    $.each(myappmaster.news.selected_groups,function(key,group){

                        if(group!==undefined){
                            myappmaster.news.selected_group_length+=1;
                        }

                    });
                        
                    /* Send to group */ 
                    if($('input[name="field-news-sendto"]:checked').val()==3){
                        

                        if(myappmaster.news.selected_group_length==0){
                            alert('Please select a group');
                        }else{
                            myappmaster.news.save_news_item(news, myappmaster.news, 'save_news_item_from_send');

                        }
                    }
                    
                    //All users
                    else if($('input[name="field-news-sendto"]:checked').val()==2){
                        //Remove the groups and send
                        myappmaster.news.save_news_item(news, myappmaster.news, 'save_news_item_from_send_all');
                        
                        
                    }
                }
            }
            
        }
    },
    
    save_news_group : function(news_id,callback){
        
        
        /* save each item */
        $.each(myappmaster.news.selected_groups,function(key,group){
                        
            myappmaster.news.add_newsletter_group(news_id, key, myappmaster.news, callback)
        });
                    
    },
    
    remove_news_group : function(news_id,callback){
        /* remove news item for save */
        /* save each item */
        $.each(myappmaster.news.selected_groups,function(key,group){
                        
            myappmaster.news.remove_newsletter_group(news_id, key, myappmaster.news, callback)
        });
    },
    
    saved_news : null,
    
    save_news_item_from_send : function(response,params){
        if(response.notes=='ADDED' || response.notes=='UPDATED'){
            
                myappmaster.news.saved_news = response.id;
                myappmaster.news.save_news_group(response.id,'add_send_selected_group_response')
            
            
        }
    },
    
    save_news_item_from_send_all : function(response,params){
        if(response.notes=='ADDED'){
            
            myappmaster.news.saved_news = response.id;
            myappmaster.news.send_added_news_item(myappmaster.news.saved_news);
            
        }else if(response.notes=='UPDATED'){
            myappmaster.news.saved_news = response.id;
            if(myappmaster.news.selected_group_length==0){
                
                myappmaster.news.send_added_news_item(myappmaster.news.saved_news);
            }else{
                myappmaster.news.remove_news_group(response.id,'remove_group_send_all_response')
            }
        }
    },
    
    
    
    add_selected_group_response : function(response){
        
    },
    
    add_send_selected_group_response : function(response){
        if(response.notes=='ADDED'){
            var newsletter_id = myappmaster.news.saved_news;
            myappmaster.news.saved_group_length+=1;
            if(myappmaster.news.selected_group_length==myappmaster.news.saved_group_length){
                myappmaster.news.send_added_news_item(newsletter_id);
            }
        }
    },
    
    remove_group_send_all_response : function(response){
        if(response.notes=='REMOVED'){
            var newsletter_id = myappmaster.news.saved_news;
            
            myappmaster.news.selected_group_length-=1;
            if(myappmaster.news.selected_group_length==0){
                myappmaster.news.send_added_news_item(newsletter_id);
                
            }
        }
    },
    
    
    send_added_news_item : function(news_id){
        
        x4hubProxy.call(
            [myappmaster.news, 'send_news_item_return'], 
            '/ondemand/news/?method=NEWS_SEND',
            {
                id: news_id
                //preview: 1
            }
        );
    },
    
    send_news_item_return: function(response) {
        myappmaster.add_message('Newsletter has been sent.', 5);
    },
    // END SEND NEWS ITEM
    
    prefill_tab: function(response, container) {        
        //console.log(response);
        if(response.data.rows.length == 1) {
            var news = response.data.rows[0];
            
            // Replace HTML entities
            $.each(news, function(k, v) {
                news[k] = myappmaster.html_decode(v);
            });
            
            
            var startdate = new Date(news.startdate.replace(/\s\d\d:\d\d:\d\d/g, ''));
            var enddate = new Date(news.enddate.replace(/\s\d\d:\d\d:\d\d/g, ''));
            
            startdate = ((startdate=='Invalid Date')?'':startdate);
            enddate = ((enddate=='Invalid Date')?'':enddate);
            
            

            // Set the field values
            $('#field-news-id').val(news.id);
            $('#field-news-subject').val(news.subject);            
            
            // Ensure dates are valid before we prefill them
            if(myappmaster.validate_date(startdate)) {
                $('#field-news-start').val($.datepicker.formatDate('dd/mm/yy', startdate));
            }
            
            if(myappmaster.validate_date(enddate)) {
                $('#field-news-end').val($.datepicker.formatDate('dd/mm/yy', enddate));
            }
            $('#field-news-from-email').val(news.fromemail);
            $('#field-news-summary').val(news.summary);            
            $('#field-news-content').val(myappmaster.html_decode(news.news));            
                        
            myappmaster.news.selected_news = news;
            myappmaster.news.tracking.init(myappmaster.news.selected_news);
            
            myappmaster.news.get_selected_groups(news.id, true);
                   
			//Show the tab
			$('#edm-nav').tabs('select', '#edmCreateNewsletter');
			
			X4HNews.add_news_tinymce();   
        } else {
            // Clear them all            
            //this.clear_modal();
            myappmaster.news.tracking.init(myappmaster.news.selected_news);
        }
        
        //this.show_modal();
    },
    clear_modal: function() {
        $('#field-news-id').val("");
        $('#field-news-subject').val("");
        $('#field-news-start').val("");
        $('#field-news-end').val("");
        $('#field-news-from-email').val("");
        $('#field-news-summary').val("");
        $('#field-news-content').val("").html("");
        $('#field-news-send-to-none').attr('checked', 'checked');
        $('#newsletter-select-groups').hide();
             
        X4HNews.add_news_tinymce();    
        
        // Reset the tabs
        $( "#newsletter-manage-screen .tabs" ).tabs('select', 0);
        $('.grouplist').find('option').remove().end();
    },
    	
	create_show_tab: {
		init : function(tabType) {
			var compose_newsletter_panel = '';
			$('#edm-nav').tabs("add","#edmCreateNewsletter",tabType);
			compose_newsletter_panel = $('#edm-nav').find("#edmCreateNewsletter");
			compose_newsletter_panel.addClass("tabbed-section");	
			$('#edm-panel').append(compose_newsletter_panel);
			
			//Now build the content for the panel
			compose_newsletter_panel.append('<div class="tabbed-content-header">'  
			+	'<input type="hidden" id="field-news-id"/>' 
			+	'<div class="tabbed-content-header-options" id="save-newsletter-btn">' 
            +       '<a class="save-newsletter" href="#">Save Newsletter</a>' 
			+	'</div>'                                             
            +'</div>'
			+ '<div id="edm_create_tabs">'  
			+	'<ul>'                    
			+		'<li><a href="#newsDetails"><span>Details</span></a></li>'
            +       '<li><a href="#newsSendTo" class="newsGroups"><span>Send To</span></a></li>'
            +       '<li><a href="#newsTracking" class="newsTracking"><span>Tracking</span></a></li>'
            +   '</ul>'
			+ '<div id="news-panel">'
			+    '<div id="newsDetails" class="tabbed-section">'
            +        '<div class="column">'
            +            '<div class="form-row">'
            +                '<label for="field-news-subject">Title:</label>'
            +                '<input type="text" id="field-news-subject" />'
            +            '</div>'
			+			'<div class="form-row">'
			+				'<label for="field-news-from-email">From:</label>'
            +                '<input type="text" id="field-news-from-email" />'
            +            '</div>'
            +            '<div class="form-row">'
			+				'<label for="field-news-start">Start:</label>'
            +                '<input type="text" id="field-news-start" class="datepicker" />'
            +            '</div>'
            +            '<div class="form-row">'
            +                '<label for="field-news-end">End:</label>'
			+				'<input type="text" id="field-news-end" class="datepicker" />'
            +            '</div>'
            +        '</div>'
            +        '<div class="column">'
            +            '<label for="field-news-summary">Summary</label><br/>'                                        
            +            '<textarea id="field-news-summary"></textarea>'
            +        '</div>'
            +        '<div style="clear: both;">&nbsp;</div>'
            +        '<textarea id="field-news-content"></textarea>'
            +    '</div>'
			+'<div id="newsSendTo" class="tabbed-section">'
            +    '<h2>Send Newsletter To:</h2>'
            +    '<p>Select which users in the system will receive this newsletter</p>'
            +    '<p><input type="radio" id="field-news-send-to-none" name="field-news-sendto" value="1"/>None</p>'
            +    '<p><input type="radio" id="field-news-send-to-all" name="field-news-sendto" value="2"/>All Users</p>'
			+	 '<p><input type="radio" id="field-news-send-to-group" name="field-news-sendto" value="3" onclick=""/>Select Groups</p>'
            +    '<div id="newsletter-select-groups" style="display:none;">'
            +    	'<div class="column">'
            +       '<h4>Available Groups</h4>'
            +       	'<div id="newsletter-available-groups">'
            +           	'<select id="list-newsletter-available-groups" class="grouplist" size="10"></select>'
            +           '</div>'
            +           '<button class="list-newsletter-available-groups-add">Add Group ></button>'
            +       '</div>'
            +       '<div class="column">'
            +       '<h4>Selected Groups</h4>'
            +       	'<div id="newsletter-selected-groups">'
            +           	'<select id="list-newsletter-selected-groups" class="grouplist" size="10"></select>'
            +           '</div>'
            +           '<button class="list-newsletter-available-groups-remove">< Remove Group</button>'
            +       '</div>'
            +       '<div style="clear: both;"></div>'
            +    '</div>'
            +    '<div id="newsletter-send-control">'
            +    	'<button id="send-newsletter-button">Send Email</button>'
            +    '</div>'
            +'</div>'
			+'<div id="newsTracking" class="tabbed-section">'
            
            +    '</div>'
			+'</div>');
			
            $('#edm_create_tabs').tabs({
                show : function(event, ui){
                    if(ui.index==2){//Tracking
                        console.log('Loading News Tracking');
                        //console.log(myappmaster.news.selected_news)
                        myappmaster.news.tracking.init(myappmaster.news.selected_news);
                    }
                }
            });

            $('.datepicker').datepicker({
                    dateFormat: 'dd/mm/yy'
            });
            $('#edm-nav').tabs('select', '#edmCreateNewsletter');    
            X4HNews.add_news_tinymce();
                        
           /* since this is a new tab, bind the controls separately */             
           this.bind_element_triggers();             
        },
        
        bind_element_triggers : function(){
            // Add/Remove groups
            $( '.list-newsletter-available-groups-add').button({}).click(function() {            
                var group_id = $('#list-newsletter-available-groups option:selected').val();
                var newsletter_id = $('#field-news-id').val();
                myappmaster.news.selected_groups[group_id] = myappmaster.news.available_groups[group_id];
                //myappmaster.news.populate_groups();
                myappmaster.news.add_newsletter_group(newsletter_id, group_id);            
            });
        
            $( '.list-newsletter-available-groups-remove').button({}).click(function() {
                var group_id = $('#list-newsletter-selected-groups option:selected').val();
                var newsletter_id = $('#field-news-id').val();
                
                delete myappmaster.news.selected_groups[group_id];
                //myappmaster.news.populate_groups();
                myappmaster.news.remove_newsletter_group(newsletter_id, group_id);
            });
        
            // Show/Hide Newsletter Groups
            $('input[name="field-news-sendto"]').change(function(){           
                // Show groups for newsletter
                if($(this).val() != '3') {
                    // Hide the div holding the groups
                    $('#newsletter-select-groups').hide();
                } else {
                    myappmaster.news.create_show_tab.prepopulate_group();
                    $('#newsletter-select-groups').show();
                }
            });
        
            // Send a newsletter
            $('#send-newsletter-button').button({}).click(function(){
                var newsletter_id = $('#field-news-id').val();
                myappmaster.news.send_news_item(newsletter_id);
            });
		
            
        },
        
        prepopulate_group : function(){
            if($('#field-news-id').val()==''){
                myappmaster.news.available_groups = {};
                myappmaster.news.selected_groups = {};
            }
            myappmaster.news.get_groups(this, 'prepopulate_group_response')
            
        },
        
        prepopulate_group_response : function(response){
            
            if(response.data.rows.length>0){
                $.each(response.data.rows,function(key,row){
                    myappmaster.news.available_groups[row.id] = row.title;
                });
            }
            myappmaster.news.populate_groups();
        }
    },
	subscribers : {
        news_subscribers : [],
        load_subscribers : function(){
            var subscribers = this;
            subcribers.get_subcribers();
        },
        get_subscribers : function(){
            var subscribers = this;
            //search for news and their groups
            //Clear ajax queue
            ajaxQueue.clearQueue();
            ajaxQueue.stop();
            //console.log(myappmaster.news.current_news_list)
            $.each(myappmaster.news.current_news_list,function(key,news){
                x4hubProxy.call_queued(
                [subscribers, 'load_subscribers_count',{news:news.id}],
                '/ondemand/news/?method=NEWS_CONTACT_PERSON_SEARCH',
                {
                        id : news.id,
                        rows : 100
                }
                );
            });
        },
        
        load_subscribers_count : function(response,params){
            //var news = {};
            var subscribers = this;
            if(response.data.rows.length>0){
                var news = {
                    id : params.news,
                    subscribers : response.data.rows,
                    subscribers_count : response.data.rows.length
                }
                
                //cache the result
                this.news_subscribers.push(news);
                
                var subscribers_link = $(
                    '<span>'
                    +'<a href="#" id="view-subscribers-'+news.id+'" class="subscribers-link" title="View Subscribers"><strong>'+news.subscribers_count+'</strong></a>'
                    +'</span>'    
                );
                
                //change value
                $('#newsletter-subscribers-'+params.news).html(subscribers_link);
                
                //bind details link
                $('#view-subscribers-'+news.id).click(function(){
                    subscribers.show_subscribers(news);
                });
            }
        },
        
        show_subscribers : function(news){
            //console.log(news);
            
            //create a new tab
            $( "#edm-nav").tabs("add","#subscribersList","Subscribers");
            var subscribers_list = $('#edm-nav').find("#subscribersList");
            subscribers_list.addClass("tabbed-section");
            $('#edm-panel').append(subscribers_list);
            $('#edm-nav').tabs('select', $('#edm-nav').tabs("length")-1);
            
            var header = $(
                '<div class="tabbed-content-header"><h1>Subscribers List</h1></div>'
            );
                
            var news_header = $(
                '<div class="tabbed-content-search">'
                +'<div class="subscribers-label"><strong>Subject:</strong> '+myappmaster.news.current_news_list[news.id].subject+'</div>'
                +'<div class="subscribers-label"><strong>From:</strong> '+myappmaster.news.current_news_list[news.id].fromemail+'</div>'
                +'<div class="subscribers-label"><strong>Summary:</strong> '+myappmaster.news.current_news_list[news.id].summary+'</div>'
                +'</div>'
            );
                
            var contact_list = $(
                '<div class="tabbed-content-body">'
                +'</div>'
            );
                
            $.each(news.subscribers,function(key,subscriber){
                var contact_row = $(
                           
                    '<div class="contact-person-info">'
                    +'    <div class="contact-person-pic"><img src = "/assets/images/avatar06.png" class="contact-profile-img" id="contact-profile-img-'+subscriber.id+'" width="50" height="50" /></div>' /** TODO: Update image for multiple contacts **/

                    +'    <span  id = "contact-row-name-'+subscriber.id+'"><strong>'+subscriber.firstname+'&nbsp'+subscriber.surname+'</strong></span>'
                    +'    <span  id = "contact-person-email">'+subscriber.email+'</span>'

                    
                    +'</div>'
                    
                    
                           
                );
                
                contact_list.append(contact_row)
                    
                if(key + 1 < news.subscribers_count) {
                            
                    contact_list.append('<div class="contact-person-line"></div>');
                }    
                    
            });    
                
            $('#subscribersList').append(header);
            $('#subscribersList').append(news_header);
            $('#subscribersList').append(contact_list);
            
            myappmaster.news.change_image('contact-profile-img','contact-profile-img');
        }
    },
	add_news_tinymce: function()
	{
		tinyMCE.execCommand('mceAddControl', true, 'field-news-content');
		var tmp_instance = tinyMCE.get('field-news-content');
		if(tmp_instance != undefined) {
			tmp_instance.setContent($('#field-news-content').val());
		}
	},
        
   //added to handle images for subscribers
   change_image  : function(target_class, target_item){
        ajaxQueue.clearQueue();
        ajaxQueue.stop();
        $('.'+target_class).each(function(key,img){
            var contact_id = myappmaster.find_id($(this).attr('id'));
            //console.log(contact_id);
            x4hubProxy.call_queued(
                [myappmaster.news, 'change_image_response',{contact_id:contact_id,target_item: target_item}],
                '/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
                {
                        object: 32,
                        objectcontext:contact_id,
                        type: 260 //Profile Attachment type
                }
            );
        });
    },
    
    change_image_response : function(response,params){
	    if(response.data.rows.length>0){
           //var contact_image = response.data.rows[0];
           var attachment = response.data.rows[0];
           var contact_image_uri = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + attachment.id + '&sid=' + x4hubProxy.sid + '&attachment=' +attachment.attachment;
           
           $('#'+params.target_item+'-'+params.contact_id).attr('src',contact_image_uri);
        }
    },
    
    get_contact_group_members : function(group){
        x4hubProxy.call_queued(
            [myappmaster.news, 'get_contact_group_members_response',{group : group}],
            '/ondemand/contact/?method=CONTACT_PERSON_GROUP_SEARCH',
            {
                    group: group.id,
                    rows : 1000
            }
        );
    },
    
    get_contact_group_members_response : function(response, params){
        if(response.data.rows.length > 0){
            var members = response.data.rows.length;
            $('#contact-group-row-' + params.group.id +' .contact-group-members span').html(members);
            
            myappmaster.news.group_contacts[params.group.id] = response.data.rows;
            
        }else{
            $('#contact-group-row-' + params.group.id +' .contact-group-members span').html(0);
            
            myappmaster.news.group_contacts[params.group.id] = [];
        }
    },
    
    create_contact_group : function(title){
        x4hubProxy.call(
        [myappmaster.news, 'create_contact_group_response'],
        '/ondemand/setup/?method=SETUP_CONTACT_PERSON_GROUP_MANAGE',
        {
            title : title
        }
        );
    },
    
    create_contact_group_response : function(response,params){
        if(response.notes == 'ADDED'){
            myappmaster.add_message('New Contact Group has been added.', 5);
            myappmaster.news.get_groups();
        }else if(response.notes == 'UPDATED'){
            myappmaster.add_message('Contact Group has been updated.', 5);
            $('#preloader-edm-contact-group').hide();
            
        }
    },
    
    contact_groups : {
        header : $(
            '<div id="edm-contact-group-header"  class="tabbed-content-header">'
            
            +    '<h1>Contact Group Details</h1>'
            +'</div>' 
        ),
            
        search : $('<div class="tabbed-content-search" id="edm-contact-group-title"></div>'),
            
        content : $(
            '<div class="tabbed-content-body">'
            +'<div id="edm-contact-group-detail">'
            
            +'</div>'
            +'</div>'
        ),
            
        footer : $(
            '<div id="edm-contact-group-footer">'
            
            
            +'</div>'
        ),
            
        //selected_group_contacts : [],    
            
        show : function(group_id, type){console.log(type)
            var contact_groups = this;
            
            /* create tab for group contacts - if they don't exist yet */
            if($( "#edm-nav").find('a[href=#edmContactgroups]').length==0){
                $('#edm-nav').tabs("add","#edmContactgroups","Contact Group");
            
            var contact_group_panel = $('#edm-nav').find("#edmContactgroups");

            contact_group_panel.addClass("tabbed-section");

            $('#edm-panel').append(contact_group_panel);
            
            contact_group_panel.append(this.header);

            
            
            
            
            if(type=='details'){
                this.search.html('<h1>Group name: '+myappmaster.news.available_groups[group_id]+'</h1>');
                
                /* remove the add button */
                $('#edm-contact-group-header-options').remove();
                
            }else if(type=='edit'){
                var group_edit = $(
                    '<div id="edm-contact-group-info-'+group_id+'">'
                    +'<label>Group Name: </label><input type="text" id="edm-contact-group-name-input" value="'+myappmaster.news.available_groups[group_id]+'"/>'
                    +'<input type="button" value="Save" id="edm-contact-group-name-save"/>'
                    +'</div>'
                );
                
                this.search.html(group_edit);
                
                /* add contact to group (only if admin) */
                /* if user is an admin, allow edit */
                if(myappmaster.users.details.systemadmin!==undefined&&myappmaster.users.details.systemadmin=="true"){
                    var header_option = $(
                        '<div id="edm-contact-group-header-options">'
                        +'    <span><a href="#" class="edm-contact-group-add" id="edm-contact-group-add-'+group_id+'">Add Contact</a></span>'
                        +' </div>'
                    );
                        
                        
                    /* add and bind if it does not exists */        
                    if(this.header.find('#edm-contact-group-header-options').size()==0){
                        this.header.find('h1').before(header_option);
                    }

                        /* bind add contact to group */
                        if( $('.edm-contact-group-add').data('events')==undefined)
                        $('.edm-contact-group-add').click(function(){
                            //contact_groups.selected_group = group_id;
                            contact_groups.add_contact(group_id);
                        });

                    //}
                }
            }
            
            
            
            contact_group_panel.append(this.search);
            
            contact_group_panel.append(this.content);
            
            /* bind save */
            $('#edm-contact-group-name-save').button({
                create : function(){
                    $(this).click(function(){
                        if($('#edm-contact-group-name-input').val()==''){
                            alert('Please enter a group name.');
                        }else{
                            var group_id = myappmaster.find_id($(this).parent().attr('id'));
                            //console.log(myappmaster.find_id($(this).parent().attr('id')));
                            
                            var preloader = $(
                            '<div id="preloader-edm-contact-group">'
                            +'<span><img src="/assets/images/preloader2.gif" />&nbsp; saving</span>'
                            +'</div>'
                            );
                            
                            var title = $('#edm-contact-group-name-input').val();
                            
                            if($('#edm-contact-group-info-'+group_id).find($('#preloader-edm-contact-group')).size()==0){
                            $('#edm-contact-group-info-'+group_id).append(preloader);
                            }else{
                                $('#preloader-edm-contact-group').show();
                            }
                            
                            
                            
                            x4hubProxy.call(
                            [myappmaster.news, 'create_contact_group_response',{title : title}],
                            '/ondemand/setup/?method=SETUP_CONTACT_PERSON_GROUP_MANAGE',
                            {
                                title : title,
                                id : group_id
                            }
                            );
                            
                        }
                    });
                }
            });
            
            }
            
            $('#edm-nav').tabs('select', "#edmContactgroups");
            
            this.load_group_contacts(group_id, type);
        },
        
        load_group_contacts : function(group_id,type){
            var contact_groups = this;
            
            $('#edm-contact-group-detail').html('');
            
            if(myappmaster.news.group_contacts[group_id].length>0){
                $.each(myappmaster.news.group_contacts[group_id],function(key,contact){
                    
                    /* if user is an admin, allow remove from group */ 
                    if(myappmaster.users.details.systemadmin!==undefined&&myappmaster.users.details.systemadmin=="true" && type=='edit'){
                        var remove_from_group = '<span  id = "remove-from-group-'+contact.id+'" class="remove-from-group">Remove from group</span>';
                    }else{
                        remove_from_group = '';
                    }
                    var contact_row = $(

                        '<div class="contact-person-info" id="contact-person-group-'+contact.id+'">'
                        +'    <div class="contact-person-pic"><img src = "/assets/images/avatar06.png" class="edm-contact-profile-img" id="edm-contact-profile-img-'+contact.contactperson+'" width="50" height="50" /></div>' /** TODO: Update image for multiple contacts **/

                        +'    <span  id = "contact-row-name-'+contact.contactperson+'"><strong>'+contact.contactpersonfirstname+'&nbsp'+contact.contactpersonsurname+'</strong></span>'
                        +remove_from_group


                        +'</div>'



                    );

                    $('#edm-contact-group-detail').append(contact_row)

                    if(key + 1 < myappmaster.news.group_contacts[group_id].length) {

                        $('#edm-contact-group-detail').append('<div class="contact-person-line"></div>');
                    }    

                });
                
                $.each($('.remove-from-group'),function(key,elem){
                    $(elem).click(function(){
                        var contact_group_id = myappmaster.find_id($(elem).attr('id'));
                        //console.log(contact_group_id);
                        var msg = confirm('Are you sure you want to remove this contact from this group?');
                        
                        if(msg){
                            
                            /* remove from list */
                            if($('#contact-person-group-'+contact_group_id).next().attr('class')=='contact-person-line'){
                                $('#contact-person-group-'+contact_group_id).next().remove();
                            }
                            $('#contact-person-group-'+contact_group_id).remove();
                            
                           
                            if($('#edm-contact-group-detail').find('.contact-person-info').size()==0){
                                $('#edm-contact-group-detail').html('<p>This group has no contacts.</p>')
                            }else if($('#edm-contact-group-detail').find('.contact-person-info').size()==1){
                                $('.contact-person-line').remove();
                            }
                            
                            
                            /* remove from cache */
                            $.each(myappmaster.news.group_contacts[group_id],function(key,contact){
                                if(contact.id==contact_group_id){
                                    myappmaster.news.group_contacts[group_id].splice(key,1);
                                    return false;
                                }
                            });
                            
                            myappmaster.contacts.remove_contact_from_group(contact_group_id,{
                               callbackobj :  contact_groups,
                               callback : 'remove_contact_from_group_response'
                               //group_id : group_id
                            });
                        }
                        
                        
                    });
                });
                
                myappmaster.news.change_image('edm-contact-profile-img','edm-contact-profile-img');
            }else{
                $('#edm-contact-group-detail').html('<p>This group has no contacts.</p>')
            }
            
            
            
            
        },
        
        add_contact : function(group_id){
            var contact_groups = this;
            if($( "#edm-nav").find('a[href=#edmAddcontact]').length==0){
                $('#edm-nav').tabs("add","#edmAddcontact","Add Contact");

                var add_contact_panel = $('#edm-nav').find("#edmAddcontact");

                add_contact_panel.addClass("tabbed-section");

                $('#edm-panel').append(add_contact_panel);
            

            
            
            var add_contact_header = $(
                '<div class="tabbed-content-header">'
            
                +    '<h1>Add Group Contact</h1>'
                +'</div>'
            );
                
            var add_contact_search = $(
                '<div id="edm-add-group-contact-search" class="tabbed-content-search">'
                +'<div id="edm-contacts-search">'
                +'                                <input type="text" id="edm-contacts-filter"/>'
                +'                                <form>'
                +'                                    <div>'
                +'                                        <select id="edm-contacts-search-dropdown" name="search" >'
                +'                                            <option value="all" selected=selected>All</option>'
                +'                                            <option value="firstname">First Name</option>'
                +'                                            <option value="surname">Last Name</option>'
                +'                                            <option value="email">Email</option>'
                +'                                            <option value="contactbusinesstext">Company</option>'
                +'                                            <option value="workphone">Phone Number</option>'
                +'                                        </select>'
                +'                                    </div>'
                                                        
                +'                                </form>'
                +'                                <a href="#" id="edm-contact-search-btn"><img src="/assets/images/search-btn01.png" /></a>'
                +'                            </div>'
                +'</div>'
            );
                
            var add_contact_content = $(
                '<div class="tabbed-content-body" id="edm-contact-list">'
                
                +'</div>'
            );    
            
            var add_contact_footer = $(
                '<div class="contact-footer" id="edm-contact-footer" style="border-top:none;">'
                +'<div class="pagination-area" id="edm-contact-list-pagination"></div>'
                +'</div>'
            );
            
            var preloader = $(
                '<div id="preloader-news-group">'
                +'<span><img src="/assets/images/preloader.gif" /><br  />loading</span>'
                +'</div>'
            );
            
            
            add_contact_panel.append(add_contact_header);
            add_contact_panel.append(add_contact_search);
            add_contact_panel.append(add_contact_content);
            add_contact_panel.append(add_contact_footer);
            
            add_contact_content.html(preloader);
            
            $('#edm-contacts-search-dropdown').each(function(){
                var title = $(this).attr('title');
                if( $('option:selected', this).val() != ''  ) title = $('option:selected',this).text();
                $(this)
                    .css({'z-index':10,'opacity':0,'-khtml-appearance':'none'})
                    .after('<span id = "edm-contacts-search-span">' + title + '</span>')
                    .change(function(){
                        val = $('option:selected',this).text();
                        $(this).next().text(val);
                });
            });
            
            
            
            /* make sure this has not been added yet */
            /*var exclude_contact = [];
            
            if(myappmaster.news.group_contacts[group_id].length>0){
                $.each(myappmaster.news.group_contacts[group_id],function(key,contact){
                    exclude_contact.push(contact.contactperson)
                });
            }*/
            
            /* contact filter */
            /*var filter = [{
                    name: 'id',
                    comparison : 'NOT_IN_LIST',
                    value : exclude_contact
            }];*/
            }
            
            $('#edm-nav').tabs('select', "#edmAddcontact");
            
            myappmaster.contacts.search(null,null,null,null, 'load_contacts', {
               callbackobj : contact_groups,
               container : 'edm-contact-list',
               group_id : group_id
            });
        },
        
        load_contacts : function(response,params){
            var contact_groups = this;
            
            $('#edm-contact-list').html('');
            $('#edm-contact-pagination').html('');
            
            if(response.data.rows.length>0){
                
                //var contact_row = '';
                $.each(response.data.rows, function(key,row){
                    contact_groups.group
                    if(row.sq6965!==undefined&&row.sq6965 != '')
                    {
                        var sProfileImage = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + row.sq6965 + '&sid=' + x4hubProxy.sid;
                    }else{
                        sProfileImage = '/assets/images/avatar06.png';
                    }
                    
                    var contact_row =$( '<div id="contact-row-' + row.id + '" class="contacts-row edm-contact-row">'
                    + '    <div class="contact-info-pic">'
                    + '        <img src="' + sProfileImage + '" width="50" id="edm-contact-' + row.id + '" class="contact-profile-img" />'                     
                    + '    </div>'
                    + '    <div class="contact-info-details">'
                    + '        <span id="contact-row-name-' + row.id + '" style="font-weight: bold;">' + row.firstname + ' ' + row.surname + '</span></br>'
                    + '        <span id="contact-row-company-' + row.id + '">Company: ' + row.contactbusinesstext + '</span></br>'
                    + '        <span id="contact-row-position-' + row.id + '">Position: ' + row.position + '</span></br>'
                    + '    </div>'
                    + '    <div class="contact-info-personal">'
                    + '        <span id="contact-row-phone-' + row.id + '">Phone: ' + (row.workphone == '' ? '&nbsp;' : row.workphone) + '</span></br>'
                    + '        <span id="contact-row-email-' + row.id + '">Email: ' + (row.email == '' ? '&nbsp;' : row.email) + '</span></br>'
                    + '        <span id="contact-add-to-group-' + row.id + '" class="contact-add-to-group">Add to group</span>'
                    + '    </div>'


                    + ' </div>');
                
                    $('#edm-contact-list').append(contact_row);
                    
                     //check if the profile image did load
                    $('#contact-row-'+row.id+' div img').error(function() {
                        //change to default image
                        $(this).attr('src','/assets/images/avatar06.png');

                    });
                    
                    if(key + 1 < response.data.rows.length) {
                    $('#edm-contact-list').append($('<div class="company-person-line"></div>'));
                    
                }
                    
                });
                
                /* bind add to group */
                $.each($('.edm-contact-row'),function(key,elem){
                    $(elem).find('.contact-add-to-group').click(function(){
                       var contact_id = myappmaster.find_id($(elem).attr('id'));
                       
                       /* make sure this has not been added yet */
                       var contact_exists = false;
                       
                       if(myappmaster.news.group_contacts[params.group_id].length>0){
                            $.each(myappmaster.news.group_contacts[params.group_id],function(key,contact){
                                if(contact.contactperson==contact_id)
                                contact_exists = true;
                                //console.log(contact.contactperson)
                            });
                       }
                       
                       if(!contact_exists){
                           //console.log(myappmaster.news.group_contacts[params.group_id]);
                           myappmaster.news.group_contacts[params.group_id].push({
                              contactperson : contact_id,
                              group : params.group_id
                           });
                           myappmaster.contacts.add_contact_to_group(contact_id, params.group_id,
                           {
                               callbackobj : contact_groups,
                               callback : 'add_contact_to_group_response',
                               contactname : ($('#contact-row-name-'+contact_id).text()!=''?$('#contact-row-name-'+contact_id).text():''),
                               contactid : contact_id,
                               contactimg : $('#edm-contact-'+contact_id).attr('src'),
                               groupid : params.group_id
                           })
                           
                       }else{
                           alert('This contact is already in the group.');
                       }
                    });
                });
                
                /* bind search */
                if( $('#edm-contact-search-btn').data('events')==undefined){
                $('#edm-contact-search-btn').click(function(){
                    var filter_option = $('#edm-contacts-search-dropdown').val();
                    var filter=null;
                    
                    //reset pagination
                    $('#edm-contact-list-pagination').html('');
                    
                    if(filter_option!=='all'){
                       var filter_text = $('#edm-contacts-filter').val();
                       filter = [{name:filter_option,comparison:'TEXT_IS_LIKE',value1: filter_text}]; 
                    }
                    
                    myappmaster.contacts.search(null,filter,null,null, 'load_contacts', {
                       callbackobj : contact_groups,
                       container : 'edm-contact-list',
                       group_id : params.groupid
                    });
                    
                });
                }
                
                
            }else{
               $('#edm-contact-list').html('<p>There are no contacts</p>'); 
            }
        },
        
        add_contact_to_group_response : function(response,params){
            var contact_groups = this;
            if(response.notes=='ADDED'){
                myappmaster.add_message('Contact has been added to group.', 5);
                
                
                /* add to added id to cache */
                $.each(myappmaster.news.group_contacts[params.groupid],function(key,contact){
                    if(contact.contactperson==params.contactid){
                        contact['id'] = response.id
                        
                        myappmaster.news.group_contacts[params.groupid][key]=contact;
                    }
                });
                
                /* then add to list of contacts */
                var contact_row= $(

                        '<div class="contact-person-info" id="contact-person-group-'+response.id+'">'
                        +'    <div class="contact-person-pic"><img src = "'+params.contactimg+'" class="contact-profile-img" id="contact-profile-img-'+params.contactid+'" width="50" height="50" /></div>'
                        +'    <span  id = "contact-row-name-'+params.contactid+'"><strong>'+params.contactname+'</strong></span>'
                        +'    <span  id = "remove-from-group-'+response.id+'" class="remove-from-group">Remove from group</span>'
                        +'</div>'
                );
                    
                if($('#edm-contact-group-detail').find('.contact-person-info').size()>0){
                   $('#edm-contact-group-detail').prepend('<div class="contact-person-line"></div>');
                   $('#edm-contact-group-detail').prepend(contact_row);
                   
                   
                                      
                   
                }else{
                    $('#edm-contact-group-detail').html(contact_row);
                }
                
                $('#remove-from-group-'+response.id).click(function(){
                        var contact_group_id = myappmaster.find_id($(this).attr('id'));
                        //console.log(contact_group_id);
                        var msg = confirm('Are you sure you want to remove this contact from this group?');
                        
                        if(msg){
                            
                            
                            /* remove from list */
                            if($('#contact-person-group-'+contact_group_id).next().attr('class')=='contact-person-line'){
                                $('#contact-person-group-'+contact_group_id).next().remove();
                            }
                            $('#contact-person-group-'+contact_group_id).remove();
                            
                           
                            if($('#edm-contact-group-detail').find('.contact-person-info').size()==0){
                                $('#edm-contact-group-detail').html('<p>This group has no contacts.</p>')
                            }else if($('#edm-contact-group-detail').find('.contact-person-info').size()==1){
                                $('.contact-person-line').remove();
                            }
                            
                            
                            /* remove from cache */
                            $.each(myappmaster.news.group_contacts[params.groupid],function(key,contact){
                                if(contact.id==contact_group_id){
                                    myappmaster.news.group_contacts[params.groupid].splice(key,1);
                                    return false;
                                }
                            });
                            
                            myappmaster.contacts.remove_contact_from_group(contact_group_id,{
                               callbackobj :  contact_groups,
                               callback : 'remove_contact_from_group_response'
                               //group_id : group_id
                            });
                        }
                        
                        
                });

            }
        },
        
        remove_contact_from_group_response : function(response){
            
        }
        
    },
    
    /* News tracking */
    tracking : {
        preloader : $(
        '<div id="preloader-edm-news-tracking">'
        +'<span><img src="/assets/images/preloader2.gif" />&nbsp; loading activities</span>'
        +'</div>'
        ),
            
        init : function(news){
            if(news==null){
                $('#newsTracking').html('<p>There are no News Tracking to display.</p>')
            }else{
                $('#newsTracking').html('');
                $('#newsTracking').append('<h2>'+news.subject+'</h2>');
                $('#newsTracking').append('<p>News tracking details: </p>');
                $('#newsTracking').append($('<div id="news-tracking-activities"></div>'));
                
                $('#news-tracking-activities').append(this.preloader);
                
                this.load_activities(news.id,this,'load_activities_response');
            }
        },
        
        load_activities : function(news_id,callbackobj, callback){
            
            x4hubProxy.call(
                [callbackobj, callback],
                '/ondemand/news/?method=NEWS_TRACKING_SEARCH',
                {
                    news: news_id,
                    rows: 100
                }
            );
        },
        
        load_activities_response : function(response){
            if(response.data.rows.length>0){
                
                $('#news-tracking-activities').html('');
                
                $.each(response.data.rows,function(key,row){
                    var activity_row = $(
                    '<div class="tracking-activity-row '+((key==0)?'top-row':'')+'">'
                    +'  <span>'
                    +'      <span class="activity-label"><strong>Date:</strong></span>'+row.datetime    
                    +'  </span><br/>'
                    +'  <span>'
                    +'      <span class="activity-label"><strong>Activity:</strong></span>'+row.activity
                    +'  </span><br/>'
                    +'  <span>'
                    +'      <span class="activity-label"><strong>Contact:</strong></span>'+row.contactpersontext
                    +'  </span><br/>'
                    +'  <span>'
                    +'      <span class="activity-label"><strong>Mail:</strong></span>'+row.contactpersonemail
                    +'  </span><br/>'
                    +'</div>'
                    );

                    $('#news-tracking-activities').append(activity_row);
                });
                
                
            }else{
                $('#news-tracking-activities').html('<p>There are no activities to display.');
            }
        }
    }
    
}