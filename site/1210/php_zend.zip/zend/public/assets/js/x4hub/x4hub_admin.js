var X4HAdmin = {
    object_id: 19,
    object_name: 'Setup',
    create_window: function() {
        
    },
    search: function(rows) {
        
    },
    list: function() {
        
    },
    user_list: function() {
        var uri = '';
        x4hubProxy.call(1
            [X4HNews, 'user_list_return', 'admin-main-list'], 
            '/ondemand/setup/?method=SETUP_USER_SEARCH',
            {
                rows: 10
            }
        );
    },
    user_list_return: function(response, container) {
		/*
        //console.log(response.data.rows.length + ' going into ' + container);
        if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                var row = $(
                    '<div id="user-row-' + row.id + '" class="user-row">'
                        + '<div class="admin-username">' + row.username + '</div>'
                        + '<div class="admin-options"><span id="user-edit-' + row.id + '" class="user-edit-anchor">Edit</span> / Disable</div>'
                        + 
                    '</div>'
                );
                
                $('#' + container).append(row);
            });
            this.bind_element_triggers();
        }*/
        
    },
    bind_element_triggers: function() {
        /*$.each( $( '.admin-edit-anchor' ), function(counter, elem) {
            $(elem).click(function() {
                // Find out the id of what we're dealing with
                var user_id = myappmaster.find_id($(elem).attr('id'));
                //console.log('Id: ' + id);
                
                /*x4hubProxy.call(
                    [X4HNews, 'prefill_modal'], 
                    '/ondemand/news/?method=NEWS_SEARCH',
                    {
                        id: news_id
                    }
                );

            });
        });*/
    }
       
}