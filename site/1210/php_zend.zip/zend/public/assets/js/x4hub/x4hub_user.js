var X4HUser = {
	monthNamesShort: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
    id: 0,
    first_name: null,
    last_name: null,
	name: null,
    email_primary: null,
	email_personal: null,
	contact_person: null,
	temp_contact_person: null, //Used in Profile Image updating
	email_sendfrom: null,
	address_street1: null,
	address_street2: null,
	address_suburb: null,
	address_state: null,
	address_postcode: null,
	address_country: null,
	mobile: null,
	is_admin: false,
	fax: null,
    role: null,
    phone: null,
    details: null,
	manager: null,
	iOnDemandTimerID: null,
	profile_image_uri: null,
    init: function(userData) {        
        this.id = userData.user;
        this.first_name = userData.firstname;
        this.last_name = userData.surname;
        this.email_primary = userData.email;
        this.contact_person = userData.contactperson;
        this.details = userData;
        
		/* ** CUSTOM LINKS MODULE **
		this.load_custom_links();
        */
		
		this.populate_extra_information();
		//Now populate the details
        this.populate_information_window();
		this.is_admin = userData.systemadmin;
		
		if(this.is_admin != 'false'){ $('#hiddenAdmin').fadeIn() }
		
		//Delegate Buttons
		$('body').delegate('.change-profile-password', 'click', function() {
			X4HUser.show_change_password_dialog();
		});
		
		//Bind Edit Link to Edit Button
		$('body').delegate('#user-link a, .edit-profile', 'click', function(event) {
            event.preventDefault();
            X4HUser.show_profile_tab();
		});
       
		$('body').delegate('a.edit-profile', 'click', function(event){
            event.preventDefault();
            X4HUser.show_profile_tab();
        });
                
        $('body').delegate('#save-profile', 'click', function(event) {
				var day = parseInt($('#field-profile-birthday').val());
				var month = $('#field-profile-birthmonth').val();
				myappmaster.users.save_profile({
					id: X4HUser.contact_person,
					phone: $('#field-profile-phone').val(),
					mobile: $('#field-profile-mobile').val(),
					email: $('#field-profile-email').val(),
					sq6856: $('#field-profile-linkedin').val(),
					sq6857: $('#field-profile-twitter').val(),
					sq6858: $('#field-profile-facebook').val(),
					sq6859: $('#field-profile-secondaryemail').val(),
					sq6860: $('#field-profile-tertiaryemail').val(),
					sq6861: $('#field-profile-personalemail').val(),
					sq6864: $('#field-profile-division').val(),
					jobtitle: $('#field-profile-positiontitle').val(),
					dateofbirth: $('#field-profile-birthday').val()
				});
		});
		
		//Bind Edit Link to add new Link
		$('body').delegate('.addlinkicon', 'click', function(event) {
			event.preventDefault();
			var urlid = '';
			var aLink = $(this).parent('td').attr('id').split('-');
			if(aLink[1] != undefined) { urlid = aLink[1]; }
			X4HUser.show_custom_link_modal(urlid);
		});
	},
	populate_extra_information: function()
	{
		//Must do a search for the contact record to find the other details
		X4HContacts.find(this.contact_person, 'set_extra_user_details');
		//Must do another search for the profile image attachment
		X4HUser.search_profile_image_field('set_profile_image');
	},
	
	/*show_bday: function()
	{
		x4hubProxy.call(
        [X4HUser, 'show_bday_response'],
         '/ondemand/contact/?method=CONTACT_PERSON_SEARCH');
	}
	show_bday_response: function(response)
	{
	
	}*/
	
	update: function() {
        
    },
    populate_information_window: function()
    {
		var sNameString = this.first_name + ' ' + this.last_name;
		this.name = sNameString;
	
		//console.log('populating ' + this.first_name);
        $('#user-info').append('<span  id = "user-info-name"><strong>You: </strong>' + sNameString + '</span><br />');
        $('#user-info').append('<span id = "user-info-title">&nbsp;</span><br />');
        $('#user-info').append('<span id = "user-info-email">' + this.email_primary + '</span><br />');
        $('#user-info').append('<span id = "user-info-phone">&nbsp;</span><br />');
        
		//Populate the other name on the other side of page
		$('.user-info-name').text(sNameString);
		
		
		/*
         * 
         *
         *  user-info
            <span style="font-size: 14px; color: #0d3558"><strong>You:</strong> Darren Jones<br /></span> 
            <span style="font-size: 11px; color: #5e5e5e">Chief Finance Officer<br /></span>
            <span style="font-size: 10px; color: #3278bf"><img src="/assets/images/email-img01.png" /> BobJones@xyzcorp.com<br /></span>
            <span style="font-size: 10px; color: #5e5e5e"><img src="/assets/images/phone-img01.png" /> 0416 234 567<br /></span>
        
            user-btns
            <a href="#"><img src="/assets/images/in-btn01.png" /></a>
            <a href="#"><img src="/assets/images/t-btn01.png" /></a>
            <a href="#"><img src="/assets/images/f-btn01.png" /></a>
        
            user-link
            <a href="#">Edit</a>
         */
    },
	load_custom_links: function()
	{
		x4hubProxy.call(
            [X4HUser, 'load_custom_links_response'],
            '/ondemand/setup/?method=SETUP_URL_SEARCH');
	},
	load_custom_links_response: function(response)
	{	
		var obj = response;
		if(obj.data.rows.length > 0) 
		{
			//Found some URL's
			$.each(response.data.rows, function(key, row) {
				var count = key+1;
				$('.mylink' + count).html('<span><a href="' + this.url + '" target="_blank" >' + this.title + '</a></span><img src="/assets/images/plus-img02.png" class="addlinkicon">');
				$('.mylink' + count).attr('id', 'mylink-' + this.id);
			})
		}
		else
		{
			console.log("No Custom Links Found");
		}
	},
	show_custom_link_modal: function(urlid)
	{
		//Build the Modal
		var aHTML = [];
		aHTML.push('<div>');
		aHTML.push('<span id="span-mycustomlink-id" style="display:none;">' + urlid + '</span>');
		
		aHTML.push('<div>');
		aHTML.push('<span>Title</span><input id="field-mycustomlink-title" /><br />');
		aHTML.push('<span>URL</span><input id="field-mycustomlink-url" />');
		aHTML.push('</div>');
		
		aHTML.push('</div>');
	
		$('.change-customlink-modal').html(aHTML.join(''));
		
		//Show the Modal
		$('.change-customlink-modal').dialog({
            title: "Add/Edit Custom Link",
            resizable: true,
            height: 400,
            width: 400,
            modal: true,
            buttons: {
					Cancel: function() {
						$(this).dialog( "destroy" );
					},
					Save: function() {
						X4HUser.save_custom_link();
						$(this).dialog( "destroy" );
					}
				}
			});	
	},
	save_custom_link: function()
	{
		var link = new Object();
		if($('#span-mycustomlink-id').text() == '') 
		{ 
			//Brand new Record
			link.title = $('#field-mycustomlink-title').val();
			link.url = $('#field-mycustomlink-url').val();
			link.type = '1'; //website
			x4hubProxy.call(
				[X4HUser, 'save_custom_link_response'],
				'/ondemand/setup/?method=SETUP_URL_MANAGE',
				link
			);
		}
		else
		{
			//Existing Record, Need to delete First
			link.id = $('#span-mycustomlink-id').text();
			link.remove = '1'
			x4hubProxy.call(
            [X4HUser, 'save_custom_link_delete_response'],
            '/ondemand/setup/?method=SETUP_URL_MANAGE',
			link
			);
		}
	},
	save_custom_link_delete_response: function(response)
	{
		$('#span-mycustomlink-id').text('');
		X4HUser.save_custom_link();
	},
	save_custom_link_response: function(response)
	{
		X4HUser.load_custom_links();
	},
	show_profile_tab: function() {
        //For a users profile, we need to get details from their user account, contact record, including attachments to their contact record to get the profile picture
		$('#field-profile-birthday').datepicker({
            dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			yearRange: 'c-90:c-0'
        });
		
		$('#save-profile').button({
			text: false,
			icons: {
				primary: "ui-icon-disk"
			},
			label: "Save"
		})
		
		$('.change-profile-password').button({
			label: 'Change Password'
		})	
		$('.profile-tab').show();
		$('#middle-nav').tabs('select', '#tab-profile');
		        		
		X4HUser.user_list();
		
		X4HUser.search_profile_fields();
		X4HUser.search_profile_image_field('populate_profile_image_field');
	},
	
	check_password: function() {
		var iFail = 0;
		$('.passwordrequired').each(function(index)
		{
			if($(this).val() != '')
			{
				
			}
			else
			{
				
				iFail = 1;
			}
		});
		
		if($('#field-profile-password-new').val() != $('#field-profile-password-new-confirm').val())
		{	
			
			iFail = 2;
		}
		
		if(iFail == 0)
		{
			return true;
		}
		else if(iFail == 1)
		{	
			alert('Please enter all details.');
			return false;
		}
		else if(iFail == 2)
		{	
			alert('Please ensure the new password and confirm password match.');
			return false;
		}
	},
	show_change_password_dialog: function() {
		$('.change-password-modal').dialog( "destroy" );
		//ShowChange Password Dialog
			var aHTML = [];
			aHTML.push('<div class="form-row">'
                    + '<label for="field-profile-password">Current Password:</label>'
                    + '<input type="password" class="passwordrequired" id="field-profile-password-current" />'
					+ '</div>');
			aHTML.push('<div class="form-row">'
                    + '<label for="field-profile-password">New Password:</label>'
                    + '<input type="password" class="passwordrequired" id="field-profile-password-new" />'
					+ '</div>');
			aHTML.push('<div class="form-row">'
                    + '<label for="field-profile-password">Confirm New Password:</label>'
                    + '<input type="password" class="passwordrequired" id="field-profile-password-new-confirm" />'
					+ '</div>');
			$('.change-password-modal').html(aHTML.join(''))
			$('.change-password-modal').dialog({
            title: "Change Password",
            resizable: true,
            height: 400,
            width: 400,
            modal: true,
            buttons: {
					Cancel: function() {
						$(this).dialog( "destroy" );
					},
					Save: function() {
						if(X4HUser.check_password())
						{
							X4HUser.change_user_password($('#field-profile-password-new-confirm').val(), $('#field-profile-password-current').val(), 360);
							$( this ).dialog( "destroy" );
						}
					}
				}
			});	
	},
	change_user_password: function(newpass, currentpass, expirydays) {
		x4hubProxy.call(
            [X4HUser, 'change_user_password_response'],
            '/ondemand/site/?method=SITE_USER_PASSWORD_MANAGE',
            {
                newpassword: newpass,
                currentpassword: currentpass,
				expirydays: expirydays, 
			}
		);
	},
	change_user_password_response: function(response) {
		var obj = response;
		if (obj.notes == 'UPDATED') 
		{
			myappmaster.add_message('Your password has been updated.', 5);
		}
		else
		{
			myappmaster.add_message('An error has occurred, Your password was not changed. Please try again.', 5);
		}
	},
	search_profile_fields: function() {
		 var oXML = "<advancedSearch>"
            + "<field><name>firstname</name></field>"
            + "<field><name>surname</name></field>"
            + "<field><name>email</name></field>"
			+ "<field><name>dateofbirth</name></field>"
            + "<field><name>homephone</name></field>"
            + "<field><name>workphone</name></field>"
			+ "<field><name>position</name></field>"
            + "<field><name>mobile</name></field>"
            + "<field><name>streetaddress1</name></field>"
            + "<field><name>streetaddress2</name></field>"
            + "<field><name>streetsuburb</name></field>"
            + "<field><name>streetstate</name></field>"
            + "<field><name>streetsuburb</name></field>"
            + "<field><name>streetcountry</name></field>"
            + "<field><name>streetpostcode</name></field>"
			+ "<field><name>sq6856</name></field>" //LinkedIn
			+ "<field><name>sq6857</name></field>" //Twitter
			+ "<field><name>sq6858</name></field>" //Facebook
			+ "<field><name>sq6859</name></field>" //Secondary Email
			+ "<field><name>sq6860</name></field>" //Tertiary Email
			+ "<field><name>sq6861</name></field>" //Personal Email
			+ "<field><name>sq6864</name></field>" //Division
			+ "<filter>"
            + "<name>id</name><comparison>EQUAL_TO</comparison><value1>" + X4HUser.contact_person + "</value1>"
            + "</filter>"
            + "<options><rf>JSON</rf><startrow>0</startrow><rows>1</rows></options>"
            + "</advancedSearch>";
        
        x4hubProxy.call(
            [X4HUser, 'populate_profile_fields'],
            '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
            {
                advanced: 1,
                data: oXML,
				//categoryid: 1172, //Messaging Information Category
            }
		);
	},
	populate_profile_fields: function(response) {
		var profile = response.data.rows[0]; 
		//Details that are attached to the contact record
		$('#field-profile-phone').val(profile.workphone);
		$('#field-profile-mobile').val(profile.mobile);
		$('#field-profile-positiontitle').val(profile.position);
		$('#field-profile-email').val(profile.email);
		
		//Extra Information
		$('#field-profile-linkedin').val(profile.sq6856);
		$('#field-profile-twitter').val(profile.sq6857);
		$('#field-profile-facebook').val(profile.sq6858);
		$('#field-profile-secondaryemail').val(profile.sq6859);
		$('#field-profile-tertiaryemail').val(profile.sq6860);
		$('#field-profile-personalemail').val(profile.sq6861);
		$('#field-profile-division').val(profile.sq6864);
		
		var oDate = $.fullCalendar.parseDate(profile.dateofbirth)
		$('#field-profile-birthday').val($.fullCalendar.formatDate(oDate, 'dd/MM/yyyy'));
		
		//Split the Date and Parse dateofbirth
		/*var aDob = profile.dateofbirth.split(' ');
		$('#field-profile-birthday').val(aDob[0]);
		$('#field-profile-birthmonth').val(aDob[1]);*/
	},
	search_profile_image_field: function(container) 
	{
		x4hubProxy.call(
            [X4HUser, container],
            '/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
            {
                object: 32, //Person Object
                objectcontext: this.contact_person,
				type: 260 //Profile Attachment type
            }
		);
	},
	set_profile_image: function(response)
	{
		if(response.data.rows.length > 0) 
		{
			var attachment = response.data.rows[0];
			X4HUser.profile_image_uri = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + attachment.id + '&sid=' + x4hubProxy.sid;
			//Insert the User-Pic
			$('#user-pic').html('<img width="34" height="34" src="' + this.profile_image_uri + '" />');
		}
		else
		{
			console.log("No Profile Pic Found");
		}
	},
	populate_profile_image_field: function(response)
	{
		if(response.data.rows.length > 0)
		{
			var attachment = response.data.rows[0];
			var uri = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + attachment.id + '&sid=' + x4hubProxy.sid;
			//alert(profile)
			$('#field-profile-picture').html('<div class="profile-image"><img width="35" height="35" src="' + uri +'" /><span class="changeprofileimage" id="del-' + attachment.attachment + '">&nbsp;</span></div>');
			$('.changeprofileimage').button({
				label: 'Change'
			})
			.click(function(event)
			{
				//Remove Attachment then show browse area
				var aAttach = $(this).attr('id').split('-');
				//X4HUser.remove_profile_image(aAttach[1]);		
				X4HUser.create_profile_upload(response, null, null, aAttach[1]);
			});
		}
		else
		{
			X4HUser.create_profile_upload(response);
		}
	},
	
	remove_profile_image: function(attachment)
	{
		x4hubProxy.call(
            [X4HUser, 'remove_profile_image_response'],
            '/ondemand/core/?method=CORE_ATTACHMENT_MANAGE',
            {
                id: attachment, 
                remove: 1
			}
		);
	},
	
	remove_profile_image_response: function(response)
	{
		myappmaster.add_message('Your profile image has been removed.', 5);
		$('.profile-image').remove();
	},
	
	create_profile_upload: function(response, container, contact, existing_profile_image)
	{
		if(container == null)
		{
			container = 'field-profile-picture';
		}
		if(contact == null)
		{
			this.temp_contact_person = this.contact_person;
		}
		else
		{
			this.temp_contact_person = contact;
		}
		$('#' + container).html('<form name="frmonDemandFileUpload" action="' + x4hubProxy.site_url + '/directory/ondemand/attach.asp" enctype="multipart/form-data" method="POST" target="ifonDemandUpload">' 
										+ '<input type="hidden" name="maxfiles" id="maxfiles" value="1">'
										+ '<input type="hidden" name="sid" id="sid" value="' + x4hubProxy.sid + '">'
										+ '<input type="hidden" name="linktypetext" id="linktypetext" value="PERSON">' 
										+ '<input type="hidden" name="linkid" id="linkid" value="' + this.temp_contact_person + '">'
										+ '<input type="hidden" name="filetype0" id="filetype0" value="260">'
										+ '<div id="interfaceUploadLabel" class="interfaceUpload">Select File</div>'
										+ '<div id="interfaceUploadFile0" class="interfaceUpload"><input class="interfaceUpload" type="file" name="oFile0" id="oFile0"><span id="uploadprofile">&nbsp;</span></div>'
										+ '<iframe name="ifonDemandUpload" id="ifonDemandUpload" class="interfaceUpload" frameborder="0"></iframe></form>');	
			$('#uploadprofile').button({
				label: 'Upload'
			})
			.click(function(event)
			{
				//Remove then Upload
				X4HUser.remove_profile_image(existing_profile_image);	
				X4HUser.file_upload();
			});
	},
	
	file_upload: function()
	{
		var oForm = document.frmonDemandFileUpload;
		var iOnDemandTimerCount = 0;
		oForm.submit();
		setTimeout('X4HUser.search_profile_image()', 10000);
		//this.iOnDemandTimerID = setInterval('X4HUser.update_file_upload_status()', 1000);
	},

	update_file_upload_status: function()
	{
		var oDivStatus = document.getElementById('divonDemandFileUploadStatus');
		var oFrame = document.getElementById('ifonDemandUpload');
		var sStatus;
		var sCurrentState;
		if (oFrame.readyState) 
		{
			//IE
			sCurrentState = oFrame.readyState;
		}
		else 
		{
			//FF
			if (oFrame.contentDocument.body.innerHTML == 'OK') 
			{
				sCurrentState = 'complete';
			}
			else 
			{
				sCurrentState = oFrame.contentDocument.body.innerHTML;
			}
		}
	 
		if (sCurrentState == 'complete') 
		{
			ClearInterval(this.iOnDemandTimerID);
		}
	},
	search_profile_image: function()
	{
		//Retrieve the Attachment
			x4hubProxy.call([X4HUser, 'store_profile_image'], 
			'/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
			{
					object: 32, //Person Object
					objectcontext: this.temp_contact_person,
					type: 260 //Profile Attachment type
			});
	},
	store_profile_image: function(response)
	{
		var attachment = response.data.rows[0]
		//Save the ID of the image against the contact record
		x4hubProxy.call([X4HUser, 'store_profile_image_response'],
		'/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
        {
			id: this.temp_contact_person,
			sq6965: attachment.id 
        });
        
            /** 21-12-2011 added to change images after upload*/
            myappmaster.contacts.update_profile_image(this.temp_contact_person,attachment.id);
	},
	store_profile_image_response: function(response)
	{
		myappmaster.add_message('Profile Image has been stored.', 5);
                
	},
	save_profile: function(profile) { 
        $.each(profile, function(key, value) {
            if(value == null) {
                value = "";
            }
            profile[key] = value;
        });
        
        x4hubProxy.call(
            [X4HUser, 'save_profile_response'], 
            '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
            profile
        );
    },
		
	save_profile_response: function() {
		myappmaster.add_message('Profile has been saved.', 5);
		this.populate_extra_information();
	},
	
	search_users: function(callback, container) {
	    x4hubProxy.call([X4HUser, callback, container], 
			'/ondemand/core/?method=CORE_USER_SEARCH',
			{
				rows: 500
			}
		);
	},
	
	search_users_return: function(response,container) {
		var aHTML = [];	
		if(response.data.rows.length > 0) {
			$.each(response.data.rows, function(key, row) {
				aHTML.push('<option value="' + row.id + '">' + row.surname + ', ' + row.firstname + '</option>');
			});
			$('#' + container).html(aHTML.join(''));
		}
		//Set the current manager in the list
		$('#' + container).val(X4HUser.manager);
	},
	
	user_list: function() {
		var oXML = '<advancedSearch><field><name>username</name></field><field><name>manager</name></field><field><name>managertext</name></field>' 
					+ '<filter>'
					+ '<name>id</name><comparison>EQUAL_TO</comparison><value1>' + X4HUser.id + '</value1>'
					+ '</filter>'
					+ '<options><rf>JSON</rf><startrow>0</startrow><rows>1</rows></options></advancedSearch>'
        var uri = '';
        x4hubProxy.call([X4HUser, 'user_list_return', 'field-profile-reportsto'], 
			'/ondemand/setup/?method=SETUP_USER_SEARCH&advanced=1',
			{
				data: oXML
            }
		);
	},
    user_list_return: function(response, container) {
		var aHTML = [];
		var user = response.data.rows[0]; 
		X4HUser.manager = user.manager;
		$('#' + container).html(aHTML.join(''));
		X4HUser.search_users('search_users_return', 'field-profile-reportsto');
	}
}