var X4HEmail = {
	object_name: 'Email',
	today_date: new Date,
	accounts: [],
	current_account: 'null',
	authtype: 2,
	rows_return: 10,
	start_result: 1,
	retrieved_results: 0,
	viewable_results: 0,
	project_id: '9',
	flag: 'null',
	search_type: 'null',
	email_tab: 'tab-dashboard',
	email_draft_id: 'null',
	folder_search: 'null',
	mail_type: 'null',
	params: {},
	file_upload_status: 'null',
	init: function() {
		//Collect the details of the signature
		this.prefill_signature();
		
		//Set the variables for pagination
		this.start_result = 1;
		this.retrieved_results = $('#tab-email').find('.end-results').text();
		this.viewable_results = 30;
		this.rows_return = 30;
		this.email_tab = 'tab-email';
		
		//Set the Tabs within Emails
		$('#email-nav').tabs({
			select: function(event, ui) {
				var tmp = ui.tab.hash.split('-');
                var object = tmp[1].toLowerCase();
				
				if(object != 'compose')
				{
					$('.email-compose-tab').hide();
					tinyMCE.execCommand('mceRemoveControl', false, 'field-email-content');
				}
			}
		})
		//Search for the saved emails only if not done already
		this.count_folder_actions();
		
		
	},
	count_folder_actions: function()
	{
		if(X4HEmail.folder_search != 'complete')
		{
			$('.foldercount').each(function(index)
			{
				X4HEmail.search_actions(myappmaster.find_id($(this).attr('id')));
			});
		}
	},
	show_email_dashboard: function()
	{
		this.email_tab = 'tab-dashboard';
		this.rows_return = 10;
		this.bind_triggers();
		
		//Search for top 50 Projects based on the date last modified
		this.search_projects();
		
		this.search_email_accounts();
		//Creates the Modal for Reading Mail and the Tab for Creating new mail
		this.create_modal();
	},
	bind_triggers: function()
	{
		$('.ui-widget-overlay').live("click", function() {
			//Close the dialogs
			if($("#project-assign").dialog('isOpen'))
			{
				$("#project-assign").dialog("close");
			}
		
			if($("#project-create").dialog('isOpen'))
			{
				$("#project-create").dialog("close");
			}
		});  
		
		
		//We want a user to be able to click on the name of the person, subject and the date values to open the mail
		$('body').delegate('.emails-col-2, .emails-col-4, .emails-col-6, .emails-col-7', 'click', function(event) {
			$('.email-read-tab').show();
			$('#middle-nav').tabs( "select" , '#tab-email' )
			$('#email-nav').tabs( "select" , '#tab-read-email' )
			X4HEmail.create_email_read_tab();	
			
			if($(this).parent('.email-row').length > 0)
			{
				/* DONT REQUIRE THIS ANY MORE
				X4HEmail.mail_type = false;
				*/
				//Standard Email (not saved on CRM yet)
				var aMessageId = $(this).parent('.email-row').attr('id').split('-');
				var aAccountId = $(this).parent('.email-row').attr('account-id').split('-');
				$('#email-read-subject-short').text($(this).parent('.email-row').children('.emails-col-4').text().substring(0,30));
				
				X4HEmail.search_mail_detail(aAccountId[1], aMessageId[1], 'prefill_read_tab');
				
				if($(this).parent('.email-row').hasClass('email-read'))
				{
					//Already been read and saved 
				}
				else
				{
					//Brand new mail so mark as seen and save
					//Mark Email as Read on IMAP
					var aMail = new Object();
					aMail.account = aAccountId[1];
					aMail.messageid = aMessageId[1];
					X4HEmail.seen_mail(aMail);
				
					//Save email to CRM and create contacts if required.
					X4HEmail.save_mail([aMail.messageid + '-' + aMail.account], 'CONTACT');
				}
				//Mark both the dash and the email tab as read on the interface
				$('#emaildash-' + aMessageId[1] + ',#email-' + aMessageId[1]).addClass('email-read').removeClass('email-unread');
			}
			else
			{
				//Action Email which has been saved to CRM
				var aActionId = $(this).parent('.email-action').attr('id').split('-');
				
				X4HEmail.mail_type = true; 
				$('#email-read-subject-short').text($(this).parent('.email-action').children('.emails-col-4').text().substring(0,30));				
				X4HEmail.search_action_detail(aActionId[1], 'prefill_read_tab');
			}
		});
		
		$('body').delegate('.project-email-row','click', function(event) {
			$('.email-read-tab').show();
			$('#middle-nav').tabs( "select" , '#tab-email' )
			$('#email-nav').tabs( "select" , '#tab-read-email' )
			X4HEmail.create_email_read_tab();	
			//Action Email which has been saved to CRM
			var aActionId = $(this).attr('id').split('-');
			$('#email-read-subject-short').text($(this).children('.project-email-col-1').text().substring(0,30));				
			X4HEmail.search_action_detail(aActionId[1], 'prefill_read_tab');
		});
		
		$('body').delegate('.emails-col-1', 'click', function(event) {
			if($(this).children('.email-select').is(':checked'))
			{
				$(this).children('.email-select').attr('checked', false);
			}
			else
			{
				$(this).children('.email-select').attr('checked', true);
			}
		});		
		
		$('body').delegate('.email-select', 'click', function(event) {
			if($(this).is(':checked'))
			{
				$(this).attr('checked', false);
			}
			else
			{
				$(this).attr('checked', true);
			}
		});
		//Delegate click on Mark as Private
		$('body').delegate('.markasprivate', 'click', function(event) {
			X4HEmail.save_mail(X4HEmail.select_mail(), 'PRIVATE');
		});
		
		//Delegate click of Personal Mail
		/*
		$('body').delegate('.sendtopersonal', 'click', function(event) {
			//Checks for blank can be extended to check that the email is a valid email address
			if(X4HUser.email_personal == '')
			{
				alert('Please go to your profile and enter a personal email so we know where to send your mail.')
			}
			else
			{
				X4HEmail.search_mail_selected(X4HEmail.select_mail(),'sendtopersonal');
			}
		});*/
		
		//Delegate click of Delete Mail
		$('body').delegate('.deletemail', 'click', function(event) {
			X4HEmail.search_mail_selected(X4HEmail.select_mail(), 'deletemail');
		});
		
		//Bind the Move Project Buttons
		$('body').delegate('.movemail', 'click', function(jsEvent) {
			var aEmails = X4HEmail.select_mail();
			if($(this).parents('.projectfoldertab').length > 0)
			{
				var bAction = true;
			}
			else
			{
				var bAction = false;
			}
			//Open the Drop down box with selection, And Search for projects
			if(aEmails.length > 0)
			{
				X4HEmail.show_assign_project(aEmails, jsEvent, bAction);	
			}
			else
			{
				//Nothing selected
				alert('Please select at least one email');
			}
		});
		
		
		//Delegate click of Colour Mail 
		/*$('body').delegate('.colormail', 'click', function(event) {
			$('.colorselectdiv').slideDown();
		});*/
		
		//Delegate the selection of categories in between
		/*$('body').delegate('.categoryselect, .flagselect', 'mouseenter', function(event) {
			$(this).css("color", "blue");
		});*/
		
		/*$('body').delegate('.categoryselect, .flagselect', 'mouseleave', function(event) {
			$(this).css("color", "");
		});*/
		
		/*$('body').delegate('.categoryselect', 'click', function(event) {
			X4HEmail.label = myappmaster.find_id($(this).attr('id'));
			X4HEmail.save_mail(X4HEmail.select_mail());
		});*/
		
		/*$('body').delegate('.moveselect', 'click', function(event) {
			X4HEmail.label = myappmaster.find_id($(this).attr('id'));
			X4HEmail.manage_mail(X4HEmail.select_mail(), X4HEmail.label);
		});*/
		
		/*$('body').delegate('.flagselect', 'click', function(event) {
			X4HEmail.label = myappmaster.find_id($(this).attr('id'));
			X4HEmail.save_mail(X4HEmail.select_mail(), 'FLAG');
		});*/
		
		/*$('body').delegate('.categoryselectdiv, .flagselectdiv, .moveselectdiv, .colorselectdiv', 'mouseleave', function(event) {
			$(this).slideUp('fast');
		});*/
		
		
		//Delegate click of New mail, compose mail
		$('body').delegate('.compose-mail', 'click', function(event) {
			$('#middle-nav').tabs( "select" , '#tab-email' );
			X4HEmail.prefill_signature();
			//Create the Dialog for a new Mail
			X4HEmail.create_email_tab();
					
			$('.email-compose-tab').show();
			$('#email-nav').tabs( "select" , '#tab-compose-email' );
			
			//Add MCE control
			X4HEmail.add_email_tinymce();
			X4HEmail.create_draft();
		});
		
		//Delegate Discard
		$('body').delegate('#email-discard', 'click', function(event) {
			myappmaster.add_message('Email Discarded', 5);
			$('#email-nav').tabs( "select" , '#tab-inbox-email' )
		});
		
		//Delegate AttachmentButton
		$('body').delegate('#email-attachments', 'click', function(event) {
			//Set the upload type to the correct object context
			$('#email-attach-menu').find('#linkid').val(X4HEmail.email_draft_id);
			$('#email-attachment-popup').slideDown();
		});
		
		$('body').delegate('#popup-attach-remove', 'click', function(event) {
			$('#email-attachment-popup').slideUp();
		});
		
		//Delegate Reply, Forwad, Trash, Send
		$('body').delegate('#email-reply', 'click', function(event) {
			//Collect the variables required for the reply
			var send_to = $('#email-read-sent-from-email').text();
			var email_subject = $('#email-read-subject').text();
			var email_message = $('#ifEmail').contents().find('html').html();
			$('#email-send-subject-short').text(email_subject.substring(0,30));
			X4HEmail.prefill_signature();
			//Close the Open Dialog
			$('#content-email-read-screen').dialog('close');
			
			//Create the Tab for a new Mail
			X4HEmail.create_email_tab();
			$('.email-compose-tab').show();
			$('#email-nav').tabs( "select" , '#tab-compose-email' )
			X4HEmail.prefill_tab(send_to, email_subject, email_message, 'reply');
			
			//Create Draft Id
			X4HEmail.create_draft();
			//Add MCE control
			X4HEmail.add_email_tinymce();
		});
		
		//Bind Forward Button
		$('body').delegate('#email-forward', 'click', function(event) {
			//Collect the variables required for the reply
			var send_to;
			var email_subject = $('#email-read-subject').text();
			$('#email-send-subject-short').text(email_subject.substring(0,30));
			var email_message = $('#ifEmail').contents().find('html').html();
			
			X4HEmail.prefill_signature();
			//Close the Open Dialog
			$('#content-email-read-screen').dialog('close');
			
			//Create the Tab for a new Mail
			X4HEmail.create_email_tab();
			$('.email-compose-tab').show();
			$('#email-nav').tabs( "select" , '#tab-compose-email' )
			X4HEmail.prefill_tab(send_to, email_subject, email_message, 'forward');
			
			//Create Draft ID
			X4HEmail.create_draft();
			
			//Add MCE control
			X4HEmail.add_email_tinymce();
		});
		
		//Bind Trash Email
		$('body').delegate('#email-trash', 'click', function(event) {
			$('#email-nav').tabs( "select" , '#tab-email' )
			var aMail = new Object();
			aMail.id = $('#email-id').text();
			X4HEmail.delete_mail(aMail);
		});
		
		//Bind Send Button on Email
		$('body').delegate('#email-send', 'click', function(event) {
				
			//Get Content and send through to the email send
			X4HEmail.send_mail();
		});
			
		//Create Buttons for Paginate
		$('.email-prev-page').button({
			text: false,
			icons: {
				primary: "ui-icon-triangle-1-w"
			},
			label: "Previous"
		});
		
		//Create Next Page for Paginate
		$('.email-next-page').button({
			text: false,
			icons: {
				primary: "ui-icon-triangle-1-e"
			},
			label: "Next"
		});
		
		//Bind Paginate
		$('body').delegate('.email-next-page', 'click', function(event) {
			if(X4HEmail.viewable_results + 1  <= X4HEmail.retrieved_results) 
			{
				X4HEmail.start_result = X4HEmail.viewable_results + 1;
				X4HEmail.search_mail();
			}
			else
			{
				alert('You have reached the outer limits');
			}
		});
		
		$('body').delegate('.email-prev-page', 'click', function(event) {
			if(X4HEmail.start_result - X4HEmail.rows_return >= 1)
			{ 		
				X4HEmail.start_result = X4HEmail.start_result - X4HEmail.rows_return;
				X4HEmail.search_mail();
			}
			else
			{
				alert('You have reached the outer limits');
			}
		});
		
		//Delegate Change of mail account
		$('body').delegate('#my-email-select', 'change', function(event) {
			X4HEmail.current_account = $(this).val();
			X4HEmail.search_mail();
		});
		
		//Folder Click Bind
		$('body').delegate('.folder', 'click', function(event) {
			var folder_id = myappmaster.find_id($(this).attr('id'));
			
			if(folder_id == 'PUBLIC' || folder_id == 'PRIVATE')
			{
				//Add a Tab to the Email Area
				X4HEmail.create_project_folder_tab(folder_id, $(this).text());
				X4HEmail.search_folder(folder_id, folder_id);
			}
			
			if(folder_id == 'INBOX')
			{
				X4HEmail.email_tab = 'tab-inbox-email';
				$('#email-nav').tabs('select','#tab-inbox-email');
				X4HEmail.search_mail();
			}
		});
		
		$('body').delegate('.childfolder, .orphanfolder', 'click', function(event){
			var aFolder_id = $(this).attr('id').split('-');
			X4HEmail.create_project_folder_tab(aFolder_id[1], $(this).text());
			X4HEmail.search_folder(aFolder_id[1]);
		})
		
				
		//Bind the searches for the email addresses
		$('body').delegate('#email-recipient, #email-recipient-cc, #email-recipient-bcc', 'keyup', function(event) {
			X4HEmail.search_type = $(this).attr('id');
			if($(this).val().length > 3)
			{
				//Run the Search
				X4HContacts.find_person($(this).val(), 'email_recipient_search_response', 'email-recipient-results');
			}
			else
			{
				//Dont run the search no enough chars
			}
		});
		
		$('body').delegate('#email-subject', 'keyup', function(event) {
			$('#email-send-subject-short').text($('#email-subject').val().substring(0,30));
		});
		
		$('body').delegate('#email-recipient, #email-recipient-cc, #email-recipient-bcc', 'focus', function(event) {
			if($(this).val().length > 0)
			{
				$('.email-recipient-results').slideUp('quick');
			}
			else
			{
			
			}
		});
		
		$('body').delegate('.email-address', 'click', function(event) {
			$('#' + X4HEmail.search_type).val($(this).children('td').text());
			$('.email-recipient-results').slideUp('quick');
		});
		
		$('body').delegate('.email-address', 'mouseenter', function(event) {
			$(this).css('cursor','pointer');
			$(this).css('color','#D3D3D3');
		});
		
		$('body').delegate('.email-address', 'mouseleave', function(event) {
			$(this).css('cursor','');
			$(this).css('color','');
		});
		
		$('body').delegate('.email-input-contact-search, .email-input-contact-search-cc, .email-input-contact-search-bcc', 'click', function(event) {
			//Run the Search
			X4HEmail.search_type = $(this).siblings('.email-input-area').children('input').attr('id');
			var sTerm = $(this).siblings('.email-input-area').children('input').val();
			if(sTerm != '')
			{
				X4HContacts.find_person(sTerm, 'email_recipient_search_response', 'email-recipient-results');
			}
			else
			{
				alert('Please enter something to search with.');
			}
		});
		
		//Bind Email settings click
		$('body').delegate('#middle-emails-settings', 'click', function(event) {
			//Show Modal for email options, settings such as the primary email account which will determine the default send of an email
			var sHTML = '';
			if(X4HEmail.accounts.length > 0)
			{
				$(X4HEmail.accounts).each(function(index)
				{
					sHTML = sHTML + '<option value="' + X4HEmail.accounts[index].email + '">' + X4HEmail.accounts[index].email + '</option>'; 
					
				});
			}
			else
			{
				sHTML = sHTML + '<option value="NULL">No Email Accounts Available</option>';
				$('#email-settings-sendfrom-save').hide();
			}
			$('#email-settings-sendfrom').html(sHTML);
					
			X4HEmail.prefill_mail_settings();
			//X4HEmail.show_mail_settings(); //Dialog function
			$('#email-nav').tabs( "select" , '#tab-email-settings')
			$('#tab-email-settings, .email-settings-tab').show()
			
		});
		
		//Bind Email settings save
		$('body').delegate('#email-settings-sendfrom-save', 'click', function(event) {
			//Update the contacts primary send from email
			var contact = new Object();
			contact.id = X4HUser.contact_person;
			contact.sq6934 = $('#email-settings-sendfrom').val();
			
			//Assign the new email to the variable
			X4HUser.email_sendfrom = $('#email-settings-sendfrom').val();
			
			//Save against the contact record.
			X4HContacts.save_contact(contact);
			
			//Recreate the Signature for the user based on the new email
			X4HEmail.prefill_signature();
		});
		
		//Bind Email Attachment Remove
		$('body').delegate('.email-attachment-remove', 'click', function(event) {
			X4HEmail.remove_draft_attachment(myappmaster.find_id($(this).attr('id')));
		});
		
		//Bind the Project Linking Buttons
		$('body').delegate('.link-to-project', 'click', function(jsEvent) {
			//Open the Drop down box with selection, And Search for projects
			if($(this).parents('.email-row').length > 0)
			{
				//Standard Email (not saved on CRM yet)
				var iEmailID = myappmaster.find_id($(this).parents('.email-row').attr('id')) + '-' + myappmaster.find_id($(this).parents('.email-row').attr('account-id'));
				var bAction = false;
			}
			else
			{
				//Action Email which has been saved to CRM
				var iEmailID = myappmaster.find_id($(this).parents('.email-action').attr('id'));
				var bAction = true;
			}
			X4HEmail.show_assign_project(iEmailID, jsEvent, bAction);
		});
		
		//Bind the project linking after you have read the email
		$('body').delegate('#email-link-project', 'click', function(jsEvent) 
		{
			var iEmailID = $(this).siblings('#email-id').text();
			X4HEmail.show_assign_project(iEmailID, jsEvent, X4HEmail.mail_type);
		});
		
		//Focus on the title input
		$('body').delegate('#popup-project-title', 'focus', function(event) {
			$(this).css('background-color','');
		});
		
		//Focus on the title input
		$('body').delegate('#popup-project-title', 'keyup', function(event) {
			var sTerm = $(this).val();
			if(sTerm.length > 3)
			{	
				//run Search
				$(".popup-project-name").not(":containsi(" + sTerm + ")").parent('.assign-project-container').hide();
				$(".assign-project-container:containsi(" + sTerm + ")").parent('.assign-project-container').show();
			}
			else
			{
				//Dont run search yet
				$(".assign-project-container").show();
			}
		});
		
		//PROJECT CLICK
		$('body').delegate('.linked-project-title.linked', 'click', function(event) {
			$('#middle-nav').tabs('select', 'tab-projects');
			var project_id = myappmaster.find_id($(this).attr('id'));
			//Show the project Nav Tab in question
			X4HEmail.create_project_tab(project_id, $(this).text());	
			X4HEmail.load_project_tab(project_id);
		});
		
		//Create new Project Click
		$('body').delegate('.create-new-folder', 'click', function(event) {
			X4HEmail.search_project_parents();
			X4HEmail.show_create_project_modal(event);
		});
		
		//Create a linked project that has a parent
		$('body').delegate('.create-new-linked-project', 'click', function(event) {
			$( '#project-create' ).dialog( 'close' );
			//Build the project params
			var project = new Object();
			project.description = $('#popup-project-create-title').val();
			project.contactbusiness = '1290915';
			project.reference = $('#popup-project-create-title').val();
			project.sq6976 = $('#popup-project-create-parent').val();
			
			//Create the Project,
			X4HEmail.create_new_project(project, null, null);
		});
	},
	create_modal: function() {
		//Check if already created.
		if($('#content-email-screen').length > 0)
		{
		
		}
		else
		{
			//For Composing Mail
			$('#tab-compose-email').append('<div id="content-email-screen">' + 
											  '<div id="email-options">&nbsp;</div>' +
											  '<div id="email-fields">&nbsp;</div>' +
											  '<div id="email-header-fields">&nbsp;</div>' +
											  '<div id="email-message" class="message-content">&nbsp;</div>' +
											  '</div>' +
											  '</div>' + 
											  '<div class="preloader-email-send" style="display:none;">'
											  + '<span><img src="/assets/images/preloader.gif" /><br  /><span class="load-status">sending mail</span></span>'
											  +'</div>');
			//For Reading Mail								  
			$('#tab-read-email').append('<div id="content-email-read-screen">' +
											  '<div class="email-read-header">' + 
											  '<div id="email-read-options">&nbsp;</div>' +
											  '<div id="email-read-fields">&nbsp;</div>' +
											  '<div id="email-read-header-fields">&nbsp;</div>' +
											  '</div>' + 
											  '<iframe name="ifEmail" id="ifEmail" frameborder="0" border="0" scrolling="no" style="width:800px;height: 450px;"></iframe>' +
											  '</div>' +
											  '</div>' +
											  '<div class="preloader-email-read" style="display:none;">' +
											  '<span><img src="/assets/images/preloader.gif" /><br  />' + 
											  '<span class="load-status">reading mail</span></span>' + 
											  '</div>');
			//For viewing and adjusting mail settings
			$('#tab-email-settings').append('<div id="email-settings-screen" class="setup-middle-content">' +
											'<div id="email-settings-header" class="tabbed-content-header">' +
											  '<h1>Email Settings</h1>' +
											  '</div>' +
											  '<div id="content-email-settings">' +
											  '<div id="email-settings-list"><label>My Default Mail Account</label><select id="email-settings-sendfrom">&nbsp;</select>' + 
											  '<span id="email-settings-sendfrom-save">&nbsp;</span></div>' +
											  '<div id="email-settings-signature-label"><label>My Signature Preview</label></div>' +
											  '<div id="email-settings-signature-preview">&nbsp;</div>' +
									  '</div>' +
									  '</div>');
		}
	},
	create_email_tab: function()
	{
		$('#content-email-screen').show();
		$('.preloader-email-send').hide();
		this.insert_new_mail_options();
		
		$('#email-send').button({
			text: false,
			icons: {
				primary: "ui-icon-mail-closed"
			},
			label: "Send"
		});
	},
	create_email_read_tab: function()
	{
		$('#content-email-read-screen').hide();
		$('.preloader-email-read').show();
		//Insert the various options and content for the read mail tab
		this.insert_read_mail_options();
	},
	prefill_tab: function(send_to, email_subject, email_message, email_type) 
	{
		if(send_to != undefined)
		{
			$('#email-recipient').val(send_to);
		}
		if(email_subject != undefined)
		{
			if(email_type == 'reply')
			{
				$('#email-subject').val('RE: ' + email_subject);
			}
			else
			{
				$('#email-subject').val('FWD: ' + email_subject);
			}
		}
		if(email_message != undefined)
		{
			$('#field-email-content').val(email_message);
		}
	},
	prefill_read_tab: function(email) {
		myappmaster.add_message('Read Mail', 5);
		$('#content-email-read-screen').show();
		$('.preloader-email-read').hide();
		//Loop through each Row and populate the details
		if(email.data.rows.length > 0) 
		{
			$.each(email.data.rows, function(key, row) 
			{
				//Declare the variables to assign
				var email_id = this.id;
				var email_messageid = this.messageid;
				var aEmail_sent_to = this.to.split('#');
				var email_sent_from = this.from;
				var email_sent_from_email = this.fromemail;
				var email_date = this.date;
				var email_subject = this.subject;
				var email_message = this.message;
				var source_type = this.sourcetype;
				var email_parent_title = $('#email-' + this.messageid).find('.linked-project-title').text();
				
				var aHTML_sent_to = [];
				$(aEmail_sent_to).each(function(index)
				{
					var aTemp = this.split('|');
					aHTML_sent_to.push(aTemp[1]);
				});
								
				//Push the variables into the relevant areas
				if(X4HEmail.mail_type)
				{
					$('#email-id').html(email_messageid);
				}
				else
				{
					$('#email-id').html(email_messageid + '-' + X4HEmail.current_account);
				}
				$('#email-link-title').text(email_parent_title);
				
				$('#email-read-sent-to').html('to&nbsp;' + aHTML_sent_to.join(';'));
				$('#email-read-sent-from').text(email_sent_from);
				$('#email-read-sent-from-email').text(email_sent_from_email);
				$('#email-read-date').text(email_date);
				$('#email-read-subject').text(email_subject);
				
				var aAttachments = this.attachments.split('#');
				var sAttachments = '';
				var aAttachmentList = [];
				
				$.each(aAttachments, function(index) {
					var aAttachment = this.split("|");
					if(source_type == '2') //Action
					{
							aAttachmentList[index] = '<a href="' + x4hubProxy.site_url + '/ondemand/core/?method=CORE_ATTACHMENT_DOWNLOAD&sid=' + x4hubProxy.sid + '&id=' + aAttachment[1] + '" target="_blank">'
										     + aAttachment[0] + '</a>';
					}
					else // Email
					{
						aAttachmentList[index] = '<a href="' + x4hubProxy.site_url + '/ondemand/messaging/?method=MESSAGING_EMAIL_ATTACHMENT_DOWNLOAD&sid=' + x4hubProxy.sid + '&account=' +X4HEmail.current_account + '&messageid=' + email_messageid + '&attachmentindex=' + aAttachment[2] + '" target="_blank">'
										     + aAttachment[0] + '</a>';
					}
				});
				
				$('#email-read-attachments').html(aAttachmentList.join(','));
				
				//Creates the iframe and then pushes the email content into the iframe
				setTimeout(function(){
					while ($('#ifEmail').length == 0)
					{
					}
					$('#ifEmail').contents().find('html').html('<div id="email-read-message" class="message-content" style="font-size: 11px;">' + email_message + '</div>');
				
					/*if ($.browser.msie)
					{
					}
					else
					{	
						var newHeight = $('#ifEmail',top.document).contents().find('html').height() + 100;
					}

					if ($.browser.msie)
					{
						setTimeout("setHeight()", 100);
					}
					else
					{	
						$('#ifEmail').height($('#ifEmail',top.document).contents().find('html').height())
						//$('#ifEmail').width($('#ifEmail',top.document).contents().find('html').width())
					}*/
				},300);
			});
		}
	},
	insert_read_mail_options:function() {
		 //The buttons available
		$('#email-read-options').html('<span id="email-reply">&nbsp;</span>' + 
								'<span id="email-forward">&nbsp;</span>' + 
								'<span id="email-trash">&nbsp;</span>' +
								'<span id="email-id" style="display:none;">&nbsp;</span>' + 
								'<span id="email-link-project" title="Link to Project"><img src="/assets/images/folder01.png"/></span>' +
								'<span id="email-link-title">N/A</span>');
		
		//The subject and sent to area
		$('#email-read-fields').html('<div id="email-read-subject-fields">' + '<div id="email-read-subject" title="email Subject">&nbsp;</div>' + '</div>');
								//'<div class="sent-to-div"><span id="email-read-sent-to" title="email Recipient">&nbsp;</span></div>');
		
		//Sender email and date
		$('#email-read-header-fields').html('<div id="email-read-left">' +
								'<div id="email-read-sent-from" title="Sender">&nbsp;</div>' +
								'<div id="email-read-sent-from-email" title="Sender email">&nbsp;</div>' +
								'<div id="email-read-sent-to" title="email Recipient">&nbsp;</div>' +
								'</div>' + 
								'<div id="email-read-right">' +
								'<div id="email-read-date" title="email Date">&nbsp;</div>' +
								'<div id="email-read-attachments">&nbsp;</div>' + 
								'</div>');
		
		//Clear Email Message
		$('#email-read-message').html('');
		
		//Bind the Buttons Now
		$('#email-reply').button({
			text: false,
			icons: {
				primary: "ui-icon-arrowreturnthick-1-w"
			},
			label: "Reply"
		});
		$('#email-forward').button({
			text: false,
			icons: {
				primary: "ui-icon-arrowreturnthick-1-e"
			},
			label: "Forward"
		});
		
		$('#email-trash').button({
			text: false,
			icons: {
				primary: "ui-icon-trash"
			},
			label: "Delete"
		});
	},
	insert_new_mail_options: function() {
		$('#email-options').html('<div class="email-options-buttons">' + 
								 '<span id="email-send">&nbsp;</span>' +
								 '<span id="email-save-as-draft">&nbsp;</span>' +								 
								 '<span id="email-attachments">&nbsp;</span>' +
								 '<span id="email-discard" style="border: 1px solid red;">&nbsp;</span>' +
								 '</div>');
		//Build the send as
		var sHTML = '';
		$(X4HEmail.accounts).each(function(index)
		{
			sHTML = sHTML + '<option value="' + X4HEmail.accounts[index].email + '">' + X4HEmail.accounts[index].email + '</option>'; 
		});
		$('#email-fields').html('<div id="fromdiv">' + 
								'<div class="leftdiv">' +
								'<div class="fromlabel">From:</div>' +
								'</div>' +
								'<div class="rightdiv">' +
								'<select id="email-sender">' + sHTML + '</select>' +
								'</div>' +
								'</div>' +
								'<div id="todiv">' + 
								'<div class="leftdiv">' +
								'<div class="tolabel">To:</div>' +
								'</div>' +
								'<div class="rightdiv">' +
								'<div class="email-input-area"><input id="email-recipient" /></div>' +
								'<div class="email-input-contact-search">&nbsp;</div>' +
								'<div class="email-recipient-results">&nbsp;</div>' +
								'</div>' +
								'</div>' + 
								'<div id="ccdiv">' + 
								'<div class="leftdiv">' +								
								'<div class="cclabel">Cc:</div>' +
								'</div>' +
								'<div class="rightdiv">' +
								'<div class="email-input-area"><input id="email-recipient-cc" /></div>' +
								'<div class="email-input-contact-search-cc">&nbsp;</div>' + 
								'<div class="email-recipient-results">&nbsp;</div>' +
								'</div>' +
								'</div>' +
								'<div id="bccdiv">' + 
								'<div class="leftdiv">' +	
								'<div class="bcclabel">Bcc:</div>' +
								'</div>' +
								'<div class="rightdiv">' +
								'<div class="email-input-area"><input id="email-recipient-bcc" /></div>' +
								'<div class="email-input-contact-search-bcc">&nbsp;</div>' +
								'<div class="email-recipient-results">&nbsp;</div>' +
								'</div>' +
								'</div>');
		$('#email-header-fields').html('<span>Subject:</span>' + 
										'<input id="email-subject" title="email Subject" />' + 
										'<div id="email-attachment-popup" style="display:none;">' +
											'<div id="popup-attach-header">' +
											'<div id="popup-attach-title">Attachments</div>' +
											'<div id="popup-attach-remove">^</div>' +
											'</div>' +
											'<div id="popup-email-main">' +
												'<div class="email-attach-container">' +
													'<span class="email-attach-status"><i>No Attachments...</i></span>' +
													'<div class="email-attach-progress"></div>'+
												'</div>' +
												'<div id="email-attach-menu">' +
													'<form name="frmonDemandFileUpload" action="' + x4hubProxy.site_url + '/ondemand/attach/progress/?sid=' + x4hubProxy.sid + '" enctype="multipart/form-data" method="POST" target="ifonDemandUpload">' +
													'<input type="hidden" name="maxfiles" id="maxfiles" value="1">' +
													'<input type="hidden" name="linktype" id="linktype" value="17">' + // Email Object Type 
													'<input type="hidden" name="linkid" id="linkid" value="">' + //Blank but will become the email_draft_id
													/*'<input type="hidden" name="linktype" id="linktype" value="32">' + // Email Object Type 
													'<input type="hidden" name="linkid" id="linkid" value="1000526796">' + //Blank but will become the email_draft_id*/
													'<input type="hidden" name="filetype0" id="filetype0" value="">' +
													'<div id="interfaceUploadFile0" class="interfaceUpload"><input class="interfaceUpload" type="file" name="oFile0" id="oFile0"></div>' + 
													'<div id="uploadattachments">&nbsp;</div>' +
													'</form>' +
													'<iframe name="ifonDemandUpload" id="ifonDemandUpload" class="interfaceUpload" frameborder="0" style="display:none;"></iframe>' +								
												'</div>' +					
											'</div>' +
											'<div id="popup-attach-footer">' +
												
											'</div>' +
										'</div>');
										
		$('#uploadattachments').button({
			label: 'Upload'
		})
		.click(function(event)
		{
			X4HEmail.file_upload();
		});
		
		$('#popup-attach-remove').button({
			text: false,
			icons: {
					primary: "ui-icon-closed"
				},
				label: "Hide"
		});
		
		$('#email-sender').val(X4HUser.email_sendfrom)								
		$('#email-message').html('<textarea id="field-email-content" cols="40" rows"20"></textarea>');	
		//Buttons for the email options
		$('#email-send').button({
			text: false,
			icons: {
				primary: "ui-icon-mail-closed"
			},
			label: "Send"
		});
		$('#email-save-as-draft').button({
			text: false,
			icons: {
				primary: "ui-icon-document"
			},
			label: "Save as Draft"
		});
		$('#email-attachments').button({
			text: false,
			icons: {
				primary: "ui-icon-link"
			},
			label: "Attachments"
		});
		$('#email-discard').button({
			text: false,
			icons: {
				primary: "ui-icon-closethick"
			},
			label: "Discard"
		});
		//Buttons for the searchs
		$('.email-input-contact-search, .email-input-contact-search-cc, .email-input-contact-search-bcc').button({
			text: false,
			icons: {
				primary: "ui-icon-search"
			},
			label: "Search Contact"
		});
		
	},
	search_email_accounts: function() {
		x4hubProxy.call(
			[X4HEmail, 'store_email_accounts'], 
            '/ondemand/messaging/?method=MESSAGING_EMAIL_ACCOUNT_SEARCH',
            {
               
            });
	},
	store_email_accounts: function(response) {
		$('.progressbar-loading').progressbar("option","value", 33);
		$('.state-loading').text('Loading User Details');
		
		myappmaster.add_message('User Email Accounts Stored.', 5);
		var aHTML = [];
		if(response.status != 'ER')
		{
			if(response.data.rows.length > 0) {
				//Store the email accounts in the email account array
				$.each(response.data.rows, function(key, row) {
					//Push the row into the accounts array
					X4HEmail.accounts.push(row);
					aHTML.push('<option value="' + row.id + '">');
					aHTML.push(row.email);
					aHTML.push('</option>');
				});
				$('#my-email-select').html(aHTML.join(''));
			}
			else
			{
				this.show_no_email_accounts_message();
			}
		}
	},
	show_no_email_accounts_message: function(response) {
		
	},
	search_mail_init: function() {
		//Load the mail for the email tab with 30 rows only show 10 rows for dash
		console.log('Search for Mail Init');
		X4HEmail.search_mail(true);
	},
	search_mail_detail: function(account_id, message_id, container) {
		this.set_authtype(account_id);
		
        //Search for a single email
		x4hubProxy.call(
		[X4HEmail, container], 
           '/ondemand/messaging/?method=MESSAGING_EMAIL_SEARCH',
		{
			data_format: 'json',
			account: account_id,
			id: message_id,
			authtype: X4HEmail.authtype
		});
	},
	set_authtype: function(account_id)
	{
		if(account_id == '20153')
		{
			X4HEmail.authtype = 0;
		}
		else
		{
			X4HEmail.authtype = 2;
		}
	},
	send_mail: function(aParam) {
		$('#content-email-screen').hide();
		$('.preloader-email-send').show();
		
		if (aParam != undefined)
		{
			//The mail has been system created (bounce to personal)
			var email_subject = aParam.subject;
			var email_message = aParam.message;
			var email_to = aParam.to;
		}
		else
		{
			//Its a user created email
			var email_subject = $('#email-subject').val();
			var email_message = tinyMCE.get('field-email-content').getContent() + $('#email-signature').html();
			var email_to = $('#email-recipient').val();
			var email_cc = $('#email-recipient-cc').val();
			var email_bcc = $('#email-recipient-bcc').val();
			var email_from = $('#email-sender').val();
		}
				
		x4hubProxy.call(
		[X4HEmail, 'send_mail_response'], 
           '/ondemand/messaging/?method=MESSAGING_EMAIL_SEND',
		{
			subject: email_subject,
			message: email_message,
			to: email_to,
			cc: email_cc,
			bcc: email_bcc,
			fromemail: email_from,
		});
	},
	send_mail_response: function(response) {
		if(response.notes = 'SENT')
		{
			myappmaster.add_message('Email Sent to ' + response.to + '.', 5);
			$('#email-nav').tabs( "select" , '#tab-inbox-email' );
		}
		else
		{
			$('.preloader-email-send').html('<span>Send Failed, please try again.</span>');
			setTimeout(
				function() {
					$('.preloader-email-send').hide();
					$('#content-email-screen').show();
				},
			800);
		}
	},
	delete_action: function(aMail){
		aMail.remove = "1";
		x4hubProxy.call(
		[X4HEmail, 'delete_action_response'], 
           '/ondemand/ACTION/?method=ACTION_MANAGE',
		   aMail
		);
	},
	delete_action_response: function(response)
	{
		var status = response;
		if(status.status = 'OK')
		{
			myappmaster.add_message('Email Deleted from CRM.', 5);
		}
	},
	delete_mail: function(aMail) {
		aMail.imapflags = "(\\Deleted)";
		x4hubProxy.call(
		[X4HEmail, 'delete_mail_response'], 
           '/ondemand/messaging/?method=MESSAGING_EMAIL_IMAP_MANAGE',
		   aMail
		);
	},
	delete_mail_response: function(response)
	{
		var status = response;
		if(status.status = 'OK')
		{
			myappmaster.add_message('Email Deleted.', 5);
		}
	},
	seen_mail: function(aMail) {
		aMail.imapflags = "(\\Seen)";
		x4hubProxy.call(
		[X4HEmail, 'seen_mail_response'], 
           '/ondemand/messaging/?method=MESSAGING_EMAIL_IMAP_MANAGE',
		   aMail
		);
	},
	seen_mail_response: function(response)
	{
		var status = response;
		if(status.status = 'OK')
		{
			myappmaster.add_message('Email Marked as Seen on IMAP.', 5);
		}
	},
	search_mail: function(bInit) {
		var container = 'emails-body'
		this.set_authtype(X4HEmail.current_account);
		X4HEmail.params.account_id = X4HEmail.current_account;
		if(bInit != null)
		{
			X4HEmail.params.bInit = true;
			X4HEmail.rows_return = 30;
		}
		else
		{
			X4HEmail.params.bInit = false;
		}
		//Show loading
		$('#' + X4HEmail.email_tab + ' #emails-body').html('<div class="email-load"><img src="/assets/images/preloader.gif"></div>');
			
		x4hubProxy.call(
		[X4HEmail, 'search_mail_response', container], 
           '/ondemand/messaging/?method=MESSAGING_EMAIL_SEARCH',
		{
			start: X4HEmail.start_result,
			data_format: 'json',
			account: X4HEmail.current_account, //aEmailAccounts[0] // FF EMAIL 20238 
			rows: X4HEmail.rows_return,
			includeremoved: '1',
			orderby: 'date'
			//search: 'UNDELETED'
		});
	},
	search_mail_response: function(mail, container) {
			
		$('.progressbar-loading').progressbar("option","value", 100);
		$('.state-loading').text('Loaded.');
		setTimeout(function()
			{
				$('.ui-widget-overlay').css('opacity','');
				$('.loading-myapp').dialog('close')
			}, 800);
		if(mail.status != 'ER')
		{
			//Update the count in the redbox and anywhere else required 
			if(parseInt(mail.unreademails) > 0)
			{	
				if(parseInt(mail.unreademails) > mail.data.rows.length)
				{
					$('.newemailcount').text(X4HEmail.rows_return + '+').show();
				}
				else
				{
					$('.newemailcount').text(mail.unreademails).show();
				}
			}
			else
			{
				$('.newemailcount').hide();
			}
			
			var aHeader = [];
			var aHTML = [];
			$('.email-load').remove();
			var aRow = [];
			
			//Header Row 6 cols
						
			aHeader.push('<div class="email-header-row">');
			aHeader.push('<div class="email-select_header email-header-format">&nbsp;</div>');
			aHeader.push('<div class="email-from_header email-header-format"><span>From</span></div>');
			aHeader.push('<div class="email-attachment_header email-header-format">&nbsp;</div>');
			aHeader.push('<div class="email-subject_header email-header-format"><span>Subject</span></div>');
			aHeader.push('<div class="email-project_header email-header-format"><span>Project</span></div>');
			aHeader.push('<div class="email-date_header email-header-format"><span>Date</span></div>');
			aHeader.push('</div>');
			
			/*$('#' + X4HEmail.email_tab + ' #emails-body').html(aHTML.join(''));
			aHTML = [];*/
			
			//Loop through each Row and create the emails row
			if(mail.data.rows.length > 0) 
			{
				$.each(mail.data.rows, function(key, row) {
					aRow = [];
					var aTo = this.to.split('#');
					var sFrom = this.from;
					var sDate = this.date;
					var sTo = '';	

					//Sample 18 Oct 2011 12:49:46
					var dDate = $.fullCalendar.parseDate( sDate )
					
					//Loop through the aTo
					$(aTo).each(function(index)
					{
						var aTemp = this.split('|');
						sTo = sTo + '<span title="' + aTemp[0] + '">' + aTemp[1] + '</span><br />'; 
					});

					//Find out if the email was recieved today
					if(X4HEmail.today_date.getDate() == dDate.getDate() && X4HEmail.today_date.getMonth() == dDate.getMonth() && X4HEmail.today_date.getFullYear() == dDate.getFullYear())
					{			
						sDate = $.fullCalendar.formatDate(dDate, 'hh:mm tt');;
					}
					else
					{
						sDate = $.fullCalendar.formatDate(dDate, 'hh:mm tt dd/MM/yyyy');
					}
				
					var sSubject = this.subject;
				
					var iMailId = this.messageid;
					var iMailRead = this.read; // 0 for no 1 for yes
					var iMailTrash = this.removed; // 0 for no 1 for yes
					var sImapFlags = '';
					var sAttachmentCount = this.contenttype;
					
					if(this.imapflags != undefined)
					{
						sImapFlags = this.imapflags;
					}
					
					//Check for Marked as Read/Seen
					if(sImapFlags.indexOf('SEEN') >= 0)
					{
						aRow.push('<div id="email-' + iMailId + '" account-id="accountid-' + X4HEmail.params.account_id + '" class="email-row email-read ' + X4HEmail.params.account_id + '-' + iMailId + '">');
					}
					else
					{
						aRow.push('<div id="email-' + iMailId + '" account-id="accountid-' + X4HEmail.params.account_id + '" class="email-row email-unread ' + X4HEmail.params.account_id + '-' + iMailId + '">');
					}
					
					
					aRow.push('<div class="emails-col-1 email-cols-format"><input type="checkbox" class="email-select"></div>');
					aRow.push('<div class="emails-col-2 email-cols-format">' + sFrom + '</div>');
										
					//Check for Attachment
					if(sAttachmentCount.indexOf('/mixed') >= 0)
					{
						aRow.push('<div class="emails-col-3 email-cols-format"><img src="/assets/images/attach01.png"></div>'); 
					}
					else
					{
						aRow.push('<div class="emails-col-3 email-cols-format">&nbsp;</div>'); 
					}
					
					aRow.push('<div class="emails-col-4 email-cols-format"><a href="#">' + sSubject + '</a></div>');
					
					aRow.push('<div class="emails-col-5 email-cols-format"><span class="link-to-project not-linked" title="Link to Project"><img src="/assets/images/folder01.png"></span><span class="linked-project-title" title="Not Linked to a Project">N/A</span></div>');			
					aRow.push('<div class="emails-col-6 email-cols-format">' + sDate + '</div>');
					aRow.push('</div>');
					aHTML.push(aRow.join(''));
				});
				//Add the total to the paginate area
				//Gives us the total of all mail present on this account
				X4HEmail.retrieved_results = parseInt(mail.totalcount);
				
				//Gives us the total of the current mail in this view
				X4HEmail.viewable_results = X4HEmail.start_result + mail.data.rows.length - 1;
				
				//Need to check if this is an init to push to both tabs (dash and email)
				if(X4HEmail.params.bInit)
				{
					var aDash = aHTML.slice(0,11);
					$('#tab-dashboard #emails-body').html(aHeader.join('') + aDash.join(''));
					$('#tab-dashboard').find('.start-results').text('1-10');
					$('#tab-dashboard').find('.end-results').text(X4HEmail.retrieved_results);
					
					$('#tab-dashboard').find('.email-row').each(function(index)
					{
						//CHANGE THE ID's NOT TO CONFUSE THEM WITH THE EMAIL TAB AREA
						var aEmail = $(this).attr('id').split('-');
						$(this).attr('id', 'emaildash-' + aEmail[1]);
					}); 
					
					$('#tab-email #emails-body').html(aHeader.join('') + aHTML.join(''));
					$('#tab-email').find('.start-results').text(X4HEmail.start_result + '-' + X4HEmail.viewable_results);
					$('#tab-email').find('.end-results').text(X4HEmail.retrieved_results);
				}
				else
				{
					$('#' + X4HEmail.email_tab + ' #emails-body').html(aHeader.join('') + aHTML.join(''));
					//Change the total at the bottom of the list
					$('#' + X4HEmail.email_tab).find('.start-results').text(X4HEmail.start_result + '-' + X4HEmail.viewable_results);
					$('#' + X4HEmail.email_tab).find('.end-results').text(X4HEmail.retrieved_results);
				}
			}
			else
			{
				$('#tab-dashboard #emails-body, #tab-email #emails-body').html('<span class="email-error">No emails found.</span>');
				$('#tab-dashboard #emails-search, #tab-email #emails-search, #tab-dashboard #nav-email, #tab-email #nav-email').hide();
				$('.footer-paginate').hide();
				console.log("No Mail found in account");
			}
		}
		else
		{
			$('#tab-dashboard #emails-body, #tab-email #emails-body').html('<span class="email-error">Could not connect to account.</span>');
			$('#tab-dashboard #emails-search, #tab-email #emails-search, #tab-dashboard #nav-email, #tab-email #nav-email').hide();
			$('.footer-paginate').hide();
			console.log("Could Not Connect to Account");
		}
	},
	select_mail: function()
	{
		var aEmailArray = [];
		if($('.projectfoldertab:visible').length > 0)
		{
			var sClass = 'email-action'
		}
		else
		{
			var sClass = 'email-row'	
		}
		$('.' + sClass).each(function(index)
		{
			if($(this).find('.email-select').attr('checked') == 'checked')
			{
				if(sClass == 'email-action')
				{
					aEmailArray.push(myappmaster.find_id($(this).attr('id')));
				}
				else
				{
					aEmailArray.push(myappmaster.find_id($(this).attr('id')) + '-' + myappmaster.find_id($(this).attr('account-id')));
				}
			}
		});
		if(aEmailArray.length > 0)
		{
			return aEmailArray;
		}
		else
		{
			return false;
		}
	},
	search_mail_selected: function(aEmailArray, type)
	{
		//For each in the array of mail we loop through and push to the personal email account 
		$(aEmailArray).each(function(index)
		{
			//Elements in each array is idofmail-idofaccount
			//Only saved mail can be deleted
			/*if(type == 'sendtopersonal')
			{
				X4HEmail.search_mail_detail(aEmail[1], aEmail[0], 'send_email_to_personal');
				X4HEmail.hide_mail(aEmail[1], aEmail[0]);
			}*/
			if(type == 'deletemail')
			{
				X4HEmail.hide_mail(null, null, aEmailArray[index]);
				var aMail = new Object();
				aMail.id = aEmailArray[index];
				X4HEmail.delete_action(aMail);
			}
		});
	},
	save_mail: function(aEmailArray, type)
	{
		$(aEmailArray).each(function(index)
		{
			//Elements in each array is idofmail-idofaccount
			var aEmail = this.split('-');
			var email = new Object();
			if(type == 'PRIVATE') 
			{ 
				email.private = 'Y' 
				X4HEmail.label = 'PRIVATE';
			}
			else if(type == 'FLAG')
			{
				X4HEmail.flag = type;
			}
			else if(type == 'PROJECT')
			{
				email.object = '1'; //Project Object
				email.objectcontext = X4HEmail.project_id; //The type of Project linking it to
			}
			else if(type == 'CONTACT')
			{
				email.autocreatecontacts = 'Y';
			}
			email.account = aEmail[1];
			email.messageid = aEmail[0];
						
			//Now do the save
			x4hubProxy.call(
			[X4HEmail, 'save_mail_response', type], 
			   '/ondemand/messaging/?method=MESSAGING_EMAIL_ACTION_MANAGE',
			   email
			);
		});
	},
	save_mail_response: function(response, type)
	{
		if(response.status != 'ER')
		{
			myappmaster.add_message('Email Saved.', 5);
			if(type == 'CONTACT')
			{
				$('#email-id').text(response.action);
				$('#email-link-title').text('Uncategorized');
			}
		}
	},
	
	//MARKING MAIL AS IMPORTANT
	/*flag_mail: function(action_id, flag)
	{
		x4hubProxy.call(
			[X4HEmail, 'flag_mail_response'], 
			   '/ondemand/action/?method=ACTION_MANAGE',
			   {
				   id: action_id,
				   priority: flag
				}
			);
	},
	flag_mail_response: function(response)
	{
		myappmaster.add_message('Mail Saved and Flagged.', 5);
	},*/
	hide_mail:function(account_id, message_id, action_id)
	{
		if(action_id == undefined)
		{
			$('.' + account_id + '-' + message_id).fadeOut('slow', function(event) {
				$(this).remove();
			});
		}
		else
		{
			$('#email-' + action_id).fadeOut('slow', function(event) {
				$(this).remove();
			});
		}
	},
	
	//BOUNCING EMAIL TO PERSONAL ACCOUNT
	/* 
	send_email_to_personal: function(response)
	{
		var email = response.data.rows[0]; 
		var aParam = new Object();
		aParam.subject = email.subject;
		aParam.message = email.message + '<p>This Email has been forwarded from myapp.</p>';
		aParam.to = X4HUser.email_personal;
		this.send_mail(aParam);
		
		var aMail = new Object();
		aMail.id = email.id;
		this.delete_mail(aMail);
	},
	*/
	search_actions: function(folder_id, type)
	{
		var oXML = "<advancedSearch>"
            + "<field><name>actionby</name></field>"
			+ "<field><name>linkid</name></field>"
           	/*if(type == 'PRIVATE') 
			{
				oXML = oXML + "<filter><name>actionprivate</name><comparison>EQUAL_TO</comparison><value1>Y</value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>and</name><comparison></comparison><value1></value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>actiontype</name><comparison>EQUAL_TO</comparison><value1>9</value1><value2></value2></filter>"
			}*/
			if(type == 'PUBLIC')
			{
				oXML = oXML + "<filter><name>actionprivate</name><comparison>EQUAL_TO</comparison><value1>N</value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>and</name><comparison></comparison><value1></value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>actiontype</name><comparison>EQUAL_TO</comparison><value1>9</value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>and</name><comparison></comparison><value1></value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>linkid</name><comparison>IS_NULL</comparison><value1></value1><value2></value2></filter>"
			}
			if(type == undefined)
			{
				oXML = oXML + "<filter><name>linkid</name><comparison>EQUAL_TO</comparison><value1>" + folder_id + "</value1><value2></value2></filter>"
			}
		oXML = oXML + "<options><rf>JSON</rf><startrow>0</startrow><rows>10</rows></options>"
			+ "<summaryField><name>count auditcount</name></summaryField>" 
            + "</advancedSearch>";
       
		x4hubProxy.call(
            [this, 'search_actions_response', type + '-' + folder_id],
            '/ondemand/action/?method=ACTION_SEARCH',
            {
                advanced: 1,
                data: oXML,
			}
        ); 
	},
	search_actions_response: function(actions, type)
	{
		X4HEmail.folder_search = 'complete';
		var aType = type.split('-');
		//Loop through each Row and create the emails row
		if(actions.data.rows.length > 0) 
		{
			var folder_id = actions.data.rows[0].linkid;
			if(aType[0] == 'PRIVATE' || aType[0] == 'PUBLIC')
			{
				folder_id = aType[0];
			}
			if(aType[0] == 'LABEL')
			{
				folder_id = aType[1];
			}

			$('#foldercount-' + folder_id).text(actions.summary.auditcount);
		}
		else
		{
		
		}
		
	},
	search_action_detail: function(action_id, container)
	{
		x4hubProxy.call(
		[X4HEmail, container], 
           '/ondemand/messaging/?method=MESSAGING_EMAIL_ACTION_SEARCH',
		{
			id: action_id,
        });
	},
	search_action_detail_response: function(action)
	{
		
	},
	search_folder: function(folder_id, type, callback)
	{	if(callback == undefined)
		{
			callback = 'search_folder_response';
		}
		var container = 'project-emails-body';
		//Show loading
		$('#' + X4HEmail.email_tab + ' #' + container + ' tbody').html('<tr class="email-load"><td><img src="/assets/images/preloader.gif"></td></tr>');
		var oXML = "<advancedSearch>"
            + "<field><name>actionby</name></field>"
			 + "<field><name>actionbytext</name></field>"
			+ "<field><name>actionprivate</name></field>"
			+ "<field><name>actiontype</name></field>"
			+ "<field><name>linkid</name></field>"
        	+ "<field><name>contactbusiness</name></field>"
			+ "<field><name>contactbusinesstext</name></field>"
			+ "<field><name>contactperson</name></field>"
			+ "<field><name>contactpersontext</name></field>"
			+ "<field><name>duedatetime</name></field>"
			+ "<field><name>actionreference</name></field>"
			+ "<field><name>attachmentcount</name></field>"
			+ "<field><name>projecttext</name></field>";
			
			if(type == 'PUBLIC')
			{
				oXML = oXML + "<filter><name>actionprivate</name><comparison>EQUAL_TO</comparison><value1>N</value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>and</name><comparison></comparison><value1></value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>actiontype</name><comparison>EQUAL_TO</comparison><value1>9</value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>and</name><comparison></comparison><value1></value1><value2></value2></filter>"
				oXML = oXML + "<filter><name>linkid</name><comparison>IS_NULL</comparison><value1></value1><value2></value2></filter>"
			}
			if(type == undefined)
			{
				oXML = oXML + "<filter><name>linkid</name><comparison>EQUAL_TO</comparison><value1>" + folder_id + "</value1><value2></value2></filter>"
			}
			oXML = oXML + "<sort><name>duedatetime</name><direction>desc</direction></sort>"
					+ "<summaryField><name>count auditcount</name></summaryField>"
					+ "<options><rf>JSON</rf><startrow>0</startrow><rows>30</rows></options>"
					+ "</advancedSearch>";
					   
        x4hubProxy.call(
            [this, callback, container],
            '/ondemand/action/?method=ACTION_SEARCH',
            {
                advanced: 1,
                data: oXML
			}
        ); 
	},
	search_folder_response: function(emails)
	{
		myappmaster.add_message('Search Mail Folder', 5);
		if(emails.status != 'ER')
		{
			var aHeader = [];
			var aHTML = [];
			$('.email-load').remove();
			var aRow = [];
			
			//Header Row 6 cols
						
			aHeader.push('<div class="email-header-row">');
			aHeader.push('<div class="email-select_header email-header-format">&nbsp;</div>');
			aHeader.push('<div class="email-from_header email-header-format"><span>From</span></div>');
			aHeader.push('<div class="email-attachment_header email-header-format">&nbsp;</div>');
			aHeader.push('<div class="email-subject_header email-header-format"><span>Subject</span></div>');
			aHeader.push('<div class="email-project_header email-header-format"><span>Project</span></div>');
			aHeader.push('<div class="email-date_header email-header-format"><span>Date</span></div>');
			aHeader.push('</div>');
									
			//Loop through each Row and create the emails row
			if(emails.data.rows.length > 0) 
			{
				$.each(emails.data.rows, function(key, row) {
					aRow = [];
					var aTo = '';
					var sFromName = this.contactpersontext;
					var sDate = this.duedatetime;
					var sTo = '';
					if(this.projecttext != '')
					{
						var sProjectTitle = this.projecttext;
						var sProjectHTML = '<span class="link-to-project id-linked" title="Move to Project"><img src="/assets/images/folder01.png"></span><span class="linked-project-title linked" id="project-' + this.linkid + '" title="Go to ' + sProjectTitle + ' Overview">' + sProjectTitle + '</span>';
					}
					else
					{
						var sProjectTitle = 'N/A';
						var sProjectHTML = '<span title="Link to Project" class="link-to-project not-linked"><img src="/assets/images/folder01.png"></span><span title="Not Linked to a Project" class="linked-project-title">N/A</span>';
					}

					//Sample 18 Oct 2011 12:49:46
					var dDate = $.fullCalendar.parseDate( sDate )
					sDate = $.fullCalendar.formatDate(dDate, 'hh:mm tt dd/MM/yyyy');
					
					var sSubject = this.actionreference;
					var iMailId = this.id;
					var sAttachmentCount = '';
										
					//Find out if the email was recieved today
					if(X4HEmail.today_date.getDate() == dDate.getDate() && X4HEmail.today_date.getMonth() == dDate.getMonth() && X4HEmail.today_date.getFullYear() == dDate.getFullYear())
					{			
						sDate = $.fullCalendar.formatDate(dDate, 'hh:mm tt');
					}
					else
					{
						sDate = $.fullCalendar.formatDate(dDate, 'hh:mm tt dd/MM/yyyy');
					}
				
					aRow.push('<div id="email-' + iMailId + '" class="email-action email-read">');
					aRow.push('<div class="emails-col-1 email-cols-format"><input type="checkbox" class="email-select"></div>');
					aRow.push('<div class="emails-col-2 email-cols-format">' + sFromName + '</div>');
							
					//Check for Attachment
					if(parseInt(this.attachmentcount) > 0)
					{
						aRow.push('<div class="emails-col-3 email-cols-format"><img src="/assets/images/attach01.png"></div>'); 
					}
					else
					{
						aRow.push('<div class="emails-col-3 email-cols-format">&nbsp;</div>'); 
					}
					
					aRow.push('<div class="emails-col-4 email-cols-format"><a href="#">' + sSubject + '</a></div>');
					//Project ROW
					aRow.push('<div class="emails-col-5 email-cols-format">' + sProjectHTML + '</div>');			
					aRow.push('<div class="emails-col-6 email-cols-format">' + sDate + '</div>');
					aRow.push('</div>');
					aHTML.push(aRow.join(''));
				});
				//Add the total to the paginate area
				//Gives us the total of all mail present on this account
				X4HEmail.retrieved_results = parseInt(emails.summary.auditcount);
				
				//Gives us the total of the current mail in this view
				X4HEmail.viewable_results = X4HEmail.start_result + emails.data.rows.length - 1;
				
				//Need to check if this is an init to push to both tabs (dash and email)
				$('.projectfoldertab #project-emails-body').html(aHeader.join('') + aHTML.join(''));
				//Change the total at the bottom of the list
				$('.projectfoldertab').find('.start-results').text(X4HEmail.start_result + '-' + X4HEmail.viewable_results);
				$('.projectfoldertab').find('.end-results').text(X4HEmail.retrieved_results);
			}
			else
			{
				console.log("No Mail found in Folder");
			}
		}
		else
		{
			console.log("Problem searching actions");
		}
	},
	manage_mail: function(aEmailArray, type)
	{
		$(aEmailArray).each(function(index)
		{
			var action = new Object();
			action.id = aEmailArray[index];
			
			if(type == 'PRIVATE')
			{
				action.private = 'Y';
			}
			
			if(type == 'PUBLIC')
			{
				action.private = 'N';
			}
			X4HEmail.hide_mail('null','null',action.id);
			x4hubProxy.call(
			[X4HEmail, 'manage_mail_response', type], 
			   '/ondemand/action/?method=ACTION_MANAGE',
			   action
			);
		});
	},
	manage_mail_response: function(response, type)
	{
		myappmaster.add_message('Emails Saved.', 5);
		this.search_actions('null', type);
	},
	prefill_mail_settings: function()
	{	
		$('#email-settings-sendfrom-save').button({
			label: 'Save'
		});
		//Populate the current send from email
		$('#email-settings-sendfrom').val(X4HUser.email_sendfrom);
		
		$('#email-settings-signature-preview').html($('#email-signature').html());
	},
	/*show_mail_settings: function()
	{
		$('#content-email-settings').dialog({
                title: "Email Settings",
                resizable: true,
                height: 600,
                width: 700,
                modal: true
        });
	},*/
	prefill_signature: function()
	{
		//Based on the send email as setting build the signature for the user
		var aHTML = [];
		var document = new Object();
		if(X4HUser.email_sendfrom.indexOf('@firstfolio.com.au') > -1)
		{
			//Get the First folio content
			document.id = '41580';
		}
		else if(X4HUser.email_sendfrom.indexOf('@leasechoice.com.au') > -1)
		{
			document.id = '41583';
		}
		else if(X4HUser.email_sendfrom.indexOf('@echoice.com.au') > -1)
		{
			document.id = '41586';
		}
		else if(X4HUser.email_sendfrom.indexOf('@nationalfinanceclub.com.au') > -1)
		{
			document.id = '41587';
		}
		else
		{
			//Generic Signature of First Folio
			document.id = '41580';
		}
		document.includecontent = '1';
		this.find_document(document, 'email-signature');
	},
	find_document: function(document, container)
	{
		x4hubProxy.call(
			[X4HEmail, 'find_document_response', container], 
			   '/ondemand/document/?method=DOCUMENT_SEARCH',
			   document
			);
	},
	find_document_response: function(documents, container)
	{
		if(documents.data.rows.length > 0) 
		{
			$.each(documents.data.rows, function(key, row) {
				$('#' + container).html(myappmaster.html_decode(this.content));
			});
			X4HEmail.change_signature();
			X4HEmail.prefill_mail_settings();
		}
	},
	change_signature: function()
	{
		//Email Signature Replace
		$('#email-signature .email-sender-name').text(X4HUser.name);
		$('#email-signature .email-sender-email').text(X4HUser.email_sendfrom);
		$('#email-signature .email-sender-title').text(X4HUser.role);
		
		$('#email-signature .email-sender-streetaddress1').text(X4HUser.address_street1 + ', ');
		$('#email-signature .email-sender-streetaddress2').text(X4HUser.address_street2 + ', ');
		$('#email-signature .email-sender-streetsuburb').text(X4HUser.address_suburb + ' ');
		$('#email-signature .email-sender-streetstate').text(X4HUser.address_state + ' ');
		$('#email-signature .email-sender-streetpostcode').text(X4HUser.address_postcode);
		
		if(X4HUser.mobile != '')
		{
			$('#email-signature .email-sender-mobile-container').show();
			$('#email-signature .email-sender-mobile').text(X4HUser.mobile);
		}
		else
		{
			$('#email-signature .email-sender-mobile-container').hide();
		}
		if(X4HUser.fax != '')
		{
			$('#email-signature .email-sender-fax-container').show();
			$('#email-signature .email-sender-fax').text(X4HUser.fax);
		}
		else
		{
			$('#email-signature .email-sender-fax-container').hide();
		}
		if(X4HUser.phone != '')
		{
			$('#email-signature .email-sender-phone-container').show();
			$('#email-signature .email-sender-phone').text(X4HUser.phone);
		}
		else
		{
			$('#email-signature .email-sender-phone-container').hide();
		}
	},
	add_email_tinymce: function()
	{
		tinyMCE.execCommand('mceAddControl', true, 'field-email-content');
		var tmp_instance = tinyMCE.get('field-email-content');
		if(tmp_instance != undefined) {
			tmp_instance.setContent($('#field-email-content').val());
		}
	},
	create_draft: function()
	{
		x4hubProxy.call(
		[X4HEmail, 'create_draft_response'], 
			'/ondemand/messaging/?method=MESSAGING_EMAIL_DRAFT_MANAGE',
			{
				'new' : '1'
			}
		);
	},
	create_draft_response: function(response)
	{
		X4HEmail.email_draft_id = response.id;
	},
	
	file_upload: function()
	{
		$('.email-attach-status').html('<i>Uploading...</i>');
		$('.email-attach-progress').progressbar({
			value: 1
		});
		x4hubProxy.call(
		[X4HEmail, 'file_upload_response'], 
			'/ondemand/core/?method=CORE_ATTACHMENT_INITIALISE_PROGRESS'
		);
	},
	file_upload_response: function(response)
	{
		var oForm = document.frmonDemandFileUpload;
		var iOnDemandTimerCount = 0;
		oForm.submit();
		X4HEmail.file_upload_status = setInterval('X4HEmail.file_upload_status_check(' + response.progress + ')', 3500);
	},
	file_upload_status_check: function(progress)
	{
		x4hubProxy.call(
		[X4HEmail, 'file_upload_status_check_response'], 
			'/ondemand/core/?method=CORE_ATTACHMENT_PROGRESS_PERCENTAGE',
			{
				progress: progress
			}
		);
	},
	file_upload_status_check_response: function(response)
	{
		//alert(response.transfercomplete);
		if(response.percentage != '100')
		{
			$('.email-attach-progress').progressbar( "option", "value", Math.round(response.percentage) );
		}
		else
		{
			$('.email-attach-progress').progressbar( "option", "value", 100 );
			clearInterval(X4HEmail.file_upload_status);
			X4HEmail.search_draft_attachments();
		}
	},
	search_draft_attachments: function()
	{
		x4hubProxy.call(
		[X4HEmail, 'search_draft_attachments_response'], 
			'/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
			{
				'object' : '17',
				'objectcontext' : X4HEmail.email_draft_id
			}
		);
	},
	search_draft_attachments_response: function(attachments)
	{
		$('#oFile0').val('');
		var aHTML = [];
		if(attachments.data.rows.length > 0) 
		{
			$.each(attachments.data.rows, function(key, row) {
				aHTML.push('<div id="attachid-' + this.attachment + '" class="file-row">' +
								'<div class="email-attachment-filename">' +
									'<a href="'+ x4hubProxy.site_url + this.link + '" >' + this.filename + '</a>&nbsp;--&nbsp;' +
									'<div class="email-attachment-checkbox">' +
										'<span id="removeid-' + this.attachment + '" class="email-attachment-remove">&nbsp;</span>' +
									'</div>' +		
								'</div>' +
							'</div>');
			});
		}
		else
		{
			aHTML.push('<span class="email-attach-status"><i>No Attachments...</i></span><div class="email-attach-progress"></div>');
		}
		$('.email-attach-container').html(aHTML.join(''));
			
		//Make the Remove buttons buttons
		$('.email-attachment-remove').button({
			text: false,
			icons: {
					primary: "ui-icon-close"
				},
				label: "Delete"
		});
	},
	remove_draft_attachment: function(attachment_id)
	{
		$('#attachid-' + attachment_id).fadeOut();
		x4hubProxy.call(
		[X4HEmail, 'remove_draft_attachment_response'], 
			'/ondemand/core/?method=CORE_ATTACHMENT_MANAGE',
			{
				'remove' : '1',
				'id' : attachment_id
			}
		);
	},
	remove_draft_attachment_response: function (response)
	{
		myappmaster.add_message('Attachment Removed', 5);
		X4HEmail.search_draft_attachments();
	},
	search_projects: function(container, callback)
	{
		 var oXML = "<advancedSearch>"
            + "<field><name>reference</name></field>"
			+ "<field><name>description</name></field>"
            + "<field><name>startdate</name></field>"
            + "<field><name>status</name></field>"
            + "<field><name>statustext</name></field>"
			+ "<field><name>template</name></field>"
            + "<field><name>type</name></field>"
            + "<field><name>typetext</name></field>"
			+ "<field><name>modifieddate</name></field>"
			+ "<field><name>modifieduser</name></field>"
			+ "<field><name>modifiedusertext</name></field>"
			+ "<field><name>sq6976</name></field>"
			+ "<sort><name>description</name><direction>asc</direction></sort>"
            + "<summaryField>"
			+ "<name>count auditcount</name>"
			+ "</summaryField>"
            + "<options>"
			+ "<rf>json</rf>"
			+ "<startrow>0</startrow>"
			+ "<rows>50</rows>"
			+ "</options>"
			+ "</advancedSearch>";
		console.log('Search Folders');	
		if(container == null)
		{
			var container = 'email-project-list';
		}
		if(callback == null)
		{
			var callback = 'search_projects_response';
		}
		x4hubProxy.call(
		[X4HEmail, callback, container], 
			'/ondemand/project/?method=PROJECT_SEARCH',
			{
				advanced: 1,
				data: oXML
			}
		);
	},
	search_projects_response: function(response, container)
	{
		var aHTML = [];
		if(response.data.rows.length > 0) 
		{
			$.each(response.data.rows, function(key, row) {
				if(this.sq6976 == 'parent')
				{
					//PARENT
					aHTML.push('<div class="parent-accordion parent-accordion-format parent-accordian-override">');
					aHTML.push('<h3><a href="#" class="parentfolder format-parentfolder accordian-format-override" id="parentfolder-' + this.id + '">' + this.description + '</a></h3>');
					aHTML.push('<div id="parentfoldercontent-' + this.id + '" class="parentfoldercontent parentfoldercontent-format parentfoldercontent-override">');
					aHTML.push('');
					aHTML.push('</div>');
					aHTML.push('</div>');
				}
				if(this.sq6976 == 'orphan')
				{
					//ORPHAN
					aHTML.push('<div class="folder-hover-format"><div class="orphanfolder folder-format folder-override" id="folder-' + this.id + '"><span class="foldertitle">' + this.description + '</span> <span class="foldercount" id="foldercount-' + this.id + '">0</span></div></div>');
				}
				if(this.sq6976 != 'orphan' && this.sq6976 != 'parent')
				{
					//CHILD WHICH should sit under its parent
					aHTML.push('<div class="folder-hover-format"><div class="childfolder folder-format folder-override" id="folder-' + this.id + '-' + this.sq6976 + '"><span class="foldertitle">' + this.description + '</span> <span class="foldercount" id="foldercount-' + this.id + '">0</span></div></div>');
				}
			});
		}
		else
		{
			aHTML.push('<div><i>No Projects Found...</i></div>');
		}
		$('#' + container).html(aHTML.join(''));
		
		//Now cycle through the children and push them into the right area. beneath their parent
		$('#email-project-list').find('.childfolder').each(function(index)
		{
			var aParent = $(this).attr('id').split('-');
			$(this).parent('.folder-hover-format').appendTo('#parentfoldercontent-' + aParent[2]);
			$(this).show();
		});
				
		$('.parent-accordion').accordion(
		{
			autoHeight: false,
			collapsible: true,
			active:false
		});
	},
	search_projects_list_response: function(response, container)
	{
		var aHTML = [];
		if(response.data.rows.length > 0) 
		{
			$.each(response.data.rows, function(key, row) {
				if(this.sq6976 == 'parent')
				{				
					aHTML.push('<div class="assign-project-parent-container" id=""><input type="checkbox" class="project-assign-select"><div class="popup-project-name" id="projectlist-' + this.id +'">' + this.description + '</div></div>');
				}
				if(this.sq6976 == 'orphan')
				{
					aHTML.push('<div class="assign-project-container" id=""><input type="checkbox" class="project-assign-select"><div class="popup-project-name" id="projectlist-' + this.id +'">' + this.description + '</div></div>');
				}
				if(this.sq6976 != 'orphan' && this.sq6976 != 'parent')
				{
					aHTML.push('<div class="assign-project-container project-child-container" parent-project="' + this.sq6976 + '"><input type="checkbox" class="project-assign-select"><div class="popup-project-name" id="projectlist-' + this.id +'"><span class="project-parent-title">&nbsp;</span>' + this.description + '</div></div>');
				}
			});
		}
		else
		{
			aHTML.push('<div><i>No Projects Found...</i></div>');
		}
		$('#' + container).html(aHTML.join(''));
		
		$('.project-child-container').each(function(index)
		{
			$(this).find('.project-parent-title').text($('#projectlist-' + $(this).attr('parent-project')).text() + ' > ');
		});
	},
	show_assign_project: function(email_id, jsEvent, bAction)
	{
		var scrollTop = $(window).scrollTop();
        var scrollLeft = $(window).scrollLeft();
        var elemX = jsEvent.pageX-scrollLeft;
        var elemY = jsEvent.pageY-scrollTop;
        
		X4HEmail.search_projects('assign-project-list', 'search_projects_list_response');
		
		//Create a new project bind
		$('.create-new-project').unbind('click').click(function(event) {
			//Close the popup
			$( '#project-assign' ).dialog( 'close' );
		
			//Create the project 
			if($('#popup-project-title').val() != '')
			{
				var project = new Object();
				project.description = $('#popup-project-title').val();
				project.contactbusiness = '1290915';
				project.reference = $('#popup-project-title').val();
				project.sq6976 = 'orphan';
				
				var email = new Object();
				email.bAction = bAction;			
				email.id = email_id;
				X4HEmail.create_new_project(project, null, email);
			}
			else
			{
				//Its blank
				alert('Please enter a title');
				$('#popup-project-title').css('background-color','red');
			}
		});
		
		$('#popup-project-assign-button').button({
			label: 'Assign Project'
		}).unbind('click').click(function(event)
		{
			if($.isArray(email_id))
			{
				var aEmailArray = email_id;
			}
			else
			{
				var aEmailArray = [email_id];
			}
			X4HEmail.project_id = myappmaster.find_id($('.project-assign-select:checked').siblings('.popup-project-name').attr('id'));
			
			if(bAction)
			{
				 $( '#project-assign' ).dialog( 'close' );
				//Is an action
				X4HEmail.assign_to_project(aEmailArray, X4HEmail.project_id);
			}
			else
			{
				 $( '#project-assign' ).dialog( 'close' );
				//Still an email
				X4HEmail.save_mail(aEmailArray, 'PROJECT');
			}
		});
				
        $( '#project-assign' ).dialog({
                resizable: false,
                height: 230,
                width: 300,
				modal: true,
				stack: false,
				open: function(event,ui) {
					$('.ui-widget-overlay').css('opacity', '0.0');
				},
				close: function(event,ui) {
					$('.ui-widget-overlay').css('opacity', '');
				},
                position : [elemX,elemY],
                dialogClass : 'project-popup',
                draggable : false,
				title: 'Select Project'
        });
		
	},
	assign_to_project: function(aEmailArray, project_id)
	{
		$(aEmailArray).each(function(index)
		{
			var action = new Object();
			action.id = aEmailArray[index];
			action.linktype = '1';
			action.linkid = X4HEmail.project_id;
			X4HEmail.hide_mail(null, null, aEmailArray[index]);	
			
			x4hubProxy.call(
			[X4HEmail, 'assign_to_project_response'], 
				'/ondemand/action/?method=ACTION_MANAGE',
				action
			);
		});
	},
	assign_to_project_response: function(response)
	{
		myappmaster.add_message('Moved to Project', 5);
		$('#email-link-title').text($('#folder-' + X4HEmail.project_id).find('.foldertitle').text());
	},
	create_project_folder_tab: function(folder_id, sTitle)
	{
		if($('.projectfoldertab').length > 0)
		{
			$('.projectfoldertab').remove();
			$('#email-nav').tabs('remove',$('#email-nav').tabs("length")-1);
		}
		var project_folder_tab = '';
		$('#email-nav').tabs("add","#projectfolder-" + folder_id, sTitle);
		project_folder_tab = $('#email-nav').find("#projectfolder-" + folder_id);
		project_folder_tab.addClass("tabbed-section");	
		project_folder_tab.addClass("projectfoldertab")
		project_folder_tab.css('padding','0');
		$('#email-panel').append(project_folder_tab);
			
			//Now build the content for the panel
			project_folder_tab.append('<div id="middle-emails-no-tab">'
									  + 	'<div id="dash-emails-header">'
									  +	    	'<h1>' + sTitle + '</h1>'
									  +     '</div>'
									  +      '<div id="emails-nav" class="dash-emails-nav-layout">'
									  + 		'<div id="emails-nav-drop">'
									  +				'<input type="checkbox" />'
									  +			'</div>'
									  +     	'<div id="emails-nav-btn01" class="compose-mail">'
									  +				'<a href="#"><img src="/assets/images/email-img03.png" /></a>'
									  +			'</div>'
									  +       '<div id="tab-emails-nav-btn02">'
									  +			'<a href="#"><span class="markasprivate">Private</span></a>'
									  +			'<a href="#"><span class="deletemail">Delete</span></a>'
									  +			'<a href="#"><span class="movemail">Move to Project</span>'
									  +			'<div class="moveselectdiv">'
									  +				'<span class="moveselect" id="move-PRIVATE">Private</span>'
									  +				'<br />'
									  +			'<span class="moveselect" id="move-PUBLIC">Public</span>'
									  +		  '</div>'
									  +			'</a>'
									  +       '</div>'
									  +       '<div id="emails-search">'
									  + 	  	'<input type="text" />'
									  +         '<a href="#"><img src="/assets/images/search-btn01.png" /></a><br /><br />'
									  +        '</div>'
									  + 	'</div>'
									  +  '<div id="project-emails-body" class="dash-emails-body-layout">'
									  +		'&nbsp;'
									  +  '</div>'
									  +'<div id = "emails-footer" class="dash-emails-footer-layout">'
									  +		'<div id="project-emails-body-pagination" class="pagination-area"></div>'
									  //+		'<span id="nav-email"  href="#">&nbsp;</span><span class="footer-paginate"><span class="start-results">0</span> of <span class="end-results">0</span></span>'
									  +'</div>'
									  +'</div>'
									  +'</div>');
			
			$('#email-nav').tabs('select', '#projectfolder-' + folder_id);    
	},
	create_new_project:function(project, callback, email)
	{
		if(callback == undefined)
		{
			callback = 'create_new_project_response';
		}
		if(parent == undefined)
		{
			parent = '';
		}
		x4hubProxy.call(
		[X4HEmail, callback, email], 
			'/ondemand/project/?method=PROJECT_MANAGE',
			project
		);
	},
	create_new_project_response: function(response, email)
	{
		if(response.status != 'ER')
		{
			myappmaster.add_message('New Project Created', 5);
			X4HEmail.search_projects();
			X4HEmail.project_id = response.id;
			if(email == null)
			{
			
			}
			else
			{
				//Save the email to project
				if(email.bAction == true)
				{
					//ACTION SO CHANGE LINK
					var aEmailArray = [email.id];
					X4HEmail.assign_to_project(aEmailArray, X4HEmail.project_id);
				}
				else
				{
					//EMAIL TO NEED TO SAVE
					var aEmailArray = [email.id];
					X4HEmail.save_mail(aEmailArray, 'PROJECT');
				}
			}
		}
	},
	/*create_new_project: function(email_id)
	{
		
		x4hubProxy.call(
		[X4HEmail, 'create_new_project_response'], 
			'/ondemand/project/?method=PROJECT_MANAGE',
			project
		);
	},
	create_new_project_response: function(response)
	{
		myappmaster.add_message('New Project Created', 5);
		$('#assign-project-list').html('<div id="scheduled-events-preloader">'
										+ '<span>Loading Projects  <img src="/assets/images/preloader2.gif"></span>'
										+ '</div>');
		//Search projects again for foreground load
		X4HEmail.search_projects('assign-project-list', 'search_projects_list_response');
		
		//Search of the projects again. For background load
		X4HEmail.folder_search = null;
		this.count_folder_actions();
	},*/
	create_project_tab: function(project_id, sTitle)
	{
		if($('.projectoverviewtab').length > 0)
		{
			$('.projectoverviewtab').remove();
			$('#projects-nav').tabs('remove',$('#projects-nav').tabs("length")-1);
		}
		var project_overview_tab = '';
		$('#projects-nav').tabs("add","#projectoverview-" + project_id, sTitle);
		project_overview_tab = $('#projects-nav').find("#projectoverview-" + project_id);
		project_overview_tab.addClass("tabbed-section");	
		project_overview_tab.addClass("projectoverviewtab")
		$('#project-panel').append(project_overview_tab);
			
			//Now build the content for the panel
			project_overview_tab.append('<div class="project-email-container">'
										+ '<div class="tabbed-content-header" id="project-discussions-header">'
										+ '<h1>Emails</h1>'
										+ '</div>'
										+ '<div class="project-emails-overview">'
										+ 	'<div class="project-email-header-row">'
										+			'<div class="project-email-subject_header project-email-header-format"><span>Subject</span></div>'
										+			'<div class="project-email-from_header project-email-header-format"><span>From</span></div>'
										+			'<div class="project-email-to_header project-email-header-format"><span>To</span></div>'
										+			'<div class="project-email-date_header project-email-header-format"><span>Date</span></div>'
										+		'</div>'
										+		'<div class="project-email-body">'
										+		'<div class="preloader-project-email">'
										+ 			'<span><img src="/assets/images/preloader.gif" /><br  /><span class="load-status">loading...</span></span>'
										+		'</div>'
										+		'</div>'
										
										+		'<div class="project-email-footer">'
										+			'<span class="footer-paginate">'
										+				'<span class="start-results">0</span> of '
										+				'<span class="end-results">0</span>'
										+			'</span>'
										+		'</div>'
										+	'</div>'
										+	'<div class="project-discuss-container">'
										+		'<div class="tabbed-content-header" id="project-discussions-header">'
										+			'<h1>Discussions</h1>'
										+		'</div>'
										+		'<div class="project-discuss-header-row">'
										+			'<div class="project-discuss-title_header project-discuss-header-format"><span>Title</span></div>'
										+			'<div class="project-discuss-description_header project-discuss-header-format"><span>Description</span></div>'
										+			'<div class="project-discuss-updated_header project-discuss-header-format"><span>Last Updated</span></div>'
										+		'</div>'
										+		'<div class="project-discussion-body">'
										+		'<div class="preloader-project-discuss">'
										+ 			'<span><img src="/assets/images/preloader.gif" /><br  /><span class="load-status">loading...</span></span>'
										+		'</div>'
										+		'</div>'
										+		'<div class="project-discuss-footer">'
										+			'<span href="#" id="">&nbsp;</span><span class="footer-paginate"><span class="start-results">0</span> of <span class="end-results">0</span></span>'
										+		'</div>'
										+	'</div>');		
			
			$('#projects-nav').tabs('select', '#projectoverview-' + project_id);    
	},
	load_project_tab: function(project_id)
	{
		//Search Emails in the project
		this.search_folder(project_id, null, 'search_project_emails_response');
				
		//Search Discussions in the project
		this.search_project_discussion(project_id, 'search_project_discussion_response', 'project-discussion-body');
	},
	search_project_emails_response: function(emails)
	{
		myappmaster.add_message('Search Mail Project', 5);
		var iRows = '0';
		if(emails.status != 'ER')
		{
			iRows = emails.rows;
			var aHTML = [];
			$('.email-load').remove();
			var aRow = [];
			
			//Loop through each Row and create the emails row
			if(emails.data.rows.length > 0) 
			{
				$.each(emails.data.rows, function(key, row) {
					aRow = [];
					var sFromName = this.contactpersontext;
					var sDate = this.duedatetime;
					var sTo = this.actionbytext;
					
					//Sample 18 Oct 2011 12:49:46
					var dDate = $.fullCalendar.parseDate( sDate )
					sDate = $.fullCalendar.formatDate(dDate, 'hh:mm tt dd/MM/yyyy');
					
					var sSubject = this.actionreference;
					var iMailId = this.id;
										
					//Find out if the email was recieved today
					if(X4HEmail.today_date.getDate() == dDate.getDate() && X4HEmail.today_date.getMonth() == dDate.getMonth() && X4HEmail.today_date.getFullYear() == dDate.getFullYear())
					{			
						sDate = $.fullCalendar.formatDate(dDate, 'hh:mm tt');
					}
					else
					{
						sDate = $.fullCalendar.formatDate(dDate, 'hh:mm tt dd/MM/yyyy');
					}
				
					aRow.push('<div id="emailproject-' + iMailId + '" class="project-email-row">');
					aRow.push('<div class="project-email-col-1 project-email-cols-format"><span>' + sSubject + '</span></div>');
					aRow.push('<div class="project-email-col-2 project-email-cols-format">' + sFromName + '</div>');
					aRow.push('<div class="project-email-col-3 project-email-cols-format">' + sTo + '</div>');		
					aRow.push('<div class="project-email-col-4 project-email-cols-format">' + sDate + '</div>');
					aRow.push('</div>');
					
					aHTML.push(aRow.join(''));
				});
				//Add the total to the paginate area
				var sReturned = emails.data.rows.length;
				
				//Need to check if this is an init to push to both tabs (dash and email)
				$('.project-email-body').html(aHTML.join(''));
				//Change the total at the bottom of the list
				$('.project-email-footer').find('.start-results').text('1' + '-' + sReturned);
				$('.project-email-footer').find('.end-results').text(parseInt(emails.summary.auditcount));
			}
			else
			{
				console.log("No Mail found in Project");
			}
		}
		else
		{
			console.log("Problem searching actions");
		}
	},
	search_project_discussion: function(project_id, callback, container)
	{
		var fields = ['title','description','object','objectcontext','owner','ownertext','postcount','commentcount', 'modifieddate'];
		var filters = [
					{
						name : 'objectcontext',
						comparison : 'EQUAL_TO',
						value1 : project_id
					}
				];
		var oXML = new X4HASearch(fields, filters, null, null).getXML();
		x4hubProxy.call(
            [this, callback, container], 
                '/ondemand/messaging/?method=MESSAGING_CONVERSATION_SEARCH', 
                {
					advanced:1,
					data: oXML,
                }
        );
	},
	search_project_discussion_response: function(response, container)
	{
		var aHTML = [];
		if(response.data.rows.length > 0)
		{
			var conversation_result = response.data.rows;
            var conversations = '';
            $.each(conversation_result,function(key,row){
                aHTML.push('<div class="project-discuss-row" id="project-discuss-' + row.id + '">');
				aHTML.push('<div class="project-discuss-col-1 project-discuss-cols-format"><span>');
				aHTML.push(row.title);
				aHTML.push('</span></div>');
				aHTML.push('<div class="project-discuss-col-2 project-discuss-cols-format"><span>');
				aHTML.push(row.description);
				aHTML.push('</span></div>');
				aHTML.push('<div class="project-discuss-col-3 project-discuss-cols-format"><span>');
				aHTML.push(row.lastupdatedatetime);
				aHTML.push('</span></div>');
				aHTML.push('</div>');
			})
		}
		else
		{
			aHTML.push('<div><span>No Discussions linked to this project</span></div>');
		
		}
		
		$('.' + container).html(aHTML.join(''));
		//Put the counts in
		
	},
	show_create_project_modal: function(jsEvent)
	{
		var scrollTop = $(window).scrollTop();
        var scrollLeft = $(window).scrollLeft();
        var elemX = jsEvent.pageX-scrollLeft;
        var elemY = jsEvent.pageY-scrollTop;
		 $('.create-new-linked-project').button();
		 $('#popup-project-create-footer').css('padding','0');
		 $( '#project-create' ).dialog({
                resizable: false,
                height: 160,
                width: 400,
                stack: false,
				modal: true,
				open: function(event,ui) {
					$('.ui-widget-overlay').css('opacity', '0.0');
				},
				close: function(event,ui) {
					$('.ui-widget-overlay').css('opacity', '');
				},
                position : [elemX,elemY],
                dialogClass : 'project-popup',
                draggable : false,
				title: 'Create New Project'
        });
	},
	search_project_parents: function(callback, container)
	{
		var oXML = "<advancedSearch>"
            + "<field><name>reference</name></field>"
			+ "<field><name>description</name></field>"
            + "<field><name>startdate</name></field>"
            + "<field><name>status</name></field>"
            + "<field><name>statustext</name></field>"
			+ "<field><name>template</name></field>"
            + "<field><name>type</name></field>"
            + "<field><name>typetext</name></field>"
			+ "<field><name>modifieddate</name></field>"
			+ "<field><name>modifieduser</name></field>"
			+ "<field><name>modifiedusertext</name></field>"
			+ "<field><name>sq6976</name></field>"
			+ "<filter>"
			+ "<name>sq6976</name><comparison>EQUAL_TO</comparison><value1>parent</value1>"
			+ "</filter>"
			+ "<sort><name>description</name><direction>asc</direction></sort>"
            + "<summaryField>"
			+ "<name>count auditcount</name>"
			+ "</summaryField>"
            + "<options>"
			+ "<rf>json</rf>"
			+ "<startrow>0</startrow>"
			+ "<rows>50</rows>"
			+ "</options>"
			+ "</advancedSearch>";
		
		if(callback == null)
		{
			callback = 'search_project_parents_response';
		}
		if(container == null)
		{
			container = 'popup-project-create-parent';
		}
		x4hubProxy.call(
		[X4HEmail, callback, container], 
			'/ondemand/project/?method=PROJECT_SEARCH',
			{
				advanced: '1',
				data: oXML
			}
		);
	},
	search_project_parents_response: function(response, container)
	{
		var aHTML = [];
		aHTML.push('<option value="orphan">- None - Orphan-</option>');
		aHTML.push('<option value="parent">- None - Parent -</option>');	
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				aHTML.push('<option value="' + this.id + '">' + this.reference + '</option>');				
			});
		}
		else
		{
			//No parent Projects		
		}
		$('#popup-project-create-parent').html(aHTML.join(''));
	}
}