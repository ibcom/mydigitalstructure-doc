var X4HAttach = {
    iFrame: 'x4hUploadFrame',
    timeout: 120,
    interval: 1,
    formSubmissions: {},
    submitForm: function(formName) {
        if(this.formSubmissions.formName != undefined) {
            console.log(formName + " is already in a state of submission");
            return false;
        }
        
        var title = $('#' + formName + ' x4hfu_title').val();
        var summary = $('#' + formName + ' x4hfu_summary').val();
        var content = $('#' + formName + ' x4hfu_content').val();
        var keywords = $('#' + formName + ' x4hfu_keywords').val();
        
        this.formSubmissions.formName = {status: 'pending', response: null};
        
        
        title = 'Test title';
        summary = 'Test Summary';
        content = null;
        keywords = null;
        
        this.manageDocumentObjectContext(title, summary, content, keywords, formName);
        
    },
    manageDocumentObjectContext: function(title, summary, content, keywords, formName) {
        var params = {};
        
        if(title != null) {
            params.title = title;
        }
        if(summary != null) {
            params.summary = summary;
        }
        if(content != null) {
            params.content = content;
        }
        if(keywords != null) {
            params.keywords = keywords;
        }
        
        x4hubProxy.call(
            [this, 'manageDocumentObjectContextResponse', formName],
            '/ondemand/setup/?method=SETUP_STRUCTURE_MANAGE',
            params
        );
    },
    manageDocumentObjectContextResponse: function(response, formName) {
        /*
        if( response.data.rows.length > 0 ){
            var document_object = response.data.rows[0];
            
            // Once we have the document object - set the values to the nodes
        }
        */
        if(response.status == undefined || response.status != 'OK') {
            console.log("Error creating an object");
            console.log(response);
            return false;
        }
        
        var object_context_id = response.id;
        
        $('#' + formName).submit();
        
        this.checkSubmitStatus(formName);
        
        /*
        var timerId = setInterval(
            function() {
                X4HAttach.checkSubmitStatus(formName);
            },
            (X4HAttach.interval) * 1000
        );
        
        /*
        var jqFrame = $('#' + this.iFrame);
        jqFrame.ready(function() {
            console.log("Frame has finished loading its source");
            console.log("Body: " + jqFrame.contents().find('body').html());
        });
        */
        
        //this.checkSubmitStatus(formName);
        ///this.formSubmissions[formName] = timerId;
    },
    checkSubmitStatus: function(formName) {
        //console.log("Checking status");
        if(this.formSubmissions[formName] == undefined) {
            console.log("Can not check if form has been submitted - " + formName);
        }
        
        var targetIFrame = document.getElementById(this.iFrame);
        
        var formState = null;
        
        if (targetIFrame.readyState) 	{
            //IE
            formState = targetIFrame.readyState;
        } else {
            if (targetIFrame.contentDocument.body.innerHTML == 'OK') {
                formState = 'complete';
            } else {
                formState = targetIFrame.contentDocument.body.innerHTML;
            }
        }

        if(formState == 'complete') {
            clearinterval(this.formSubmissions[formName]);
            delete this.formSubmissions[formName];
            console.log("File upload completed");
        } else {
            console.log("Currently form is not completed: " + formState);
            console.log(targetIFrame.contentDocument.body);
        }
    }
}