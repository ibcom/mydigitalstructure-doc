var X4HSetup = {
    object_id: 19,
    object_name: 'Setup',
	year_milliseconds: 31556926000,
	default_contact_business: '1290915', //FF Business ID
	user_contact_person: '',
	selected_network_group: '',
	selected_project: '',
	create_setup_div: function() {
		X4HSetup.show_tab();	
		//Create the User Modal ready for population of data
		//X4HSetup.user_modal_create();
		//Find the list of users on the system
		X4HSetup.user_list();
                
                //bind the search after user has been loaded
                $('#user-search-btn').click(function(){
                   var criteria  = $('#user-search-dropdown').val();
                   var filters = null;
                   if(criteria!=='all'){
                       var query_string = $('#user-filter').val();
                       console.log(query_string);
                       filters  = [{
                               name : criteria,
                               comparison : 'TEXT_IS_LIKE',
                               value1 : query_string
                       }];
                   
                   }
                   //reset pagination
                   $('#user-main-list-pagination').html('');
                   X4HSetup.user_list(null,filters);
                });
		X4HSetup.bind_element_triggers();
    },
	show_tab: function() {
		$( ".setup-tab").show();
		$( "#middle-nav").tabs("select","#tab-setup");
		
		$( "#setup-nav" ).bind( "tabsselect", function(event, ui) {
			if(ui.tab.hash == '#setupNetworkGroups')
			{
				X4HSetup.hide_network_group_panels();
				//load the network group tab
				//Search for network groups available
				$('.network-groups-left-nav').html('<span>Loading Groups <img src="/assets/images/preloader2.gif" /></span>');
				X4HSetup.search_network_groups();
			}
			if(ui.tab.hash == '#adminProjects')
			{
				X4HSetup.hide_project_panels();
				//load the projects tab
				//Search for projects available
				X4HSetup.search_projects();
			}
		});
		
		//apply filter fix
        $('#user-search-dropdown').each(function(){
            var title = $(this).attr('title');
            if( $('option:selected', this).val() != ''  ) title = $('option:selected',this).text();
            $(this)
                .css({'z-index':10,'opacity':0,'-khtml-appearance':'none'})
                .after('<span id = "user-search-span">' + title + '</span>')
                .change(function(){
                    val = $('option:selected',this).text();
                    $(this).next().text(val);
                    })
        });
	},
    user_list: function(fields,filters,options,sort,callback,container) {
        fields = (fields==null)?['username','manager','disabled', 'ContactBusinessText', 'ContactPersonFirstName', 'ContactPersonSurname', 'ContactPersonEmail']:fields;
        
        var oXML = new X4HASearch(fields, filters, options, sort).getXML();
        
		if(callback == null)
		{
			callback = 'user_list_return';
		}
		if(container == null)
		{
			container = 'user-main-list';
		}
		
	    x4hubProxy.call([X4HSetup, callback, container], 
			'/ondemand/setup/?method=SETUP_USER_SEARCH',
			{
                            advanced : 1,
                            data: oXML,
                            rows:500
            }
		);
	},
    user_list_return: function(response, container) {
		$('.preloader-setup').hide();
		//Loop through the users returned and insert into the HTML
        //console.log(response.data.rows.length + ' going into ' + container);
		var aHTML = [];
		//aHTML.push('<table class="user-table"><tbody>');
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {				
				if(row.disabled == 'Y')
				{
					var disableAnchor = 'Enable User'
					var disableStatus = 'Disabled'
				}
				else
				{
					var disableAnchor = 'Disable User'
					var disableStatus = 'Enabled'
				}
				aHTML.push('<div id="user-row-' + row.id + '" class="user-row">')
				aHTML.push('<div class="user-id">' + row.id + '</div>');
				aHTML.push('<div class="user-username">' + row.username + '</div>');
				aHTML.push('<div class="user-status">' + disableStatus + '</div>');
				aHTML.push('<div class="user-options"><span id="user-edit-' + row.id + '" class="user-edit-anchor">Edit</span><span id="userdisabled-' + row.disabled + '-' + row.id + '" class="user-disable-anchor">' + disableAnchor + '</span></div>');
				aHTML.push('</div>');
				aHTML.push('<div class="user-line"></div>');
			});
			//aHTML.push('</tbody></table>');
			$('#' + container).html(aHTML.join(''));
			
        }else{
            $('#user-main-list').html('<p>Your search returned no results.</p>');
        }
        
    },
	
	bind_element_triggers: function() {
        $('body').delegate('.user-edit-anchor', 'click', function() 
		{
		// Find out the id of what we're dealing with
                var user_id = myappmaster.find_id($(this).attr('id'));
                //console.log('Id: ' + id);
                var oXML = '<advancedSearch>' +
				           '<field><name>billable</name></field>' +
						   '<field><name>ContactBusiness</name></field>' + 
						   '<field><name>ContactBusinessText</name></field>' + 
						   '<field><name>ContactPerson</name></field>' +
						   '<field><name>ContactPersonText</name></field>' +
						   '<field><name>Disabled</name></field>' +
						   '<field><name>DisabledDate</name></field>' +
						   '<field><name>DisabledReason</name></field>' +
						   '<field><name>Manager</name></field>' +
						   '<field><name>ManagerText</name></field>' +
						   '<field><name>NewsAlerts</name></field>' +
						   '<field><name>PasswordExpiry</name></field>' +
						   '<field><name>ServiceAlerts</name></field>' +
						   '<field><name>SessionTimeout</name></field>' +
						   '<field><name>SupportContactList</name></field>' +
						   '<field><name>TimeZoneOffset</name></field>' +
						   '<field><name>Type</name></field>' +
						'<field><name>TypeText</name></field>' +
						'<field><name>username</name></field>' +
						'<filter><name>id</name><comparison>EQUAL_TO</comparison><value1>' + user_id + '</value1></filter>' + 
						'<options><rf>JSON</rf><startrow>0</startrow><rows>20</rows></options>' +
						'</advancedSearch>';
            x4hubProxy.call(
				[X4HSetup, 'user_prefill_modal', 'user-manage-screen'], 
                '/ondemand/setup/?method=SETUP_USER_SEARCH&advanced=1',
                {
                    data: oXML
                }
            );
		});
		
		//Make the buttons buttons
		$('#network-groups-button-add').button({
			label:'New Group'
		}).click(function(event)
		{
			$('.network-group-parent').removeClass('network-group-selected');
			X4HSetup.hide_network_group_panels();
			$('.network-groups-create-groups-container').show();
		});
		
		$('#network-groups-button-edit').button({
			label:'Edit Group'
		}).click(function(event)
		{	
			if($('.network-group-selected').length > 0)
			{
				X4HSetup.search_network_groups('show_network_group_details_response', X4HSetup.selected_network_group);
				X4HSetup.search_network_groups_user();
			
				X4HSetup.hide_network_group_panels();
				$('.network-groups-edit-groups-container').show();
			}
			else
			{
				alert('Please Select a Network Group to Edit');
			}
		});
		
		$('.network-group-edit-group-close').button({
			label: 'Save & Close'
		}).click(function(event)
		{
			//Save the network group changes
			X4HSetup.create_network_group(
			{
				id: X4HSetup.selected_network_group,
				notes: $('#field-edit-group-description').val(),
				title: $('#field-edit-group-name').val()
			});
			X4HSetup.hide_network_group_panels();
		});
		
		$('.add-new-network-group').button({
		
		}).click(function(event)
		{
			X4HSetup.hide_network_group_panels();
		});
		
		$('#admin-projects-button-add').button({
			label: 'New Project'
		}).click(function(event)
		{
			//Clear the text fields
			$('#field-admin-new-project-name, #field-admin-new-project-description').val('');
			
			//Show add Projects
			$('.admin-projects-left-nav div').removeClass('project-selected');
			X4HSetup.hide_project_panels();
			
			$('.parent-selection').show();
			//Load Parent Choices
			X4HSetup.search_parent_projects(true);
			
			//Search available network groups
			X4HSetup.search_network_groups('search_network_groups_checklist_reponse');
			
			$('.admin-projects-create-project-container').show();
		});
        
		$('#admin-projects-button-edit').button({
			label: 'Edit Project'
		}).click(function(event)
		{
			if($('.project-selected').length > 0)
			{
				//Check if this is a parent we are editing
				if($('.project-selected').hasClass('admin-projects-parent'))
				{
					//hide the parent select area as a parent cannot be 'converted' to a orphan or child
					$('.parent-selection').hide();
				}
				else
				{
					$('.parent-selection').show();
					//Load Parent Choices
					X4HSetup.search_parent_projects(false);
				}
				
				//Show edit Projects
				X4HSetup.hide_project_panels();
				
				//Search available network groups
				$('.admin-projects-network-groups-list').html('<span>Loading Groups <img src="/assets/images/preloader2.gif" /></span>');
				X4HSetup.search_network_groups('search_network_groups_checklist_reponse');
				
				//Load Project Details
				X4HSetup.search_projects('show_project_details_response', null, X4HSetup.selected_project);
				
				$('.admin-projects-edit-projects-container').show();
			}
			else
			{
				alert('Please Select a Project to Edit');
			}
		});
		
		$('.save-new-admin-project').button({
			label: 'Save Project'
		}).click(function(event)
		{
			var project = new Object();
			project.sq6976 = $('#field-admin-parent-project-name-new').val();
			project.reference = $('#field-admin-new-project-name').val();
			project.description = $('#field-admin-new-project-description').val();
			
			X4HSetup.save_project(project);
			
			X4HSetup.hide_project_panels();
		});
		
		$('.save-admin-project').button({
			label: 'Save Project'
		}).click(function(event)
		{
			var project = new Object();
			project.id = X4HSetup.selected_project;
			project.sq6976 = $('#field-admin-parent-project-name-edit').val();
			project.reference = $('#field-edit-project-name').val();
			project.description = $('#field-edit-project-description').val();
			X4HSetup.save_project(project);
			
			X4HSetup.hide_project_panels();
		});
		
		
		
		$('.deleteproject').button({
			label: 'Delete Project'
		}).click(function(event)
		{
			X4HSetup.hide_project_panels();
			if($('#parentcontain-' + X4HSetup.selected_project).find('.admin-projects-child').length > 0)
			{
				//This parent has children
				alert('This parent has children, please remove/move the children first');
			}
			else
			{
				if($('#project-' + X4HSetup.selected_project).hasClass('admin-projects-parent'))
				{
					X4HSetup.confirm_project_delete();
				}
				else
				{
					X4HSetup.delete_project();
				}
			}
		});
	
		$('.user-disable-anchor').click(function() 
		{
			var aDisabled = $(this).attr('id').split('-');
			if(aDisabled[1] == 'N')
			{
				aDisabled[1] = 'Y';
				var sString = 'Disable';
			}	
			else
			{
				aDisabled[1] = 'N';
				var sString = 'Enable';
			}
                        
                        //if user targets self, then log the user out
                        if(myappmaster.users.id==myappmaster.find_id($(this).attr('id'))){
                            x4hubProxy.logout();
                        }else{

                            var answer = confirm("Are you sure you wish to " + sString + " this User?")
                            if (answer){
                                    X4HSetup.disable_enable_user(aDisabled[2], aDisabled[1]);
                            }
                            else
                            {

                            }
                        }
		});
		
		
		$('#setup-new-user').click(function(event){
			X4HSetup.user_show_modal('new');
		});
		
		$('#setup-showall-users').button().click(function(event){
			$('.user-disabled').slideDown();
		});
		
		$('body').delegate('.network-group-parent', 'click', function(event)
		{
			X4HSetup.selected_network_group = myappmaster.find_id($(this).attr('id'));
			//Unhighlight all
			$('.network-group-parent').removeClass('network-group-selected');
			$(this).addClass('network-group-selected');
			
			//Hide the panels
			X4HSetup.hide_network_group_panels();
		});
		
		$('body').delegate('.add-new-network-group', 'click', function(event)
		{
			X4HSetup.create_network_group();
			//Hide the edit and create area
			X4HSetup.hide_network_group_panels();
		});
		
		$('body').delegate('.admin-projects-parent, .admin-projects-child, .admin-projects-orphan', 'click', function(event)
		{
			X4HSetup.selected_project = myappmaster.find_id($(this).attr('id'));
			
			$('.admin-projects-parent, .admin-projects-child, .admin-projects-orphan').removeClass('project-selected');
			$(this).addClass('project-selected');
			
			//Hide the panels
			X4HSetup.hide_project_panels();
		});
		
		$('body').delegate('#network-group-search-username', 'keyup', function(event){
			var sTerm = $(this).val();
			if(sTerm.length > 3)
			{	
				//run Filter
				$('.not-current').not(":containsi(" + sTerm + ")").hide();
				$('.not-current:containsi(' + sTerm + ')').show();
			}
			else
			{
				//Dont run search yet
				$(".not-current").show();
			}
		});
		
		//Bind Click of the Input in the user list
		$('body').delegate('.network-group-user-row input', 'click', function(event)
		{
			//assign the user to the NG and reload
			X4HSetup.link_user_to_network_group($(this).val());
		});
		
		
		$('body').delegate('.network-group-current-user-row input', 'click', function(event)
		{
			//unlink and reload
			X4HSetup.link_user_to_network_group($(this).val(), 'remove');
		});
		
		//Bind Click of the Input in the network groups
		$('body').delegate('.admin-select-network-group input', 'click', function(event)
		{
			if($(this).attr('checked') == 'checked')
			{
				//share the project with the network group
				X4HSetup.selected_network_group = $(this).val();
				X4HSetup.share_project_with_network_group(X4HSetup.selected_project, X4HSetup.selected_network_group, null);
			}
			else
			{
				//unshare the project with the network group
				X4HSetup.selected_network_group = $(this).val();
				X4HSetup.share_project_with_network_group(X4HSetup.selected_project, X4HSetup.selected_network_group, $(this).attr('linkid'));
			}
			
			
		});
	},
	disable_enable_user: function(user_id, disabled_state) {
		x4hubProxy.call(
            [X4HSetup, 'disable_enable_user_response'],
            '/ondemand/setup/?method=SETUP_USER_MANAGE',
            {
                id: user_id,
                disabled: disabled_state
			}
		);
	},
	disable_enable_user_response: function(response)
	{
		X4HSetup.user_list();
	},
	populate_new_user: function() {
	
	},
	
	user_prefill_modal: function(response, container) {
        //Fill the modal form with the data from the selected ID
		
		//$('.preloader-modal').dialog('open');
        //$('.preloader-modal').dialog({title: 'User Details'});
		if(response.data.rows.length == 1) 
		{
		    var user = response.data.rows[0];            

            var tmpexpirydate = myappmaster.html_decode(user.passwordexpiry)
            var expirydate = new Date(tmpexpirydate.replace(/\s\d\d:\d\d:\d\d/g, ''));
            			
			// Set the field values
            var contact_id = user.contactperson;
			
			X4HUser.manager = user.manager;
			
			$('#field-user-id').val(user.id);
			
			$('#field-contactperson-id').val(user.contactperson);
			
			$('#field-setup-user-contactbusiness').val(user.contactbusinesstext);
			$('#field-setup-user-contactperson').val(user.contactpersontext);
			
            $('#field-setup-user-username').val(user.username);
			$('#field-setup-user-passwordexpiry').val($.datepicker.formatDate('dd/mm/yy', expirydate));
			
			
			$('.preloader-modal').dialog('close');
        } 
		this.find_extra_information(contact_id);
        this.user_show_modal('existing');
		
    },
    
	find_extra_information: function(contact_id) {
		var oXML = "<advancedSearch>"
            + "<field><name>firstname</name></field>"
            + "<field><name>surname</name></field>"
            + "<field><name>email</name></field>"
			+ "<field><name>dateofbirth</name></field>"
            + "<field><name>homephone</name></field>"
            + "<field><name>workphone</name></field>"
			+ "<field><name>position</name></field>"
            + "<field><name>mobile</name></field>"
            + "<field><name>streetaddress1</name></field>"
            + "<field><name>streetaddress2</name></field>"
            + "<field><name>streetsuburb</name></field>"
            + "<field><name>streetstate</name></field>"
            + "<field><name>streetsuburb</name></field>"
            + "<field><name>streetcountry</name></field>"
            + "<field><name>streetpostcode</name></field>"
			+ "<field><name>sq6856</name></field>" //LinkedIn
			+ "<field><name>sq6857</name></field>" //Twitter
			+ "<field><name>sq6858</name></field>" //Facebook
			+ "<field><name>sq6859</name></field>" //Secondary Email
			+ "<field><name>sq6860</name></field>" //Tertiary Email
			+ "<field><name>sq6861</name></field>" //Personal Email
			+ "<field><name>sq6864</name></field>" //Division
			+ "<filter>"
            + "<name>id</name><comparison>EQUAL_TO</comparison><value1>" + contact_id + "</value1>"
            + "</filter>"
            + "<options><rf>JSON</rf><startrow>0</startrow><rows>1</rows></options>"
            + "</advancedSearch>";
        
        x4hubProxy.call(
            [X4HSetup, 'populate_extra_information'],
            '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
            {
                advanced: 1,
                data: oXML
			}
		);
	},
    
	populate_extra_information: function(response) {
		var user = response.data.rows[0]; 
		$('#field-setup-user-firstname').val(user.firstname);
		$('#field-setup-user-lastname').val(user.surname);
		$('#field-setup-user-email').val(user.email);
		
		$('#field-setup-user-phone').val(user.workphone);
		$('#field-setup-user-mobile').val(user.mobile);
		
		$('#field-setup-user-position').val(user.position);
		//$('#field-setup-user-position').val(user.jobtitle);
					
		//Split the Date and Parse dateofbirth
		var aDob = user.dateofbirth.split(' ');
		$('#field-setup-user-birthday').val(aDob[0]);
		$('#field-setup-user-birthmonth').val(aDob[1]);
	},
	
	user_show_modal: function(dialogtype) {
		this.populate_reports_to_area();
		var aHTML = [];
		
		for(var i = 1; i <= 31; i++)
		{
			 aHTML.push('<option value="' + i + '">' + i + '</option>');
		}
		$('#field-setup-user-birthday').html(aHTML.join(''));
			
		aHTML = [];
		 
		$(X4HUser.monthNamesShort).each(function(i)
		{
			 aHTML.push('<option value="' + this + '">' + this + '</option>');
		});
		$('#field-setup-user-birthmonth').html(aHTML.join(''));
		
		$('#field-setup-user-passwordexpiry').datepicker({
            dateFormat: 'dd/mm/yy'
        });
		
		//Bind the options
		$('#save-user').button({
			text: false,
			icons: {
				primary: "ui-icon-disk"
			},
			label: "Save"
		})
		
        
		$('#cancel-save-user').button({
			text: false,
			icons: {
				primary: "ui-icon-close"
			},
			label: "Cancel"
		})
		.click(function(event) {
			$('#setup-nav').tabs('select', '#setupUsers');
		});
		
		if(dialogtype == 'new') 
		{
			$('#save-user').click(function(event) {
				X4HSetup.create_new_user();
				$('#setup-nav').tabs('select', '#setupUsers');
				$('#save-user').unbind('click');
			});
			$('#setup-manage-screen input').each(function(index)
			{
				$(this).val('');
			});
			$('.userMessaging, .userNetworkGroups').hide();
		}
		else
		{
			/*$('#delete-user').button({
				text: false,
				icons: {
					primary: "ui-icon-trash"
				},
				label: "Delete"
			})
			.click(function(event) {
				
			});*/
			$('#save-user').click(function(event) {
				X4HSetup.save_user();
				$('#setup-nav').tabs('select', '#setupUsers');
				$('#save-user').unbind('click');
			});
			$('.userMessaging, .userNetworkGroups').show();
		}
		
		
		//Show Tab here
		$('.setup-user-detail').show(); 
		$('#tab-user').tabs();
		$( "#setup-nav").tabs("select","#setupUserDetail");
		
		//Find the Messaging accounts for this user
		this.user_messaging_search();
		
		//Find the Network groups for this user
		this.user_networkgroups_search();
    },
	user_messaging_search: function () {
		//Call the method to search for the messaging accounts for this user
		x4hubProxy.call(
			[X4HSetup, 'user_messaging_create', 'setupUserMessaging'], 
            '/ondemand/setup/?method=SETUP_MESSAGING_ACCOUNT_SEARCH',
            {
                user: $('#field-user-id').val()
            });
	},
	user_messaging_create: function(response, container) {
		var aHTML = [];
		var iType;
		
		aHTML.push('<div class="user-messaging-table"></div>');
		aHTML.push('<span class="user-messaging-add">&nbsp;</span>');
		aHTML.push('<div class="messaging-add"></div>');
		$('#' + container).html(aHTML.join(''));
		
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				$('.user-messaging-table').append('<div id="user-messaging-row-' + row.id + '" class="user-messaging-row">'
							+ '<div class="column">' 
							+ '<div class="form-row">'
							+ '<div class="user-messaging-title"><label for="user-messaging-title">Title:</label><input type="text" value="' + row.title + '"/></div>'
							+ '</div>'
							+ '<div class="form-row">'
							+ '<div class="user-messaging-email"><label for="user-messaging-email">Email:</label><input type="text" value="' + row.email  + '"/></div>'
							//+ '<div class="user-messaging-footer"><input type="text" value="' + row.footer  + '"/></div>'
							+ '</div>'
							+ '<div class="form-row">'
							+ '<div class="user-messaging-accountname"><label for="user-messaging-accountname">Account Name:</label><input type="text" value="' + row.accountname  + '"/></div>'
							+ '</div>'
							+ '<div class="form-row">'
							+ '<div class="user-messaging-accountpassword"><label for="user-messaging-accountpassword">Account Password:</label><input type="password" value=""/></div>'
							+ '</div>'
							+ '<div class="form-row">'
							+ '<div class="user-messaging-server"><label for="user-messaging-server">Server:</label><input type="text" value="' + row.server  + '"/></div>'
							+ '</div>'
							+ '</div>'
							+ '<div class="column">'
							+ '<div class="form-row">'
							+ '<div class="user-messaging-port"><label for="user-messaging-port">Port:</label><input type="text" value="' + row.port  + '"/></div>'
							+ '</div>'
							+ '<div class="form-row">'
							+ '<div class="user-messaging-sslport"><label for="user-messaging-sslport">SSL Port:</label><input type="text" value="' + row.sslport  + '"/></div>'
							+ '</div>'
							+ '<div class="form-row">'
							+ '<div class="user-messaging-authtype"><label for="user-messaging-type">Authtype:</label><select><option value="2">NTLM</option><option value="">Standard</option></select></div>'
							+ '</div>'
							+ '<div class="form-row">'
							+ '<div class="user-messaging-type"><label for="user-messaging-type">Type:</label><select><option value="2">POP</option><option value="4">Conversation</option><option value="5">IMAP</option></select></div>'
							+ '</div>'
							+ '<div class="form-row">'
							+ '<div><span id="user-messaging-' + row.id + '" class="user-messaging-edit">&nbsp;</span><span id="user-messaging-' + row.id + '" class="user-messaging-remove">&nbsp;</span></div>'
							+ '</div>'
							+ '</div>');
				$('#user-messaging-row-' + row.id + ' .user-messaging-type select').val(row.type);
				$('#user-messaging-row-' + row.id + ' .user-messaging-authtype select').val(row.authtype);
			});
		}
		else
		{
			$('.user-messaging-table').append('<div colspan="8">No Messaging Accounts found..Why not add one now.</div>');
		}
		
        this.bind_setup_messaging_triggers();
	},
	
	bind_setup_messaging_triggers: function(response, container) {
		$('.user-messaging-add').button({
			label: "Add"
		})
		.click(function()
		{
			X4HSetup.messaging_add_create('messaging-add');
		});
		
		$('.user-messaging-edit').button({
			label: "Save"
		})
		.click(function()
		{
			var aID = $(this).attr('id').split('-');
			var messaging_account = new Object();
			
			messaging_account.id = aID[2];
            messaging_account.title = $('#user-messaging-row-' + aID[2] + ' .user-messaging-title input').val();
            messaging_account.user = $('#field-user-id').val();
			messaging_account.email = $('#user-messaging-row-' + aID[2] + ' .user-messaging-email input').val();
            messaging_account.type = $('#user-messaging-row-' + aID[2] + ' .user-messaging-type select').val();
            //messaging_account.footer = $('#user-messaging-row-' + aID[2] + ' .user-messaging-footer input').val();
            messaging_account.accountname = $('#user-messaging-row-' + aID[2] + ' .user-messaging-accountname input').val();
			
			if($('#user-messaging-row-' + aID[2] + ' .user-messaging-accountpassword input').val() != '')
			{
				messaging_account.accountpassword = $('#user-messaging-row-' + aID[2] + ' .user-messaging-accountpassword input').val();
			}
			messaging_account.port = $('#user-messaging-row-' + aID[2] + ' .user-messaging-port input').val();
            messaging_account.sslport = $('#user-messaging-row-' + aID[2] + ' .user-messaging-sslport input').val();
			messaging_account.server = $('#user-messaging-row-' + aID[2] + ' .user-messaging-server input').val();
			messaging_account.authtype = $('#user-messaging-row-' + aID[2] + ' .user-messaging-authtype select').val();
			myappmaster.setup.save_messaging_account(messaging_account);
		});
		
		$('.user-messaging-remove').button({
			text: false,
			icons: {
				primary: "ui-icon-closethick"
			},
			label: "Remove"
		})
		.click(function()
		{	
			$(this).parents('tr').fadeOut();
			var aID = $(this).attr('id').split('-');
			myappmaster.setup.remove_messaging_account({
				id: aID[2],
				remove: 1
			});
		});
	},
	
	remove_messaging_account: function(account)
	{
		x4hubProxy.call(
            [X4HSetup, 'remove_messaging_account_response'], 
            '/ondemand/setup/?method=SETUP_MESSAGING_ACCOUNT_MANAGE',
            account
        );
	},
	
	remove_messaging_account_response: function(response)
	{
		if(response.notes == 'REMOVED')
		{
			myappmaster.add_message('Messaging Account Removed.', 5);
			//Search the messaging accounts again
			this.user_messaging_search();
		}
		else
		{
			myappmaster.add_message('** Messaging Account was not removed an error occurred.', 5);
		}
		
	},
	
	populate_reports_to_area: function()
	{
		X4HUser.search_users('search_users_return','field-setup-reportsto');
	},
	
	messaging_add_create: function(container) {
		var aHTML = [];
		aHTML.push('<div class="column">' 
					+ '<div class="form-row">'
					+ '<div class="user-messaging-title"><label for="user-messaging-title">Title:</label><input id="user-messaging-title" type="text" /></div>'
					+ '</div>'
					+ '<div class="form-row">'
					+ '<div class="user-messaging-email"><label for="user-messaging-email">Email:</label><input id="user-messaging-email" type="text" /></div>'
					+ '</div>'
					+ '<div class="form-row">'
					+ '<div class="user-messaging-accountname"><label for="user-messaging-accountname">Account Name:</label><input id="user-messaging-accountname" type="text" /></div>'
					+ '</div>'
					+ '<div class="form-row">'
					+ '<div class="user-messaging-accountpassword"><label for="user-messaging-accountpassword">Account Password:</label><input id="user-messaging-accountpassword" type="password" /></div>'
					+ '</div>'
					+ '<div class="form-row">'
					+ '<div class="user-messaging-server"><label for="user-messaging-server">Server:</label><input id="user-messaging-server" type="text" /></div>'
					+ '</div>'
					+ '</div>'
					+ '<div class="column">'
					+ '<div class="form-row">'
					+ '<div class="user-messaging-port"><label for="user-messaging-port">Port:</label><input id="user-messaging-port" type="text" /></div>'
					+ '</div>'
					+ '<div class="form-row">'
					+ '<div class="user-messaging-sslport"><label for="user-messaging-sslport">SSL Port:</label><input id="user-messaging-sslport" type="text" /></div>'
					+ '</div>'
					+ '<div class="form-row">'
					+ '<div class="user-messaging-authtype"><label for="user-messaging-type">Authtype:</label><select id="user-messaging-authtype"><option value="2">NTLM</option><option value="">Standard</option></select></div>'
					+ '</div>'
					+ '<div class="form-row">'
					+ '<div class="user-messaging-type"><label for="user-messaging-type">Type:</label><select id="user-messaging-type"><option value="2">POP</option><option value="4">Conversation</option><option value="5">IMAP</option></select></div>'
					+ '</div>'
					+ '<div class="form-row">'
					+ '<span class="user-messaging-save">&nbsp;</span>'
					+ '</div>'
					+ '</div>');
					 
		$('.' + container).html(aHTML.join(''));	 
		
		$('.user-messaging-save').button({
			label: "Save"
		})
		.click(function()
		{
			//Verify first
			if($('.messaging-add').find('#user-messaging-accountpassword').val() != 0)
			{
				myappmaster.setup.save_messaging_account({
					title: $('#user-messaging-title').val(),
					user: $('#field-user-id').val(),
					email: $('#user-messaging-email').val(),
					type: $('#user-messaging-type').val(),
					authtype: $('#user-messaging-authtype').val(),
					accountpassword: $('.messaging-add').find('#user-messaging-accountpassword').val(),
					accountname: $('#user-messaging-accountname').val(),
					port: $('#user-messaging-port').val(),
					sslport: $('#user-messaging-sslport').val(),
					server: $('#user-messaging-server').val()
				});
			}
			else
			{
				alert('Please enter a password for this account.');
			}
		});
	},
	
	save_messaging_account: function(messaging_account) {
		$.each(messaging_account, function(key, value) {
            if(value == null) {
                value = "";
            }
            messaging_account[key] = value;
        });
		x4hubProxy.call(
            [X4HSetup, 'save_messaging_account_return'], 
            '/ondemand/setup/?method=SETUP_MESSAGING_ACCOUNT_MANAGE',
            messaging_account
        );
	},
	
	save_messaging_account_return: function(response, container) {
		myappmaster.add_message('Message Account Details Saved.', 5);
		//Search the messaging accounts again
		this.user_messaging_search();
	},
	save_user: function() {
		//Save the Contact Record
		this.save_existing_contact();	
			
		//Save the User Record
		this.save_existing_user();
	},
	save_existing_contact: function() {
		var day = parseInt($('#field-setup-user-birthday').val());
		var month = $('#field-setup-user-birthmonth').val();
		myappmaster.setup.save_user_contact_details({
			id: $('#field-contactperson-id').val(),
			firstname: $('#field-setup-user-firstname').val(),
			surname: $('#field-setup-user-lastname').val(),
			contactbusiness: X4HSetup.default_contact_business,
			phone: $('#field-setup-user-phone').val(),
			mobile: $('#field-setup-user-mobile').val(),
			email: $('#field-setup-user-email').val(),
			position: $('#field-setup-user-position').val(),
			dateofbirth: day + ' ' + month + ' ' + 2000
		});	
	},
	save_existing_contact_response: function(response) {
	
	},
	save_existing_user: function() {
		var user = new Object();
		user.contactbusiness = X4HSetup.default_contact_business;
		user.contactperson = $('#field-contactperson-id').val();
		user.id = $('#field-user-id').val();
		user.username = $('#field-setup-user-username').val();
		
		if($('#field-setup-user-password').val() != '')
		{
			user.userpassword = $('#field-setup-user-password').val();
		}
		if($('#field-setup-user-passwordexpiry').val() == '')
		{
			var oPasswordExpiry = new Date();
			oPasswordExpiry.setTime(oPasswordExpiry.getTime() + year_milliseconds);
			var sPasswordExpiry = $.fullCalendar.formatDate(oPasswordExpiry, 'dd/MM/yyyy');
		}
		else
		{
			var sPasswordExpiry = $('#field-setup-user-passwordexpiry').val();
		}
		user.userpasswordexpiry = sPasswordExpiry;
		user.manager = $('#field-setup-reportsto').val();
		user.unrestrictedaccess = 'Y';
		
		myappmaster.setup.save_user_details(user);
	},
	create_new_user: function() {
		//Create the Contact Record First as we need to link the user record to this
		this.save_new_user();		
	},
	save_new_user: function() {
		//Save the contact information
		var day = parseInt($('#field-setup-user-birthday').val());
		var month = $('#field-setup-user-birthmonth').val();
		myappmaster.setup.save_user_contact_details({
			id: $('#field-contactperson-id').val(),
			firstname: $('#field-setup-user-firstname').val(),
			surname: $('#field-setup-user-lastname').val(),
			contactbusiness: X4HSetup.default_contact_business,
			phone: $('#field-setup-user-phone').val(),
			mobile: $('#field-setup-user-mobile').val(),
			email: $('#field-setup-user-email').val(),
			position: $('#field-setup-user-position').val(),
			dateofbirth: day + ' ' + month + ' ' + 2000
		});	
	},
	
	save_user_contact_details: function(contact) {
		// Check if id is not null
        if(contact.id == '') 
		{
            delete contact.id;
			x4hubProxy.call(
            [this, 'save_new_user_contact_details_response'],
				'/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
				contact
			);
        }
		else
		{
			x4hubProxy.call(
            [this, 'save_existing_contact_response'],
				'/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
				contact
			);
		}
        
	},
	
	save_new_user_contact_details_response: function(response) {
		myappmaster.add_message('Contact Details Saved.', 5);
		//Use the response id to link to the new user account we are creating
		//Save the actual user account
		var day = parseInt($('#field-setup-user-birthday').val());
		var month = $('#field-setup-user-birthmonth').val();
		
		X4HSetup.user_contact_person = response.id;
		if($('#field-setup-user-passwordexpiry').val() == '')
		{
			var oPasswordExpiry = new Date();
			oPasswordExpiry.setTime(oPasswordExpiry.getTime() + X4HSetup.year_milliseconds);
			var sPasswordExpiry = $.fullCalendar.formatDate(oPasswordExpiry, 'dd/MM/yyyy');
		}
		else
		{
			var sPasswordExpiry = $('#field-setup-user-passwordexpiry').val();
		}
		myappmaster.setup.save_user_details({
			contactbusiness: X4HSetup.default_contact_business,
			contactperson: X4HSetup.user_contact_person,
			username: $('#field-setup-user-username').val(),
			userpassword: $('#field-setup-user-password').val(),
			userpasswordexpiry: sPasswordExpiry,
			manager: $('#field-setup-reportsto').val(),
			unrestrictedaccess: 'Y'
		});	
	},
	
	save_user_details: function(user) {
		x4hubProxy.call(
            [this, 'save_user_details_response'],
				'/ondemand/setup/?method=SETUP_USER_MANAGE',
				user
			);
	},
	
	save_user_details_response: function(response) {
		if(response.status != 'ER')
		{
			myappmaster.add_message('User Details Saved.', 5);
		}
		else
		{
			if(response.error.errorcode = '4')
			{
				//Delete the created contact
				myappmaster.add_message('Username already used.', 5);
				X4HContacts.remove_contact(X4HSetup.user_contact_person);
			}
		}
	},
	
	user_networkgroups_search: function () {
		//Call the method to search for the Network Group accounts for this user
		 var oXML = '<advancedSearch>' +
				           '<field><name>providerServiceText</name></field>' +
						   '<filter><name>user</name><comparison>EQUAL_TO</comparison><value1>' + $('#field-user-id').val() + '</value1></filter>' + 
						   '<options><rf>JSON</rf><startrow>0</startrow><rows>500</rows></options>' +
						   '</advancedSearch>';
		x4hubProxy.call(
			[X4HSetup, 'user_networkgroups_create', 'setupUserNetworkgroups'], 
            '/ondemand/setup/?method=SETUP_USER_NETWORK_GROUP_SEARCH',
            {
                data: oXML,
				rows: 500
            });
	},
	
	user_networkgroups_create: function(response, container) {
		var aHTML = [];
		aHTML.push('<table class="user-networkgroups-table"><tbody>');
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				aHTML.push('<tr id="user-networkgroups-row-' + row.id + '" class="user-messaging-row">'
			    			 + '<td class="user-networkgroups-title">' + row.providerservicetext + '</td>'
							 + '</tr>');
			});
		}
		else
		{
			aHTML.push('<tr><td>No Groups found..Why not add one now.</td></tr>');
		}
		aHTML.push('<tr><td><span class="user-networkgroups-add">&nbsp;</span></td></tr>');
		aHTML.push('</tbody></table>');
		
		$('#' + container).html(aHTML.join(''));
        this.bind_setup_networkgroups_triggers();
	},
	
	bind_setup_networkgroups_triggers: function(response, container) {
		$('.user-networkgroups-add').button({
			label: "Add Network Group"
		})
		.click(function()
		{
			alert('test');
		});
		
		$('.user-networkgroups-edit').button({
			label: "Edit Network Group"
		})
		.click(function()
		{
			alert('test');
		});
	},
	
	search_network_groups: function(callback, network_group)
	{
		if(callback == undefined)
		{
			callback = 'search_network_groups_response';
		}
		if(network_group == undefined)
		{
			var sFilter = "";
		}
		else
		{
			var sFilter = "<filter><name>id</name><comparison>EQUAL_TO</comparison><value1>" + network_group + "</value1><value2></value2></filter>"
		}
		
		
		var oXML = "<advancedSearch>"
            + "<field><name>documentalert</name></field>"
			+ "<field><name>includeinnetworknews</name></field>"
			+ "<field><name>jointype</name></field>"
			+ "<field><name>jointypetext</name></field>"
			+ "<field><name>leavetype</name></field>"
			+ "<field><name>leavetypetext</name></field>"
			+ "<field><name>manageruser</name></field>"
			+ "<field><name>managerusertext</name></field>"
			+ "<field><name>notes</name></field>"
			+ "<field><name>sharewith</name></field>"
			+ "<field><name>sharewithtext</name></field>"
			+ "<field><name>title</name></field>"
			+ sFilter
			+ "<options><rf>JSON</rf><startrow>0</startrow><rows>500</rows></options>"			
			+ "</advancedSearch>";
			x4hubProxy.call(
            [X4HSetup, callback],
            '/ondemand/setup/?method=SETUP_PROVIDER_SERVICE_SEARCH',
            {
                advanced: 1,
                data: oXML,
				rows: 500
			});	
			
	},
	search_network_groups_response: function(response)
	{
		var aHTML = [];
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				aHTML.push('<div class="network-group-parent" id="networkgroup-' + this.id + '">' + this.title + '</div>');
			});
		}
		else
		{
			aHTML.push('<tr><td>No Network Groups Found.</td></tr>');
		}
		$('.network-groups-left-nav').html(aHTML.join(''));
    },
	hide_network_group_panels: function()
	{
		$('.network-groups-create-groups-container, .network-groups-edit-groups-container').hide();
	},
	hide_project_panels: function()
	{
		$('.admin-projects-create-project-container, .admin-projects-edit-projects-container').hide();
	},
	create_network_group: function(network_group)
	{
		if(network_group == null)
		{
			var network_group = new Object();
			network_group.documentalert = 'N';
			network_group.includeinnetworknews = 'N';
			network_group.manageruser = '25230'; //Rolands ID
			network_group.leavetype = '1';
			network_group.notes = $('#field-new-group-description').val();
			network_group.title = $('#field-new-group-name').val();
		}	
		x4hubProxy.call(
            [X4HSetup, 'create_network_group_response'],
            '/ondemand/setup/?method=SETUP_PROVIDER_SERVICE_MANAGE',
            network_group
		);	
	},
	create_network_group_response: function(response)
	{
		if(response.status != 'ER')
		{
			myappmaster.add_message('Network Group Created', 5);
			//Show Search
			$('.network-groups-left-nav').html('<span>Loading Groups <img src="/assets/images/preloader2.gif" /></span>');
			//Do search for the network Groups again
			X4HSetup.search_network_groups();
		}
	},
	show_network_group_details_response: function(response)
	{
		//Populate the details into the Edit fields
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				$('#field-edit-group-name').val(this.title);
				$('#field-edit-group-description').val(this.notes);
				$('#network-groups-edit-group-header').find('span').text(this.title);
			});
		}
		else
		{
			
		}
	},
	search_network_groups_user: function () {
		 var oXML = '<advancedSearch>' +
				    '<field><name>user</name></field>' +
					'<field><name>usertext</name></field>' +
					'<filter><name>providerservice</name><comparison>EQUAL_TO</comparison><value1>' + X4HSetup.selected_network_group + '</value1></filter>' + 
					'<options><rf>JSON</rf><startrow>0</startrow><rows>300</rows></options>' +
					'</advancedSearch>';
		x4hubProxy.call(
			[X4HSetup, 'search_network_groups_user_response'], 
            '/ondemand/setup/?method=SETUP_USER_NETWORK_GROUP_SEARCH',
            {
                data: oXML
            });
	},
	search_network_groups_user_response: function(response)
	{
		var aHTML = [];
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				aHTML.push('<div class="network-group-current-user-row" id="usercurrent-' + this.user + '"><input type="checkbox" checked="checked" value="' + this.id + '">'
						   + this.usertext
						   + '</div>');
			});
		}
		else
		{
			aHTML.push('<div>No Members Found...</div>');
		}
		$('.network-groups-current-users-list').html(aHTML.join(''));
		
		X4HSetup.user_list(null,null,null,null,'search_available_network_group_users_response', 'network-groups-user-search-results');
	},
	search_available_network_group_users_response: function(response, container)
	{
		var aHTML = [];
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				//Is this user currently a member?				
				if($('#usercurrent-' + this.id).length > 0)
				{
					var sClass = 'current';
				}
				else
				{
					var sClass = 'not-current';
				}
				aHTML.push('<div class="network-group-user-row ' + sClass + '"><input type="checkbox" value="' + this.id + '">'
						   + this.username
						   + '</div>');
			});
		}
		else
		{
			aHTML.push('<div>No Users Found...</div>');
		}
		$('.' + container).html(aHTML.join(''));
	},
	filter_users: function(sTerm)
	{
		//Used to filter the users when adding to network groups
	},
	link_user_to_network_group: function(user_id, remove)
	{	
		var group = new Object();
		if(remove == null)
		{
			group.user = user_id;
			group.providerservice = X4HSetup.selected_network_group;
		}
		else
		{
			group.id = user_id;
			group.remove = 1;
		}
		
		x4hubProxy.call(
            [X4HSetup, 'link_user_to_network_group_response'],
            '/ondemand/setup/?method=SETUP_USER_NETWORK_GROUP_MANAGE',
            group
		);
	},
	link_user_to_network_group_response: function(response)
	{
		myappmaster.add_message('Network Group Link Edited.', 2);
		//Search for the groups again
		X4HSetup.search_network_groups_user();
	},
	search_projects: function(callback, container, project_id)
	{
		 var oXML = "<advancedSearch>"
            + "<field><name>reference</name></field>"
			+ "<field><name>description</name></field>"
            + "<field><name>startdate</name></field>"
            + "<field><name>status</name></field>"
            + "<field><name>statustext</name></field>"
			+ "<field><name>template</name></field>"
            + "<field><name>type</name></field>"
            + "<field><name>typetext</name></field>"
			+ "<field><name>modifieddate</name></field>"
			+ "<field><name>modifieduser</name></field>"
			+ "<field><name>modifiedusertext</name></field>"
			+ "<field><name>sq6976</name></field>"
			
			if(project_id != null)
			{
			oXML = oXML + "<filter>"
					+ "<name>id</name><comparison>EQUAL_TO</comparison><value1>" + project_id + "</value1>"
					+ "</filter>"
			}
			oXML = oXML + "<sort><name>description</name><direction>asc</direction></sort>"
            + "<summaryField>"
			+ "<name>count auditcount</name>"
			+ "</summaryField>"
            + "<options>"
			+ "<rf>json</rf>"
			+ "<startrow>0</startrow>"
			+ "<rows>50</rows>"
			+ "</options>"
			+ "</advancedSearch>";
			console.log('Search Projects');	
			if(container == null)
			{
				var container = 'admin-projects-left-nav';
			}
			if(callback == null)
			{
				var callback = 'search_projects_response';
			}
			x4hubProxy.call(
			[X4HSetup, callback, container], 
				'/ondemand/project/?method=PROJECT_SEARCH',
				{
					advanced: 1,
					data: oXML
				}
			);
	},
	search_projects_response: function(response, container)
	{
		var aHTML = [];
		
		if(response.data.rows.length > 0) 
		{
			$.each(response.data.rows, function(key, row) {
				var sClass = '';
				var sParent = '';
				var sContainer = '';
				if(this.sq6976 == 'parent')
				{
					//PARENT
					sClass = 'admin-projects-parent';
					sContainer = '<div class="admin-parent-container" id="parentcontain-' + this.id + '">&nbsp;</div>';
				}
				if(this.sq6976 == 'orphan')
				{
					//ORPHAN
					sClass = 'admin-projects-orphan';
				}
				if(this.sq6976 != 'orphan' && this.sq6976 != 'parent')
				{
					//CHILD
					sClass = 'admin-projects-child';
					sParent = ' parent="' + this.sq6976 + '" '
				}
				aHTML.push('<div class="' + sClass + '"' + sParent + 'id="project-' + this.id + '">' + this.description + '</div>'
							+ sContainer);
			});
		}
		else
		{
			aHTML.push('<div><i>No Projects Found...</i></div>');
		}
		$('.' + container).html(aHTML.join(''));
		
		$('.admin-projects-left-container').find('.admin-projects-child').each(function(index)
		{
			var iParent = $(this).attr('parent');
			$(this).appendTo('#parentcontain-' + iParent);
			$(this).show();
		});
	},
	show_project_details_response: function(response)
	{
		//Populate the details into the Edit fields
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				$('#field-edit-project-name').val(this.reference);
				$('#field-edit-project-description').val(this.description);
				$('#admin-projects-edit-projects-header').find('span').text(this.reference);
				$('#field-admin-parent-project-name-edit').val(this.sq6976);
			});
		}
		else
		{
			
		}
	},
	search_parent_projects: function(new_project)
	{
		var oXML = "<advancedSearch>"
            + "<field><name>reference</name></field>"
			+ "<field><name>description</name></field>"
            + "<field><name>startdate</name></field>"
            + "<field><name>status</name></field>"
            + "<field><name>statustext</name></field>"
			+ "<field><name>template</name></field>"
            + "<field><name>type</name></field>"
            + "<field><name>typetext</name></field>"
			+ "<field><name>modifieddate</name></field>"
			+ "<field><name>modifieduser</name></field>"
			+ "<field><name>modifiedusertext</name></field>"
			+ "<field><name>sq6976</name></field>"
			+ "<filter>"
			+ "<name>sq6976</name><comparison>EQUAL_TO</comparison><value1>parent</value1>"
			+ "</filter>"
			+ "<sort><name>description</name><direction>asc</direction></sort>"
            + "<summaryField>"
			+ "<name>count auditcount</name>"
			+ "</summaryField>"
            + "<options>"
			+ "<rf>json</rf>"
			+ "<startrow>0</startrow>"
			+ "<rows>50</rows>"
			+ "</options>"
			+ "</advancedSearch>";
			
			x4hubProxy.call(
			[X4HSetup, 'search_parent_projects_response', new_project], 
				'/ondemand/project/?method=PROJECT_SEARCH',
				{
					advanced: 1,
					data: oXML
				}
			);
	},
	search_parent_projects_response: function(response, new_project)
	{
		var aHTML = [];
		aHTML.push('<option value="orphan">- None - Orphan-</option>');
		if(new_project)
		{
			aHTML.push('<option value="parent">- None - Parent -</option>');	
		}
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				aHTML.push('<option value="' + this.id + '">' + this.reference + '</option>');				
			});
		}
		else
		{
			//No parent Projects		
		}
		$('#field-admin-parent-project-name-edit, #field-admin-parent-project-name-new').html(aHTML.join(''));
	},
	save_project: function(project)
	{
		x4hubProxy.call(
			[X4HSetup, 'save_project_response'], 
				'/ondemand/project/?method=PROJECT_MANAGE',
				project
			);
	},
	save_project_response: function(response)
	{
		myappmaster.add_message('Project Saved.', 5);
		X4HSetup.search_projects();
	},
	search_network_groups_checklist_reponse: function(response)
	{
		var aHTML = [];
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				aHTML.push('<div class="admin-select-network-group"><input type="checkbox" value="' + this.id + '">' + this.title + '</div>');
			});
		}
		else
		{
			aHTML.push('<tr><td>No Network Groups Found.</td></tr>');
		}
		$('.admin-projects-network-groups-list').html(aHTML.join(''));
		
		//Search which of these groups are shared with the project
		X4HSetup.search_network_group_shares();
	},
	delete_project: function()
	{
		this.search_project_action();
	},
	delete_project_response: function(response)
	{
		myappmaster.add_message('Project Deleted', 5);
		this.search_projects();
	},
	search_project_action: function()
	{
		var oXML = "<advancedSearch>"
            + "<field><name>actionby</name></field>"
			+ "<field><name>linkid</name></field>"
			+ "<filter><name>linkid</name><comparison>EQUAL_TO</comparison><value1>" +  X4HSetup.selected_project + "</value1><value2></value2></filter>"
			+ "<options><rf>JSON</rf><startrow>0</startrow><rows>1</rows></options>"
			+ "<summaryField><name>count auditcount</name></summaryField>" 
            + "</advancedSearch>";
       
		x4hubProxy.call(
            [X4HSetup, 'search_project_action_response'],
            '/ondemand/action/?method=ACTION_SEARCH',
            {
                advanced: 1,
                data: oXML,
			}
        ); 
	},
	search_project_action_response: function(response)
	{
		if(response.data.rows.length > 0) 
		{
			alert('There are emails in this project please move the emails first');
		}
		else
		{
			X4HSetup.confirm_project_delete();
		}
	},
	confirm_project_delete: function(response)
	{
		var project = new Object();
			project.remove = 1;
			project.id = X4HSetup.selected_project;
			x4hubProxy.call(
			[X4HSetup, 'delete_project_response'], 
				'/ondemand/project/?method=PROJECT_MANAGE',
				project
			);		
	},
	share_project_with_network_group: function(project_id, network_group_id, remove)
	{
		var link = new Object();
		if(remove != null)
		{
			link.remove = 1;
			link.id = remove;
		}
		else
		{
			link.object = 1;
			link.objectcontext = project_id;
			link.networkgroup = network_group_id;
		}
		x4hubProxy.call(
            [X4HSetup, 'share_project_with_network_group_reponse'],
            '/ondemand/setup/?method=SETUP_OBJECT_NETWORK_GROUP_ACCESS_MANAGE',
            link
        ); 
	},
	share_project_with_network_group_reponse: function(response)
	{
		if(response.status != 'ER')
		{
			myappmaster.add_message('Project sharing has been modified.', 5);
			X4HSetup.search_network_groups('search_network_groups_checklist_reponse');
		}
		else
		{
			myappmaster.add_message('An Error has occurred.', 5);
		}
	},
	search_network_group_shares: function()
	{
		x4hubProxy.call(
            [X4HSetup, 'search_network_group_shares_response'],
            '/ondemand/setup/?method=SETUP_OBJECT_NETWORK_GROUP_ACCESS_SEARCH'
        ); 
	},
	search_network_group_shares_response: function(response)
	{
		if(response.data.rows.length > 0) 
		{
			$.each(response.data.rows, function(key, row) {
				if(row.objectcontext == X4HSetup.selected_project)
				{
					$('input[value="' + row.networkgroup + '"]').attr('checked', 'checked');
					$('input[value="' + row.networkgroup + '"]').attr('linkid', row.id);
				}
				else
				{
					$('input[value="' + row.networkgroup + '"]').removeAttr('checked');
				}
			});
		}
		else
		{
			//There are no shares at all
		}
	}
}


