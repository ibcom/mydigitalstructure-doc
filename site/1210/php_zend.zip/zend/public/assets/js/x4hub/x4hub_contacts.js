// Manages contacts (business/person) within the platform
var X4HContacts = {
    defaultFields: [ 'firstname', 'surname', 'email', 'homephone', 'position', 'workphone', 'mobile', 'contactbusiness','notes','contactbusinesstext', 'sq6856', 'sq6857', 'sq6858', 'sq6859', 'sq6860', 'sq6861', 'sq6864', 'sq6965'],
	defaultFilters: [],
	//defaultOptions: [{rf: 'json', startrow: 0, rows: 20, returnparameters: 'true'}],
    defaultSort: [/*{name: 'id', direction: 'desc'}*/] /** TODO: X4H support for ID */,
    
    defaultPerPage: 20,
    
    selected_contact: null, 
		
    last_query: null,
    
    tmp_contact_details : null, //used for storing temp contact when saving
    
    contact_edit_referrer : null, //used to redirect contact edit when saved,
    
    selected_contact_details : null,
    
    
    
   init: function() {
        $('.create-contact').click(function(event) {
			event.preventDefault();
            //Clear contents of each of the fields
			myappmaster.contacts.clear_modal();
            /*myappmaster.contacts.show_modal('Create');*/
			myappmaster.contacts.show_tab('Create');		
		});
        
		$('.create-company').click(function(event) {
			event.preventDefault();
            //Clear contents of each of the fields
			myappmaster.contacts.clear_modal();
            /*myappmaster.contacts.show_modal('Create');*/
			myappmaster.contacts.show_company_tab('Create')		
		});
		
	
		
        //Set Date and Time for the left hand side
        this.set_date();
	
        //Set companies    
        myappmaster.companies = new X4HCompanies();
        myappmaster.companies['initFlag'] = false;	
        
        $( "#tab-contacts .tabs" ).tabs();
        
        $("#contacts-nav").tabs({
            select : function(event,ui){
                if(ui.index==0){
                    /* reset pagination */
                    $('#contacts-main-list-pagination').html('');
                    myappmaster.contacts.search(null, filters, null, null, null);
                }
                if(ui.index==1){
                    //init companies when selected
                    if(myappmaster.companies.initFlag==false){
                        myappmaster.companies.initFlag=true;
                        myappmaster.companies.init();
                        
                    }
                   
                }
				if(ui.index==2){
                    //init favourites when selected
                    //myappmaster.contacts.favourites();
					var filters = [{name:'',comparison:'IS_FAVOURITE',value1: ''}];
					myappmaster.contacts.search(null, filters, null, null, 'init', 
					{
						callbackobj : myappmaster.contacts.favourites_list,
						container : 'favourites-main-list'
					});
                }
            },            
            show : function(event, ui){
                
                var tabindex = $(this).tabs("length")-1;
                if(ui.index!=tabindex){
                    
                    if(tabindex>2){ //default tab length
                        if($('#contacts-nav').find('a[href=#contactsOverview]').size()!==0&& $('#contacts-nav').find('a[href=#contact-manage-screen]').size()!==0){
                            $(this).tabs("remove",tabindex);
                            
                            if($(this).tabs("length")-1!==ui.index){
                            
                                $(this).tabs("remove",tabindex-1);
                            }
                        }else{
                    
                            $(this).tabs("remove",tabindex);
                        }
                    }
                }
            }
            
        });
        
        $( '.show-create-contact-group').click(function(event) {
            event.preventDefault();
            $( '#contact-group-add').show();
        });
        
        $( '.hide-create-contact-group').click(function(event) {
            event.preventDefault();
            $( '#contact-group-add').hide();
        });
        
        // Populate the main list
        //this.list(10);
        
        /* advance searching feature */
        if(X4HASearchWidget.widget_search){
            var filters = X4HASearchWidget.search_filter;
        }else{
            filters = null;
        }
        
        /* reset pagination */
        $('#contacts-main-list-pagination').html('');
        
        // Always go to page one when clicking on the tab        
        this.search(null, filters, null, null, null);
        
        //init Companies
        //myappmaster.companies = new X4HCompanies();
        //myappmaster.companies.init();
        
        //init contact search
        this.contact_search.init();
        this.favourites_list = {
			init : function(response, container){
				myappmaster.contacts.search_return(response, container.container);
			}
		};
                
        //apply filter fix
        $('#contacts-search-dropdown').each(function(){
            var title = $(this).attr('title');
            if( $('option:selected', this).val() != ''  ) 
            title = $('option:selected',this).text();
        
            $(this).css({'z-index':10,'opacity':0,'-khtml-appearance':'none'})
            
            
            if($('#contacts-search-span').size()==0){
                $(this).after('<span id = "contacts-search-span">' + title + '</span>');    
            }
            $(this).change(function(){
                    val = $('option:selected',this).text();
                    $(this).next().text(val);
                });    
                
        });        


	},
	
	set_date: function() {
		var current_date = new Date; 
		$('#left-sidebar-date').text($.fullCalendar.formatDate(current_date, 'dddd dS MMMM'));
		$('#left-sidebar-time').text($.fullCalendar.formatDate(current_date, 'h:mmtt'));
	},
	set_extra_user_details: function(response) {
		$('.progressbar-loading').progressbar("option","value", 60);
		$('.state-loading').text('Loading Email');
		
		var extra_details = response.data.rows[0]; 
		$('#user-info-title').text(extra_details.position);
		$('#user-info-phone').text(extra_details.mobile);
		
		var sLinkedIn = '';
		var sTwitter = '';
		var sFacebook = '';
		
		if(extra_details.sq6856!==undefined&&extra_details.sq6856 != '')
        { 
            sLinkedIn = '<a href="' + extra_details.sq6856 + '" target="_blank" id="info-btn-sq6856-'+extra_details.id+'"><img src="/assets/images/in-btn01.png" /></a><br />';
        }
        if(extra_details.sq6857!==undefined&&extra_details.sq6857 != '')
        { 
            sTwitter = '<a href="' + extra_details.sq6857 + '" target="_blank" id="info-btn-sq6857-'+extra_details.id+'"><img src="/assets/images/t-btn01.png" /></a><br />';
        }
        if(extra_details.sq6858!==undefined&&extra_details.sq6858 != '')
        { 
            sFacebook = '<a href="' + extra_details.sq6858 + '" target="_blank" id="info-btn-sq6858-'+extra_details.id+'"><img src="/assets/images/f-btn01.png" /></a><br />';
        }
		$('#user-btns').html(sLinkedIn + sTwitter + sFacebook);
		
		X4HUser.role = extra_details.position;
		X4HUser.mobile = extra_details.mobile;
		X4HUser.fax = extra_details.fax;
		X4HUser.phone = extra_details.workphone;
		
		X4HUser.address_street1 =  extra_details.streetaddress1;
		X4HUser.address_street2 = extra_details.streetaddress2;
		X4HUser.address_suburb = extra_details.streetsuburb;
		X4HUser.address_state = extra_details.streetstate;
		X4HUser.address_postcode = extra_details.streetpostcode;
		X4HUser.address_country = extra_details.streetcountry;
				
		X4HUser.email_personal = extra_details.sq6861; // this is the personal email for the logged in profile
		X4HUser.email_sendfrom = extra_details.sq6934;
		
		//We can now search the default email account
		X4HEmail.current_account = $('#my-email-select option:contains("' + X4HUser.email_sendfrom + '")').attr('selected', 'selected').val(); 
		X4HEmail.search_mail_init();
	},    
    save_contact: function(contact) {
        // Check if id is not null
        var newContact = false;
        
        //console.log(parseInt(contact.id));
        
        if(contact.id=='') {
            newContact = true;
            delete contact.id;
            
        }
        
        this.tmp_contact_details = contact;
        
        var function_call = (newContact ? 'save_contact_response_new' : 'save_contact_response_update');
        
        if(!newContact){
            console.log();
            //get id from src
            var src_txt = $('#contact-image .profile-image img').attr('src');
            var match = RegExp('[?&]' + 'id' + '=([^&]*)')
            .exec(src_txt);
            var attachment_id = match && decodeURIComponent(match[1].replace(/\+/g, ' '));
            contact['sq6965'] = attachment_id;
        }
        
        var error_message = [];
        
        //validate
        
            if($('#field-contact-firstname').val()==''){
                error_message.push('Firstname is required.');
            }
            if($('#field-contact-lastname').val()==''){
                error_message.push('Lastname is required.');
            }
            if($('#field-contact-email').val()==''){
                error_message.push('Email is required.');
            }
        
        //reset values
        $('#contact-messages').html('');
        
        if(error_message.length>0){
            //$('#contact-messages').append('<p>* Error creating contact.</p>');
            $.each(error_message, function(key,err){
                $('#contact-messages').append('<p>'+err+'</p>');
            });
        }else{
            
            $('#contact-manage-create').append($(
                '<div class="preloader-contact-overview" id="update-contact-preloader">'
                +'    <span><img src="/assets/images/preloader.gif" /><br  />saving contact details</span>'
                +'</div>'
            ));
            
            x4hubProxy.call(
                [this, function_call, contact],
                '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
                contact
            );
            
            
            if(contact.id==''){
                myappmaster.contacts.clear_modal();    
            }
        }
        
        
        
        // Update the record if it exists - OR 
    },
    
    // When adding a new row - need to update the available row list to the default
    save_contact_response_new: function(response, container) {
        myappmaster.add_message('Contact Created.', 5);
        //remove preloader
        $('#update-contact-preloader').remove();
		// Sync in all the elements so everything is in place
        //this.search(null, null, null, null, null);
        
        //added 01-11-11
        //allocate to company by email
        this.allocate_contact(response)
    },
    // When updating a row - delete the current row and replace it with the new row
    save_contact_response_update: function(response, contact) {
        myappmaster.add_message('Contact Saved.', 5);
        
        //remove preloader
        $('#update-contact-preloader').remove();
        
        //contact phone number
        contact['workphone'] = contact.phone;
        
        //contact business if any
        contact['contactbusinesstext'] = $('#contact-row-company-'+contact.id).text().replace(/Company: /,"");
        
        //get image id from profile image
        //var image_id  = myappmaster.find_id($('#contact-image').find('.profile-image').find('img').attr('src'));
        //console.log($('#contact-image').find('.pr);
        
        this.tmp_contact_details = contact;
        
        if(X4HContacts.contact_edit_referrer=='contact-list'){
            // Update the row elements
            var row = this.generate_rowcontent(contact);
        
            $('#contact-row-' + contact.id).replaceWith(row);
            
            //check if the profile image did load
            $('#contact-row-'+contact.id+' div img').error(function() {
                //change to default image
                $(this).attr('src','/assets/images/avatar06.png');
            });
            //var target_item = 'contact-edit';
            /*//change image
            var img_contact_id = contact.id;
            x4hubProxy.call(
                [X4HContacts, 'change_image_response',{contact_id:img_contact_id,target_item: target_item}],
                '/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
                {
                        object: 32,
                        objectcontext:img_contact_id,
                        type: 260 //Profile Attachment type
                }
            );*/
        }
        
        //edited through contacts overview
        if(X4HContacts.contact_edit_referrer=='contact-overview'){
            $('#contact-info-name').html(contact.firstname+'&nbsp;'+contact.surname);
            $('#contact-info-title').html('Position: '+contact.position);
            $('#contact-info-phone').html(contact.workphone);
            $('#contact-info-email').html(contact.email);
            
        }
        //allocate to company by email
        if(myappmaster.contacts.selected_contact_details.email!=contact.email){
            this.allocate_contact(response);
        }else{
            //reattach triggers
            if(X4HContacts.contact_edit_referrer!='contact-overview')
            myappmaster.contacts.bind_contact_triggers(contact.id);
        }
        
    },
    remove_contact: function(contact_id) {
        x4hubProxy.call(
            [this, 'remove_contact_response',contact_id],
            '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
            {
                id: contact_id,
                remove: 1
            }
        );
    },
    remove_contact_response: function(response,contact_id) {
        console.log(response);
        myappmaster.add_message('Deleted a Record ' + contact_id + '.', 5);
        //this.list(20);
        $('#update-contact-preloader').remove();
        
        //remove the contact from list
        $('#contact-row-'+contact_id).next('div').remove();
        $('#contact-row-'+contact_id).remove();
        
        //this.search(null, null, null, null, null);
        $('#contacts-nav').tabs('select', '#contactsPeople');
    },
    
    // Search Function
    search: function(fields, filters, options, sort, callback, params) {        
        if(fields == null) {
            fields = this.defaultFields;
        }
        if(filters == null) {
            filters = this.defaultFilters;
        }
        if(options == null) {
            options = this.defaultOptions;
        }
        if(sort == null) {
            sort = this.defaultSort;
        }
        
        //added by Ram Alveyra
        if(callback==null){
            callback = 'search_return';
        }
        if(params==null){
            params = 'contacts-main-list';
            var callbackobj = this;
        }else{
            callbackobj = params.callbackobj;
			//var callbackobj = this;
        }
        
        if(params!==null&&params.rows!==undefined){
            var rows = params.rows;
        }else{
            rows = this.defaultPerPage;
        }
        
        var oXML = new X4HASearch(fields, filters, options, sort).getXML();
		
        this.last_query = {
            fields: fields,
            filters: filters,
            options: options,
            sort: sort
        };
        
       	   
        x4hubProxy.call(
            [callbackobj, callback, params],
            '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
            {
                advanced: 1,
                data: oXML,
                rows: rows
            }
        );
        
        /* reset advance search flag */
        if(X4HASearchWidget.widget_search){
            X4HASearchWidget.widget_search = false;
        }    
    },
    search_return: function(response, container) {
		myappmaster.add_message('Contact Search', 5);
        $('.preloader-contact').hide();
        
        // Remove children
        $('#' + container).find('.contacts-row').remove();
        $('#' + container).find('.company-person-line').remove();  
        
        if(response.data.rows.length > 0) {
            var rowcount = response.data.rows.length;
            $.each(response.data.rows, function(key, row) {
                var rowcontent = myappmaster.contacts.generate_rowcontent(row, container);
                $('#' + container).append(rowcontent);                
                if(key + 1 < rowcount) {
                    $('#' + container).append('<div class="company-person-line"></div>');
                }
                
                //check if the profile image did load
                $('#contact-row-'+row.id+' div img').error(function() {
                    //change to default image
                    $(this).attr('src','/assets/images/avatar06.png');
                    
                });
			});

            // Add edit anchors
            $.each( $( '.contact-view-details' ), function(counter, elem) {
                $(elem).click(function() {
                    // Find out the id of what we're dealing with
                    var contact_id = myappmaster.find_id($(elem).attr('id'));
                    //myappmaster.contacts.find(contact_id);
                    var contact_name = $('#contact-row-name-'+contact_id).text();
                    console.log('show contact details');
                    myappmaster.contacts.contact_overview.init(contact_id, contact_name);
                });
            });
			
			// Add 
            $.each( $( '.contact-favourite' ), function(counter, elem) {
                $(elem).click(function() {
                    // Find out the id of what we're dealing with
                    var contact_id = myappmaster.find_id($(elem).attr('id'));
                    var contact_name = $('#contact-row-name-'+contact_id).text();
                    console.log('Mark as favourite');
                    myappmaster.contacts.mark_as_favourite(contact_id);
                });
            });
			
			// Add favourite
            $.each( $( '.contact-favourite-remove' ), function(counter, elem) {
                $(elem).click(function() {
                    // Find out the id of what we're dealing with
                    var contact_id = myappmaster.find_id($(elem).attr('id'));
                    var contact_name = $('#contact-row-name-'+contact_id).text();
                    console.log('Unmark as favourite');
                    myappmaster.contacts.unmark_as_favourite(contact_id);
                });
            });
			
            // Now that we have bound whats visible - lets see what else have to do
            //var currentPage = (1 + parseInt(response.startrow) % 20);
            
            //if user is an admin, allow edit
            if(myappmaster.users.details.systemadmin!==undefined&&myappmaster.users.details.systemadmin=="true"){
                //bringing edit back
                $.each( $( '.contact-edit-anchor' ), function(counter, elem) {
                    $(elem).click(function() {
                        console.log('edit contact');
                        X4HContacts.contact_edit_referrer = 'contact-list';
                        //$('.preloader-modal').dialog('open');
                        //$('.preloader-modal').dialog({title: 'Contacts'});

                        // Find out the id of what we're dealing with
                        X4HContacts.selected_contact = myappmaster.find_id($(elem).attr('id'));
                            myappmaster.contacts.find(X4HContacts.selected_contact);

                    });
                });
			}
			
			//No longer required 12-12-2011 RW
            //search for image and replace
			//this.change_image('contact-profile-img', 'contact-edit') //param = target id and target class for iteration;
		}
		else
		{
            $('#' + container).append('<div class="contacts-row">No available records to display.</div>');
        }
        
    },
    
    generate_rowcontent: function(row, container) {
        //console.log(row)
		//Check if Twitter, Linked In, Facebook
        var sLinkedIn = '';
		var sTwitter = '';
		var sFacebook = '';
		var sFavourite = '';
		var sProfileImage = '/assets/images/avatar06.png';
        if(container != 'favourites-main-list')
		{
			sFavourite = '<span id="contact-favourite-' + row.id + '" class="contact-favourite">Add to Favourites</span>';
		}
		else
		{
			sFavourite = '<span id="contact-favourite-' + row.id + '" class="contact-favourite-remove">Remove from Favourites</span>';
		}
		//Check if contact row exists and fix link
                if($('#contact-row-'+row.id).size()!==0){
                    var sLinkedInLink = $('#contact-row-'+row.id).find('.contact-info-btns').find('#info-btn-sq6856-'+row.id+'');
                    var sTwitterLink = $('#contact-row-'+row.id).find('.contact-info-btns').find('#info-btn-sq6857-'+row.id+'');
                    var sFacebookLink = $('#contact-row-'+row.id).find('.contact-info-btns').find('#info-btn-sq6858-'+row.id+'');
                    
                    if(sLinkedInLink.size()!==0){
                        row['sq6856'] = sLinkedInLink.attr('href');
                    }
                    
                    if(sTwitterLink.size()!==0){
                        row['sq6857'] = sTwitterLink.attr('href');
                    }
                    
                    if(sFacebookLink.size()!==0){
                        row['sq6858'] = sFacebookLink.attr('href');
                    }
                    
                }

                if(row.sq6856!==undefined&&row.sq6856 != '')
                { 
                        sLinkedIn = '<a href="' + row.sq6856 + '" target="_blank" id="info-btn-sq6856-'+row.id+'"><img src="/assets/images/in-btn01.png" /></a><br />';
                }
                if(row.sq6857!==undefined&&row.sq6857 != '')
                { 
                        sTwitter = '<a href="' + row.sq6857 + '" target="_blank" id="info-btn-sq6857-'+row.id+'"><img src="/assets/images/t-btn01.png" /></a><br />';
                }
                if(row.sq6858!==undefined&&row.sq6858 != '')
                { 
                        sFacebook = '<a href="' + row.sq6858 + '" target="_blank" id="info-btn-sq6858-'+row.id+'"><img src="/assets/images/f-btn01.png" /></a><br />';
                }
                //Check if they have an attachment defined in their attachment id field
                if(row.sq6965!==undefined&&row.sq6965 != '')
                {
					sProfileImage = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + row.sq6965 + '&sid=' + x4hubProxy.sid;
				}
		
        var content = $(''
            + '<div id="contact-row-' + row.id + '" class="contacts-row">'
            + '    <div class="contact-info-pic">'
            + '        <img src="' + sProfileImage + '" width="50" id="contact-edit-' + row.id + '" class="contact-edit-anchor contact-profile-img" />'                     
            + '    </div>'
            + '    <div class="contact-info-btns">'
            + sLinkedIn
            + sTwitter
            + sFacebook
            + '    </div>'
            + '    <div class="contact-info-details">'
            + '        <span id="contact-row-name-' + row.id + '" style="font-weight: bold;">' + row.firstname + ' ' + row.surname + '</span></br>'
            + '        <span id="contact-row-company-' + row.id + '">Company: ' + row.contactbusinesstext + '</span></br>'
            + '        <span id="contact-row-position-' + row.id + '">Position: ' + row.position + '</span></br>'
            + '    </div>'
            + '    <div class="contact-info-personal">'
            + '        <span id="contact-row-phone-' + row.id + '">Phone: ' + (row.workphone == '' ? '&nbsp;' : row.workphone) + '</span></br>'
            + '        <span id="contact-row-email-' + row.id + '">Email: ' + (row.email == '' ? '&nbsp;' : row.email) + '</span></br>'
            + '        <span id="contact-view-details-' + row.id + '" class="contact-view-details">View Details</span>'
			+ 			sFavourite
            + '    </div>'
            + '</div>'
        );
        return content;
    },
    mark_as_favourite: function(contact_id)
	{
		myappmaster.add_message('Favourite Added', 5);
		$('.contacts-favourites-tab').animate({
			opacity: 0.25
		}, 500, function() 
		{
			$(this).animate({
				opacity: 1
			}, 500, function() {
				//Animate Complete
			});		
		});
		x4hubProxy.call([X4HContacts, 'favourite_response'],
            '/ondemand/core/?method=CORE_FAVOURITE_MANAGE',
            {
				objectcontext: contact_id,
				object: '32'
			}
        );
	},
	unmark_as_favourite: function(contact_id)
	{
		$('#favourites-main-list #contact-row-' + contact_id).fadeOut(500);
		//SEARCH FOR ID TO BE REMOVED
		x4hubProxy.call([X4HContacts, 'remove_favourite'],
            '/ondemand/core/?method=CORE_FAVOURITE_SEARCH',
            {
				objectcontext: contact_id,
			}
        );
	},
	remove_favourite: function(response)
	{
		myappmaster.add_message('Favourite Removed', 5);
		if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
				x4hubProxy.call([X4HContacts, 'favourite_response'],
					'/ondemand/core/?method=CORE_FAVOURITE_MANAGE',
					{
						id: this.id,
						remove: '1'
					}
				);
			});
		}
		else
		{
			alert('Could not find favourite.');
		}
	},
	favourite_response: function(response)
	{
	
	},
    // Search for contacts
    find: function(contact_id, display_function) {
            if(display_function == null) {
            display_function = 'prefill_modal';
        }
        
        var oXML = new X4HASearch()
			.addField('firstname')
            .addField('surname')
            .addField('email')
            .addField('homephone')
            .addField('position')
            .addField('workphone')
            .addField('mobile')
            .addField('contactbusiness')
            .addField('contactbusinesstext')
            .addField('fax')
            .addField('streetaddress1')
            .addField('streetaddress2')
            .addField('streetsuburb')
            .addField('streetstate')
            .addField('streetcountry')
            .addField('streetpostcode')
			.addField('dateofbirth')
			.addField('sq6861')
			.addField('sq6934')
			.addField('sq6856') // LI
			.addField('sq6857') // Twitter
			.addField('sq6858') // FB
			.addFilter('id', 'EQUAL_TO', contact_id)
            .getXML();
		       
        x4hubProxy.call(
            [this, display_function],
            '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
            {
                advanced: 1,
                data: oXML
				//categoryid: 1172, //Messaging Information Category
            }
        );
    },
    
    // Search for contacts
    list: function(rows) {
        x4hubProxy.call(
            [this, 'list_response', 'contacts-main-list'],
            '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
            {rows: rows}
        );
    },
    
    list_response: function(response, container) {
		myappmaster.add_message('List Contacts', 5);
		$('#preloader-contact').hide();
        // Remove children
        $('#' + container).find('.contact-row').remove();
        
        if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                var row = $(
                    '<div id="contact-row-' + row.id + '" class="contact-row">'
                        + '<div class="contact-img"><img class="contact-profile-img" src="" id="img-' + row.id + '" width="50"/></div>'
                        + '<div class="contact-details">'
                        + '<div class="contact-firstname"> Name: ' + row.firstname + '&nbsp;' + row.surname +'</div>'
                        + '<div class="contact-email">Email: ' + row.email + '</div>'
                        + '<div class="contact-position"> Position: ' + row.position + '</div>'
                        + '<div class="contact-phone">Phone:' + row.workphone + '</div>'
                        + '<div class="contact-company"> Company: ' + row.company + '</div>'
                        + '<div class="contact-mobile">Mobile: ' + row.mobile + '</div>'
                    	+'</div>'
                        + '<div class="contact-options"><span id="contact-edit-' + row.id + '" class="contact-edit-anchor">Edit</span></div>'
                        + 
                    '</div>'
                );
                $('#' + container).append(row);
				row.id
            });
        }
        //if user is an admin, allow edit
       if(myappmaster.users.details.systemadmin!==undefined&&myappmaster.users.details.systemadmin=="true"){
            $.each( $( '.contact-edit-anchor' ), function(counter, elem) {
                $(elem).click(function() {
                    console.log('edit contact');
                    //$('.preloader-modal').dialog('open');
                    //$('.preloader-modal').dialog({title: 'Contacts'});

                    // Find out the id of what we're dealing with
                    var contact_id = myappmaster.find_id($(elem).attr('id'));
                    myappmaster.contacts.find(contact_id);

                });
            });
       }
		
		//This will eventually go through each contact and grab the contacts profile image for display
		/* $('.contact-profile-img').each(function(index) {
			var contact_id = myappmaster.find_id($(this).attr('id'));
            //Run a search for attachments to the contact records and change the src of the image to match the new src
			x4hubProxy.call(
				[X4HContacts, 'change_image'],
				'/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
				{
					object: 32, //Person Object
					objectcontext: contact_id,
					type: 260 //Profile Attachment type
				}
			);
		});*/
        
        
    },
	/* 21-12-2011 Adding this to change profile image after edit/update of contact */
    update_profile_image: function(contact_id, attachment_id) {
        var contact_image_uri = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + attachment_id + '&sid=' + x4hubProxy.sid;
        
        //change contact image in contact list
        $('#contact-row-'+contact_id+' div img').attr('src',contact_image_uri);
        
        //change contact image in contact overview
        $('#contact-person-img-'+contact_id).attr('src',contact_image_uri);
        
        //change contact image in company contacts
        $('#company-contact-'+contact_id).attr('src',contact_image_uri);
    },
    /*
    change_image_response : function(response,params){
	    if(response.data.rows.length>0){
           //var contact_image = response.data.rows[0];
           var attachment = response.data.rows[0];
           var contact_image_uri = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + attachment.id + '&sid=' + x4hubProxy.sid;
           $('#'+params.target_item+'-'+params.contact_id).attr('src',contact_image_uri);
        }
    },
    */
	
	// Search for a person based on the firstname and last name
    find_person: function(person_name, response_function, container) {
		var oXML = "<advancedSearch>"
            + "<field><name>firstname</name></field>"
            + "<field><name>surname</name></field>"
			+ "<field><name>contactbusiness</name></field>"
			+ "<field><name>contactbusinesstext</name></field>"
            + "<field><name>surname</name></field>"
            + "<field><name>email</name></field>"
            + "<field><name>homephone</name></field>"
            + "<field><name>workphone</name></field>"
            + "<field><name>mobile</name></field>"
			+ "<field><name>dateofbirth</name></field>"
            + "<field><name>streetaddress1</name></field>"
            + "<field><name>streetaddress2</name></field>"
            + "<field><name>streetsuburb</name></field>"
            + "<field><name>streetstate</name></field>"
            + "<field><name>streetsuburb</name></field>"
            + "<field><name>streetcountry</name></field>"
            + "<field><name>streetpostcode</name></field>"
			+ "<field><name>sq6856</name></field>" //LinkedIn
			+ "<field><name>sq6857</name></field>" //Twitter
			+ "<field><name>sq6858</name></field>" //Facebook
			+ "<field><name>sq6859</name></field>" //Secondary Email
			+ "<field><name>sq6860</name></field>" //Tertiary Email
			+ "<field><name>sq6861</name></field>" //Personal Email
			+ "<field><name>sq6864</name></field>" //Division
			+ "<filter>"
            + "<name>firstname</name><comparison>STRING_IS_LIKE</comparison><value1>" + person_name + "</value1>"
			+ "</filter>"
			+ "<filter><name>or</name><comparison></comparison><value1></value1><value2></value2></filter>"
			+ "<filter>"
			+ "<name>surname</name><comparison>STRING_IS_LIKE</comparison><value1>" + person_name + "</value1>"
            + "</filter>"
			+ "<filter><name>or</name><comparison></comparison><value1></value1><value2></value2></filter>"
			+ "<filter>"
			+ "<name>email</name><comparison>STRING_IS_LIKE</comparison><value1>" + person_name + "</value1>"
            + "</filter>"
            + "<options><rf>JSON</rf><startrow>0</startrow><rows>10</rows></options>"
            + "</advancedSearch>";
        
        x4hubProxy.call([X4HContacts, response_function, container],
            '/ondemand/contact/?method=CONTACT_PERSON_SEARCH&advanced=1',
            {
                data: oXML
            }
        );
    },
	email_recipient_search_response: function(response, container) {
		var aHTML = []
		aHTML.push('<table><tbody>');
		if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                aHTML.push('<tr class="email-address" id="email-' + this.id + '"><td>' + this.email+ '</td></tr>');
			});
		}
		else
		{
			aHTML.push('<tr><td>No People Found...</td></tr>');
		}
		aHTML.push('</tbody></table>');
		
		var aType = X4HEmail.search_type.split('-');
		if(aType[2] != null)
		{
		
		}
		else
		{
			aType[2] = 'to';
		}
		$('#' + aType[2] + 'div').find('.' + container)
		.html(aHTML.join(''))
		.slideDown('slow');
		
		$('html').click(function() {
			//Hide the menus if visible
			$('.email-recipient-results').hide();
		});
		/*$('.email-recipient-results').click(function(event) {
			event.stopPropagation();
		});*/
		
	},
    find_person_response: function(response, container) {
        myappmaster.add_message('Contact Search', 5);
		if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                var row = $(
                    '<div id="contact-row-' + row.id + '" class="contact-row">'
                        + '<div class="contact-img">' + '&nbsp;' + '</div>'
                        + '<div class="contact-details">'
                        + '<div class="contact-firstname"> Name: <span>' + row.firstname + '&nbsp;' + row.surname +'</span></div>'
                        + '<div class="contact-email">Email: <span>' + row.email + '</span></div>'
                        + '<div class="contact-position"> Position: ' + row.position + '</div>'
                        + '<div class="contact-phone">Phone:' + row.workphone + '</div>'
                        + '<div class="contact-company"> Company: <span>' + row.contactbusinesstext + '</span></div>'
                        + '<div class="contact-companyid" style="display:none;">' + row.contactbusiness + '</div>'
                                                + '<div class="contact-personid" style="display:none;">' + row.id + '</div>'
                                                //+ '<div class="contact-firstname">' + row.firstname + '</div>'
                        //+ '<div class="contact-lastname">' + row.surname + '</div>'
                        + '<div class="contact-mobile">Mobile: ' + row.mobile + '</div>'
                                                + '</div>'
                    +'</div>'
                );

                $('#' + container).append(row);
            });
        }
                
        $.each( $( '.contact-select-anchor' ), function(counter, elem) {
            $(elem).click(function() {		
                $('.preloader-modal').dialog('open');
                $('.preloader-modal').dialog({title: 'Contacts'});

                // Find out the id of what we're dealing with
                var contact_id = myappmaster.find_id($(elem).attr('id'));
                myappmaster.contacts.find(contact_id);

            });
        });
        
        /*
        $( '#person-search-screen .contact-row' ).click(function() {
            var contact_id = myappmaster.find_id($(this).attr('id'));
            $('#field-contactbusiness-id').val($(this).find('.contact-companyid span').text());
            $('#field-contactperson-id').val(contact_id);
            $('#field-setup-user-contactbusiness').val($(this).find('.contact-company span').text());
            $('#field-setup-user-contactperson').val($(this).find('.contact-firstname span').text());
            $('#field-setup-user-logonname').val($(this).find('.contact-email span').text());
            
            // Find out the id of what we're dealing with
            $('#person-search-screen').dialog( 'close' );                
        });

        this.show_find_response('person-search-screen');
        */
    },
    
    show_find_response: function(container) {
        $( '#' + container ).dialog({
            title: "Results",
            resizable: true,
            height: 600,
            width: 700,
            modal: true,
            buttons: {
                Cancel: function() {
                    $( this ).dialog( "close" );
                }
            }
        });
    },
	
    // MODAL DETAILS
    prefill_modal: function(response) {
		this.show_tab();
		//Populate the users image
		
		this.search_contact_image_field('populate_contact_image_field');
		       
		if(response.data.rows.length == 1) {
            var contact = response.data.rows[0];
            
            //cache details
            myappmaster.contacts.selected_contact_details = contact;
            
            $('#field-contact-id').val(contact.id);
            $('#field-contact-firstname').val(contact.firstname);
            $('#field-contact-lastname').val(contact.surname);
            $('#field-contact-email').val(contact.email);
            //$('#field-contact-homephone').val(contact.homephone);
            $('#field-contact-position').val(contact.position);
            $('#field-contact-workphone').val(contact.workphone);
            $('#field-contact-mobile').val(contact.mobile);
			var oDate = $.fullCalendar.parseDate(contact.dateofbirth)
			$('#field-contact-birthday').val($.fullCalendar.formatDate(oDate, 'dd/MM/yyyy'));
            // Address Fields
            $('#field-contact-streetaddress1').val(contact.streetaddress1);
            $('#field-contact-streetaddress2').val(contact.streetaddress2);
            $('#field-contact-streetsuburb').val(contact.streetsuburb);
            $('#field-contact-streetstate').val(contact.streetstate);
            $('#field-contact-streetpostcode').val(contact.streetpostcode);
            $('#field-contact-streetcountry').val(contact.streetcountry);
		} else {
            // Clear them all            
            this.clear_modal();
        }
    },
    clear_modal: function() {
        // Personal Details
        $('#field-contact-id').val(0);
        $('#field-contact-firstname').val('');
        $('#field-contact-lastname').val('');
        $('#field-contact-email').val('');
        $('#field-contact-homephone').val('');
        $('#field-contact-workphone').val('');
        $('#field-contact-mobile').val('');
        $('#field-contact-position').val('');
        // Address Fields
        $('#field-contact-streetaddress1').val('');
        $('#field-contact-streetaddress2').val('');
        $('#field-contact-streetsuburb').val('');
        $('#field-contact-streetstate').val('');
        $('#field-contact-streetpostcode').val('');
        $('#field-contact-streetcountry').val('');
    },
	search_contact_image_field: function(container) 
	{
		x4hubProxy.call(
            [X4HContacts, container],
            '/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
            {
                object: 32, //Person Object
                objectcontext: X4HContacts.selected_contact,
				type: 260 //Profile Attachment type
            }
		);
	},
	populate_contact_image_field: function(response) 
	{
		if(response.data.rows.length > 0)
		{
			var attachment = response.data.rows[0];
			var uri = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + attachment.id + '&sid=' + x4hubProxy.sid;
			$('#contact-image').html('<div class="profile-image"><img width="35" height="35" src="' + uri +'" /><span class="changecontactimage" id="del-' + attachment.attachment + '">&nbsp;</span></div>');
			$('.changecontactimage').button({
				label: 'Change'
			})
			.click(function(event)
			{
				//Remove Attachment then show browse area
				var aAttach = $(this).attr('id').split('-');
				X4HUser.remove_profile_image(aAttach[1]);		
				X4HUser.create_profile_upload(response, 'contact-image', X4HContacts.selected_contact);
			});
		}
		else
		{
			X4HUser.create_profile_upload(response, 'contact-image', X4HContacts.selected_contact);
		}
	},
	show_tab: function(tabType)
	{
		if(tabType == null) {
            tabType = 'Save';
        }
		if($( "#contacts-nav").find('a[href=#contact-manage-screen]').length==0)
		{
            //add a new tab
			$( "#contacts-nav").tabs("add","#contact-manage-screen", tabType);
        }
		else
		{
            $('#contacts-nav').find("#contact-manage-screen").html('');
        }
        var person_contacts = $('#contacts-nav').find("#contact-manage-screen");
		person_contacts.addClass("tabbed-section");
		
		person_contacts.append('<div id="contacts-header"  class="tabbed-content-header">' +
										'<h1>Manage Contact</h1>' +
										'<div id="contact-options">&nbsp;</div>' +
									'</div>' +
                                            '<div id="contact-manage-create" class="tabbed-content-body" >'+
                                            '<div id="contact-messages"></div>'+
			                    '<input type="hidden" id="field-contact-id"/>' +
									'<div class="column">' +
										'<h2>Personal</h2>' +
										    '<div class="form-row">' +
												'<label for="field-contact-firstname">First Name:</label>' +
												'<input type="text" id="field-contact-firstname" />' +
											'</div>' +
                                            '<div class="form-row">' +
											    '<label for="field-contact-lastname">Last Name:</label>' +
												'<input type="text" id="field-contact-lastname" />' +
											'</div>' +
											'<div class="form-row">' +
											    '<label for="field-contact-email">Email:</label>' +
												'<input type="text" id="field-contact-email" />' +
											'</div>' +
											'<div class="form-row">' +
												'<label for="field-contact-homephone">Position:</label>' +
												'<input type="text" id="field-contact-position" />' +
											'</div>' +
											'<div class="form-row">' +
												'<label for="field-contact-homephone">Phone:</label>' +
												'<input type="text" id="field-contact-workphone" />' +
											'</div>' +
											'<div class="form-row">' +
												'<label for="field-contact-workphone">Mobile:</label>' +
												'<input type="text" id="field-contact-mobile" />' +
											'</div>' +
											'<div class="form-row">' +
												'<label for="field-contact-birthday">Birthday:</label>' +
												'<input type="text" id="field-contact-birthday" />' +
											'</div>' +
									'</div>' +
									'<div class="column">' +
										'<h2>Address</h2>' +
										'<div class="form-row">' +
											'<label for="field-contact-streetaddress1">Address1:</label>' +
											'<input type="text" id="field-contact-streetaddress1" />' +
										'</div>' +
										'<div class="form-row">' +
											'<label for="field-contact-streetaddress2">Address2:</label>' +
											'<input type="text" id="field-contact-streetaddress2" />' +
										'</div>' +
										'<div class="form-row">' +
											'<label for="field-contact-streetsuburb">Suburb:</label>' +
											'<input type="text" id="field-contact-streetsuburb" />' +
										'</div>' +
										'<div class="form-row">' +
											'<label for="field-contact-streetstate">State:</label>' +
											'<input type="text" id="field-contact-streetstate" />' +
										'</div>' +
										'<div class="form-row">' +
											'<label for="field-contact-streetpostcode">Postcode:</label>' +
											'<input type="text" id="field-contact-streetpostcode" />' +
										'</div>' +
										'<div class="form-row">' +
											'<label for="field-contact-streetcountry">Country:</label>' +
											'<input type="text" id="field-contact-streetcountry" />' +
										'</div>' +
									'</div>'+
                                                                    '</div>');
		$('#contact-manage-create').append('<div id="contact-image">&nbsp;</div>');			
		$('#contacts-panel').append(person_contacts);
		//Append the contact options
		$('#contact-options').html('<span id="save-contact">&nbsp;</span><span id="cancel-save-contact">&nbsp;</span><span id="delete-contact">&nbsp;</span>');
		
		$('#field-contact-birthday').datepicker({
            dateFormat: 'dd/mm/yy',
			changeMonth: true,
			changeYear: true,
			yearRange: 'c-90:c-0'
        });
		
		//Bind the Buttons
		$('#save-contact').button({
			text: false,
			icons: {
				primary: "ui-icon-disk"
			},
			label: "Save"
		})
		.click(function(event) {
                
			 myappmaster.contacts.save_contact({
                id: $('#field-contact-id').val(),
                firstname: $('#field-contact-firstname').val(),
                surname: $('#field-contact-lastname').val(),
                email: $('#field-contact-email').val(),
                mobile: $('#field-contact-mobile').val(),
				dateofbirth: $('#field-contact-birthday').val(),
                phone: $('#field-contact-workphone').val(),
                position: $('#field-contact-position').val(),
                streetaddress1: $('#field-contact-streetaddress1').val(),
                streetaddress2: $('#field-contact-streetaddress2').val(),
                streetsuburb: $('#field-contact-streetsuburb').val(),
                streetstate: $('#field-contact-streetstate').val(),
                streetpostcode: $('#field-contact-streetpostcode').val(),
                streetcountry: $('#field-contact-streetcountry').val()
            });
            
                
		
            });
		$('#cancel-save-contact').button({
			text: false,
			icons: {
				primary: "ui-icon-close"
			},
			label: "Cancel"
		})
		.click(function(event) {
			$('#contacts-nav').tabs('select', '#contactsPeople');
		});
		
		if(tabType == 'Save') {
                        
                        if(X4HContacts.selected_contact!==myappmaster.users.details.contactperson){
			$('#delete-contact').button({
				text: false,
				icons: {
					primary: "ui-icon-trash"
				},
				label: "Delete"
			})
			.click(function(event) {
				myappmaster.contacts.remove_contact($('#field-contact-id').val());
                                $('#contact-manage-create').append($(
                                    '<div class="preloader-contact-overview" id="update-contact-preloader">'
                                    +'    <span><img src="/assets/images/preloader.gif" /><br  />deleting contact</span>'
                                    +'</div>'
                                ));
				//$('#contacts-nav').tabs('select', '#contactsPeople');
			});
                        }
        }
	
		//select new created tab
        $('#contacts-nav').tabs('select',$('#contacts-nav').tabs("length")-1);
		
		
	
	},
	
	show_company_tab: function(tabType)
	{
		if(tabType == null) 
		{
            tabType = 'Save';
        }
		if($( "#contacts-nav").find('a[href=#new-company-manage-screen]').length==0)
		{
            //add a new tab
			$( "#contacts-nav").tabs("add","#new-company-manage-screen", tabType);
        }
		else
		{
            $('#contacts-nav').find("#new-company-manage-screen").html('');
        }
		
		//CREATE COMPANY CONTACT
		
		var company_contacts = $('#contacts-nav').find("#new-company-manage-screen");
		company_contacts.addClass("tabbed-section");
		
		company_contacts.append('<div id="company-header" class="tabbed-content-header">' +
									'<h1>Profile</h1>' +
									'<div id="company-options">&nbsp;</div>' +
                                        '</div>'+                                
                                                                        
								'<div id="company-create" class="tabbed-content-body">'+
                                                                
								'<input type="hidden" id="field-company-id"/>' +
								'<div class="company-pic-row">' +
									'<div id="company-pic"><img src="/assets/images/companies02.png" width="96" class="company-img" id="company-pic-default"/></div>' +
									'<div id="company-pic-file">' +
									'</div>' +
								'</div>'+
								
								'<div class="column">' +
									'<h2>Company</h2>' +
									'<div class="form-row">' +
										'<label for="field-company-name">Name:</label>' +
										'<input type="text" id="field-company-name" />' +
									'</div>' +
								
									'<div class="form-row">' +
										'<label for="field-company-abn">ABN:</label>' +
										'<input type="text" id="field-company-abn" />' +
									'</div>' +
									
									'<div class="form-row">' +
										'<label for="field-company-email">Email:</label>' +
										'<input type="text" id="field-company-email" />' +
									'</div>' +
								'<div class="form-row">' +
										'<label for="field-company-webaddress">Website:</label>' +
										'<input type="text" id="field-company-webaddress" />' +
									'</div>' +                     
									'<div class="form-row">' +
										'<label for="field-company-phonenumber">Phone:</label>' +
										'<input type="text" id="field-company-phonenumber" />' +
									'</div>' +
									'<div class="form-row">' +
										'<label for="field-company-faxnumber">Fax:</label>' +
										'<input type="text" id="field-company-faxnumber" />' +
									'</div>' +
								'</div>' +
								
								'<div class="column">' +
								'<h2>Address</h2>' +
									'<div class="form-row">' +
										'<label for="field-company-streetaddress1">Address1:</label>' +
										'<input type="text" id="field-company-streetaddress1" />' +
									'</div>' +
									
									'<div class="form-row">' +
										'<label for="field-company-streetaddress2">Address2:</label>' +
										'<input type="text" id="field-company-streetaddress2" />' +
									'</div>' +
									
									'<div class="form-row">' +
										'<label for="field-company-streetsuburb">Suburb:</label>' +
										'<input type="text" id="field-company-streetsuburb" />' +
									'</div>' +
									
									'<div class="form-row">' +
										'<label for="field-company-streetstate">State:</label>' +
										'<input type="text" id="field-company-streetstate" />' +
									'</div>' +
									
									'<div class="form-row">' +
										'<label for="field-company-streetpostcode">Postcode:</label>' +
										'<input type="text" id="field-company-streetpostcode" />' +
									'</div>' +
									
									'<div class="form-row">' +
										'<label for="field-company-streetcountry">Country:</label>' +
										'<input type="text" id="field-company-streetcountry" />' +
									'</div>'+
                                                                    '</div>'+
                                                                '</div>');
                                                                
		company_contacts.append('<div id="company-image">&nbsp;</div>');
		$('#contacts-panel').append(company_contacts);
		//Append the company options
		$('#company-options').html('<span id="save-company">&nbsp;</span><span id="cancel-save-company">&nbsp;</span><span id="delete-company">&nbsp;</span>');
		
                //css fix
                $('#company-create').css('float', 'left');
		
		//Bind the Company-Create Buttons
		$('#save-company').button({
			text: false,
			icons: {
				primary: "ui-icon-disk"
			},
			label: "Save"
		})
		.click(function(event) {
                
                if($('#field-company-name').val()==''){
                    alert('Tradename is mandatory.')
                }else{
                    myappmaster.companies.save({
                        id: $('#field-company-id').val(),
                        tradename: $('#field-company-name').val(),
                        abn: $('#field-company-abn').val(),
                        email: $('#field-company-email').val(),
                        webaddress: $('#field-company-webaddress').val(),
                        phonenumber: $('#field-company-phonenumber').val(),
                        faxnumber: $('#field-company-faxnumber').val(),

                                        streetaddress1: $('#field-company-streetaddress1').val(),
                        streetaddress2: $('#field-company-streetaddress2').val(),
                        streetsuburb: $('#field-company-streetsuburb').val(),
                        streetstate: $('#field-company-streetstate').val(),
                        streetpostcode: $('#field-company-streetpostcode').val(),
                        streetcountry: $('#field-company-streetcountry').val()

                    });

                    if(X4HContacts.contact_edit_referrer=='company-list'){
                            $('#contact-nav').tabs('select', '#contactsCompanies');
                    }
                    if(X4HContacts.contact_edit_referrer=='company-overview'){
                            $('#contact-nav').tabs('select', '#companyOverview');
                    }
                }
            });
		$('#cancel-save-company').button({
			text: false,
			icons: {
				primary: "ui-icon-close"
			},
			label: "Cancel"
		})
		.click(function(event) {
			$('#contacts-nav').tabs('select', '#contactsCompanies');
		});
		
		if(tabType == 'Save') {
                        //allow delete to admin
                        if(myappmaster.users.details.systemadmin!==undefined&&myappmaster.users.details.systemadmin=="true"){
			$('#delete-company').button({
				text: false,
				icons: {
					primary: "ui-icon-trash"
				},
				label: "Delete"
			})
			.click(function(event) {
				myappmaster.companies.remove_company($('#field-company-id').val());
				//$('#contacts-nav').tabs('select', '#contactsCompanies');
				
			});
                        }else{
                            $('#delete-company').remove();
                        }
                        
        }
		//select new created tab
        $('#contacts-nav').tabs('select',$('#contacts-nav').tabs("length")-1);

	},	
	
    //added functions - Ram Alveyra (25-20-11)
    contact_overview : {
        preloader : $(
            '<div class="preloader-contact-overview" id="contact-person-body">'
            +'    <span><img src="/assets/images/preloader.gif" /><br  />loading contact details</span>'
            +'</div>'
        ),
            
        content_data : {
           contact_details : null,
           contact_company_details : null
           //contact_public_communications : null,
           //contact_communications_content : null
        },
        
        contact_image : null,contact_communications_content : null,
        
        filters : {},
        
        //tmp_contact_details : null, //cache contact details after search
            
        init : function(contact_id,contact_name){
            //console.log(myappmaster.users);
            
            var contact_overview = this;
            
            //clear data
            $.each(this.content_data,function(key,val){
                contact_overview.content_data[key] = null;
            });
            
            //clear filter
            this.filters = {};
                                        
            
            $( "#contacts-nav").tabs("add","#contactsOverview","Contact Overview");
            
            var contacts_overview = $('#contacts-nav').find("#contactsOverview");

            contacts_overview.addClass("tabbed-section");
            
            $('#contacts-panel').append(contacts_overview);

            $('#contacts-nav').tabs('select', $('#contacts-nav').tabs("length")-1);
            
            
            var header = $(
            '<div id="contacts-header"  class="tabbed-content-header">'
            +' <div id="contacts-header-options">'
            
            +' </div>'
            +    '<h1>'+contact_name+'</h1>'
            +'</div>' 
            );
                
            //if user is an admin, allow edit
            if(myappmaster.users.details.systemadmin!==undefined&&myappmaster.users.details.systemadmin=="true"){
                var edit_option = header.find('#contacts-header-options');
                edit_option.append($(
                    '<span><a href="#" class="edit-contact" id="edit-contact-'+contact_id+'">Edit</a></span>'
                ));
                
                //bind edit click
                edit_option.find('.edit-contact').click(function(){
                   var contact_id = myappmaster.find_id($(this).attr('id'));
                   //console.log(contact_id);
                   X4HContacts.contact_edit_referrer = 'contact-overview';
                   X4HContacts.selected_contact = contact_id;
                   myappmaster.contacts.find(contact_id);
                });
            }
                
            contacts_overview.append(header);
            
            this.set_content(contact_id);
        },
        
        //use this to handle multiple calls
        load_content : function(){
            var content_loaded = true;
            $.each(this.content_data,function(key,value){
                
                if(value==null){
                    console.log(key+":"+value);
                    content_loaded = false;
                    return
                }
                
            });
            
            if(content_loaded){
                var content_body = $('#contacts-nav').find("#contactsOverview");
                content_body.find('.preloader-contact-overview').remove();
                content_body.append(this.content_data.contact_details);
                content_body.find('#contact-info2').append(this.content_data.contact_company_details);
                content_body.find('#contact-person-pic').append(this.contact_image);
                content_body.append(this.content_data.contact_public_communications);
                
                /*this.content_data.contact_public_communications
                .find('#contact-emails-body')
                .append(this.content_data.contact_communications_content);*/
                //contact_emails.find('#contact-emails-body').append();
                
                    
            }
        },
        
        set_content : function(contact_id){
            //add content calls here
            $('#contacts-nav').find("#contactsOverview").append(this.preloader);
            this.set_contact_details(null,{contact_id:contact_id});
            this.set_contact_image(null,{contact_id :contact_id});
            
        },
        
        set_contact_details : function(response,params){
            if(response==null){
                
               var filters = [{name:'id',comparison:'EQUAL_TO',value1: params.contact_id}];
               myappmaster.contacts.search(null, filters, null, null, 'set_contact_details',
                {
                    callbackobj : myappmaster.contacts.contact_overview
                });
            }else if(response.data.rows.length>0){
				var contact_details = response.data.rows[0];
                //this.tmp_contact_details = contact_details;
				
				//Check if Twitter, Linked In, Facebook
				var sLinkedIn = '';
				var sTwitter = '';
				var sFacebook = '';
				if(contact_details.sq6856 != '')
				{ 
					sLinkedIn = '<a href="' + contact_details.sq6856 + '" target="_blank"><img src="/assets/images/in-btn01.png" /></a><br />';
				}
				if(contact_details.sq6857 != '')
				{ 
					sTwitter = '<a href="' + contact_details.sq6857 + '" target="_blank"><img src="/assets/images/t-btn01.png" /></a><br />';
				}
				if(contact_details.sq6858 != '')
				{ 
					sFacebook = '<a href="' + contact_details.sq6858 + '" target="_blank"><img src="/assets/images/f-btn01.png" /></a><br />';
				}
                var contact_body = $(
                    '<div id="contact-person-body">'
                    +'<div id="contact-person-pic"></div>'
                    +'  <div id="contact-info1">'
                    +'      <div id="contact-info-btns">'
                    + sLinkedIn
                    + sTwitter
                    + sFacebook
                    +'      </div>' 
                    +'      <span  id = "contact-info-name">'+contact_details.firstname+'&nbsp;'+contact_details.surname+'</span>'
                    
                    +'      <div id="contact-personal">'
                    +'        <span  id = "contact-info-company">Company: '+contact_details.contactbusinesstext+'</span>'
                    +'        <span  id = "contact-info-title">Position: '+contact_details.position+'</span>'
                    +'        <span  id = "contact-info-phone">'+contact_details.workphone+'</span>'
                    +'        <span  id = "contact-info-email">'+contact_details.email+'</span>'
                    +'      </div>'
                    +'  </div>'
                    
                    +'  <div id="contact-info2">'
                    
                    +'  </div>'
                    
                    +'  <div id="contact-note">Notes: '+contact_details.notes
                    +'  </div>'
                    +'</div>'
                );
                    
                var contact_emails = $(
                    '<div id="contact-emails">'
                    +'  <div id="contact-emails-header">'
                    +'      <h1>Public Emails from '+contact_details.firstname+'&nbsp;'+contact_details.surname+'</h1>'
                    /*+'      <div id="contact-emails-sort"><span><a href="#">All work Items</a> | <a href="#">By Due Date</a> | <a href="#">By Sprint</a> | <a href="#">By Department</a> ... <a href="#">More</a></span></div>'
                    +'      <div id="contact-emails-settings"><span><a href="#">Settings</a></span></div>'*/
                    +'  </div>'

                    +'  <div id="contact-emails-nav" class="communications">'
                    /*+'      <div id="contact-emails-nav-drop">'
                    +'          <input type="checkbox" />'
                    +'      </div>'
                    +'      <div id="contact-emails-nav-btn01">'
                    +'          <a href="#"><img src="/assets/images/email-img03.png" /></a>'
                    +'      </div>'
                    +'      <div id="contact-emails-nav-btn02">'
                    +'          <a href="#"><span>Archive</span></a>'
                    +'          <a href="#"><span>Spam</span></a>'
                    +'          <a href="#"><span>Delete</span></a>'
                    +'          <a href="#"><span>Move</span></a>'
                    +'          <a href="#"><span>Flag</span></a>'
                    +'          <a href="#"><span>Label</span></a>'
                    +'      </div>'*/
                    /*+       '<div id="contact-emails-search">'
                    +'          <input type="text" />'
                    +'          <a href="#"><img src="/assets/images/search-btn01.png" /></a><br /><br />'
                    +'      </div>'*/
                    /*+'      <div id="communications-search">'
                    +'          <input type="text" />'
                                            
                    +'          <form>'
                    +'          <div>'
                    +'              <select id="communications-dropdown-search" name="search" >'
                    +'                  <option value="0">Date</option>'
                    +'                  <option value="1">From</option>'
                    +'              </select>'
                    +'          </div>'
                    +'          </form>'

                    +'          <a href="#"><img src="/assets/images/search-btn01.png" /></a>'
                    +'      </div>'*/
                   
                    +'  </div>'

                    +'  <div id="contact-emails-body">'
                    +'      <div class="preloader-contact-communications" id="">'
                    +'          <span><img src="/assets/images/preloader.gif" /><br  />loading conversations</span>'
                    +'      </div>'
                    +'  </div>'

                    +'  <div id = "contact-emails-footer">'
                    +'      <div id="contact-emails-body-pagination" class="pagination-area"></div>'
                    +'  </div>'

                    +'</div>'
                );
                    
                this.content_data.contact_public_communications = contact_emails;    
                    
                this.content_data.contact_details = contact_body;    
                
                this.set_contact_company(null,{company_id: contact_details.contactbusiness});
                
                
                this.set_public_communications(null,{contact_details : contact_details});
                //this.load_content();    
             //$('#contacts-nav').find("#contactsOverview").append(contact_body);   
             
            }
        },
        
        set_contact_company : function(response,params){
            var company_details;
            if(response==null){
               if(params.company_id==''){
                   company_details = $(
                        '<span  id = "contact-info-name">This contact is not associated with any business.</span>'
                   );
                   this.content_data.contact_company_details = company_details;
                   this.load_content();
               }else{
                   
                var filters = [{name:'id',comparison:'EQUAL_TO',value1: params.company_id}];
                myappmaster.companies.search(null, filters, null, null, 'set_contact_company',
                {
                    callbackobj : myappmaster.contacts.contact_overview
                });
               }
               
            }else if(response.data.rows.length>0){
                var company_contact = response.data.rows[0];
                company_details = $(
                    '<span  id = "contact-info-name">Company information: '+company_contact.tradename+'</span>'                           
                    +'<div id="contact-personal">'
                    +'  <span  id = "company-info-phone">General Enquiries: '+company_contact.phonenumber+'</span>'
                    +'  <span  id = "company-info-fax">Fax: '+company_contact.faxnumber+'</span>'
                    +'  <span  id = "company-info-email">Email: '+company_contact.email+'</span>'
                    +'  <span  id = "company-info-web">Web: '+company_contact.webaddress+'</span>'
                    +'</div>'
                );
                this.content_data.contact_company_details = company_details;
                this.load_content();
            }
        },
        
        set_contact_image : function(response,params){
			$('.progressbar-loading').progressbar("option","value", 70);
			$('.state-loading').text('Loading Email');
            if(response==null){
                
                //remove previous pic
                this.contact_image = $(
                    '<img src = "/assets/images/avatar06.png" width="128px" height="80px" id="contact-person-img-'+params.contact_id+'"/>'
                );
                this.search_profile_image(params.contact_id,'set_contact_image',{contact_id:params.contact_id});
                
                
            }else if(response.data.rows.length>0){
                
				myappmaster.add_message('Profile Image Set', 5);
                var attachment = response.data.rows[0];
                
                var contact_image_uri = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + attachment.id + '&sid=' + x4hubProxy.sid;
                
                this.contact_image = $(
                    '<img src = "'+contact_image_uri+'" width="128px" height="80px" id="contact-person-img-'+params.contact_id+'"/>'
                );
                
                //set image
                $('#contact-person-pic').html(this.contact_image);
                    
            }else{
            console.log('no image');
                this.contact_image = $(
                    '<img src = "/assets/images/avatar06.png" width="128px" height="80px" id="contact-person-img-'+params.contact_id+'"/>'
                );
            }
        },
        
        search_profile_image: function(contact_id,callback,params) 
		{
            x4hubProxy.call(
            [this, callback, params],
            '/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
            {
                object: 32, //Person Object
                objectcontext: contact_id,
		type: 260 //Profile Attachment type
            }
            );
		},
        
        set_public_communications : function(response, params){
            var contact_overview = this;
            if(response==null){
                var contact_details = params.contact_details;
            
                
                
                //this.content_data.contact_public_communications = contact_emails;
                //this.load_content();
                //$('#contactsOverview').append(contact_emails);
                
                
                // get user details by contactid first
                x4hubProxy.call(
                [this, 'set_public_communications', {callType : 'user-fetch'}],
                '/ondemand/core/?method=CORE_USER_SEARCH',
                    {
                        contactperson : params.contact_details.id
                    }
                );
                
            }else{
                if(params.callType){
                    switch (params.callType)
                    {
                       case 'user-fetch' :
                           if(response.data.rows.length>0){
                              var user = response.data.rows[0];
                              this.get_contact_mail_actions(user.id,'set_public_communications',{callType:'actions-fetch', container : 'contact-emails-body',user : user});
                              
                              
                           }else{
                               contact_emails = this.content_data.contact_public_communications;
                               this.contact_communications_content = $(
                                    '<div style="padding:10px; border-bottom: solid 1px #d1d1d1;">No available communications to display.</div>'
                               );
                                   
                               this.content_data.contact_public_communications
                                .find('#contact-emails-body')
                                .html(this.contact_communications_content);
                               //this.load_content();
                               
                           }
                       break;
                       
                       case 'actions-fetch' :
                           contact_emails = this.content_data.contact_public_communications;
                           
                           if(response.data.rows.length>0){
                               var communications = response.data.rows;
                               var communication_row = '';
                               
                               //remove old data
                               $('#'+params.container).html('');
                               
                               $.each(communications,function(key,row){
                                    if(row.actiontype==5){//sent
                                        var contact = params.user.surname+' '+params.user.firstname;
                                    }else if(row.actiontype==9){
                                        contact = row.contactpersontext;
                                    }
                                    communication_row+='<div class="communication-row" id="communication-row-'+row.id+'">'
                                    +'  <div id="communications-contact">'+contact+'</div>'
                                    +'  <div id="communications-reference">'+row.actionreference+'</div>'
                                    +'  <div id="communications-date">'+row.duedatetime+'</div>'
                                    +'</div>';    
                                    
                               });
                               
                               
                                    
                           }else{
                               console.log('no records.');
                               communication_row = '<div style="padding:10px;">No available communications to display.</div>';
                               
                               /*
                               this.content_data.contact_public_communications
                                .find('#contact-emails-body')
                                .html(this.contact_communications_content);*/
                           }
                           
                           
                           this.contact_communications_content = $(communication_row);
                           
                           //append filters
                           var filter = $('      <div id="communications-search">'
                            +'          <input type="text" id="communications-filter-from"/>'
                            +'          <input type="text" id="communications-filter-date"/>'

                            +'          <form>'
                            +'          <div>'
                            +'              <select id="communications-dropdown-search" name="search" >'
                            +'                  <option value="date">Date</option>'
                            +'                  <option value="from">From</option>'
                            +'                  <option value="all" selected=selected>All</option>'
                            +'              </select>'
                            +'          </div>'
                            +'          </form>'

                            +'          <a href="#" id="communication-filter-btn"><img src="/assets/images/search-btn01.png" /></a>'
                            +'      </div>');
                            
                           var nav = this.content_data.contact_public_communications
                           .find('#contact-emails-nav')
                           
                           if(nav.find('#communications-search').length==0){
                               nav.append(filter);
                               //apply filter fix
                                $('#communications-dropdown-search').each(function(){
                                    var title = $(this).attr('title');
                                    if( $('option:selected', this).val() != ''  ) title = $('option:selected',this).text();
                                    $(this)
                                        .css({'z-index':10,'opacity':0,'-khtml-appearance':'none'})
                                        .after('<span id = "communications-search-span">' + title + '</span>')
                                        .change(function(){
                                            val = $('option:selected',this).text();
                                            $(this).next().text(val);
                                            })
                                });
                                
                                $('#communications-filter-date').datepicker({dateFormat: 'dd M yy'});
                                $('#communications-filter-date').hide();
                                //$('#communications-filter-from').hide();
                                
                                
                                //change input
                                $('#communications-dropdown-search').change(function(){
                                    var filter_option = $(this).val();
                                    //console.log(filter_option);
                                    
                                    $('#communications-filter-date').val('');
                                    $('#communications-filter-from').val('');
                                    
                                    if(filter_option=='date'){
                                        //initialize datepicker
                                        $('#communications-filter-date').show();
                                        $('#communications-filter-from').hide();
                                        
                                    }else if(filter_option=='from'){
                                        $('#communications-filter-date').hide();
                                        $('#communications-filter-from').show();
                                    }else if(filter_option=='all'){
                                        $('#communications-filter-date').hide();
                                        $('#communications-filter-from').show();
                                    }
                                });
                                //bind search
                               $('#communication-filter-btn').click(function(){
                                   contact_overview.content_data.contact_public_communications
                                    .find('#contact-emails-body')
                                    .html(
                                    '<div class="preloader-contact-communications" id="">'
                                    +'  <span><img src="/assets/images/preloader.gif" /><br  />loading conversations</span>'
                                    +'</div>'

                                    );
                                        
                                    //reset pagination
                                    $('#contact-emails-body-pagination').html('');
                                    
                                    if($('#communications-dropdown-search').val()=='all'){
                                        contact_overview.filters = {};
                                        contact_overview.get_contact_mail_actions(
                                        params.user.id,'set_public_communications',
                                        {
                                            callType:'actions-fetch', 
                                            container : 'contact-emails-body',
                                            user : params.user
                                        });
                                            
                                    }else if($('#communications-dropdown-search').val()=='date'){//console.log(params);
                                       var dateFilter =  $('#communications-filter-date').val()
                                       contact_overview.filters['date'] = dateFilter;
                                       contact_overview.get_contact_mail_actions(
                                       params.user.id,'set_public_communications',
                                       {
                                           callType:'actions-fetch', 
                                           container : 'contact-emails-body',
                                           user : params.user
                                           
                                       });
                                       
                                    }else if($('#communications-dropdown-search').val()=='from'){
                                        var fromFilter =  $('#communications-filter-from').val();
                                        /*var filters = [
                                                {
                                                    name:'firstname',
                                                    comparison:'TEXT_IS_LIKE',
                                                    value1: fromFilter
                                                },
                                                {
                                                    name:'or',
                                                    comparison:'',
                                                    value1: ''
                                                },
                                                {
                                                    name:'surname',
                                                    comparison:'TEXT_IS_LIKE',
                                                    value1: fromFilter
                                                },
                                        ];
                                        myappmaster.contacts.search(null, filters, null, null, 'filter_communications_by_contact',
                                        {
                                            callbackobj : myappmaster.contacts.contact_overview,
                                            params : {
                                                user : params.user.id,
                                                callback : 'set_public_communications',
                                                callback_params  : {
                                                    callType:'actions-fetch', 
                                                    container : 'contact-emails-body',
                                                    user : params.user
                                                }
                                            }
                                        });*/
                                        contact_overview.filters['from'] = fromFilter;
                                        contact_overview.get_contact_mail_actions(
                                        params.user.id,'set_public_communications',
                                        {
                                           callType:'actions-fetch', 
                                           container : 'contact-emails-body',
                                           user : params.user

                                        });
                                    }    
                               });
                            
                           }
                           
                           
                           
                           this.content_data.contact_public_communications
                                .find('#contact-emails-body')
                                .html(this.contact_communications_content);
                                
                           //bind row click
                           $.each($('.communication-row'),function(key,elem){
                               var row_id = myappmaster.find_id($(elem).attr('id'));
                               //console.log(row_id);
                               $('#communication-row-'+row_id).click(function(){
                                   var row_id = myappmaster.find_id($(this).attr('id'));
                                   //console.log(row_id);
                                   contact_overview.show_communication_details(row_id);
                               });
                           });
                       break;
                    }
                    
                }
                
                
            }
            //this.load_content();
            //console.log(this.content_data.contact_public_communications)
        },
        
        filter_communications_by_contact : function(response,params){
            console.log(response);
        },
        
       
        
        //get email for contact via action
        get_contact_mail_actions : function(user_id,callBack,params){
            var oXML = "<advancedSearch>"
            + "<field><name>ActionBy</name></field>"
            + "<field><name>ActionByText</name></field>"
            + "<field><name>ActionReference</name></field>"
            + "<field><name>Description</name></field>"
            + "<field><name>CompletedTime</name></field>"
            + "<field><name>ActionType</name></field>"
            + "<field><name>ActionTypeText</name></field>"
            + "<field><name>ContactBusiness</name></field>"
            + "<field><name>ContactBusinessText</name></field>"
            + "<field><name>LinkId</name></field>"
            + "<field><name>LinkType</name></field>"
            + "<field><name>ContactPerson</name></field>"
            + "<field><name>ContactPersonText</name></field>"
            + "<field><name>DueDate</name></field>"
            + "<field><name>DueDateTime</name></field>"
            /*+ "<field><name>streetsuburb</name></field>"
            + "<field><name>streetcountry</name></field>"
            + "<field><name>streetpostcode</name></field>"*/
            /*+ "<field><name>count</name></field>"*/
            + "<filter>"
            + "<name>ActionBy</name><comparison>EQUAL_TO</comparison><value1>" + user_id + "</value1>"
            + "</filter>"
            + "<filter>"
            + "<name>ActionType</name><comparison>IN_LIST</comparison><value1>5,9</value1>"
            + "</filter>";
            /*+ "<filter><name>or</name><comparison></comparison><value1></value1><value2></value2></filter>"
            + "<filter>"*/
            //console.log(this.filters)
            //if(this.filters.length>0){
            if(this.filters.date!==undefined){
                var dateFilter = this.filters.date;
                //console.log(new Date(dateFilter));
                oXML+= "<filter><name>DueDate</name><comparison>ON_DAY_MONTH</comparison><value1>"+dateFilter+"</value1>"
                + "</filter>"
            }
            
            if(this.filters.from!==undefined){
                var fromFilter = this.filters.from;
                oXML+= "<filter><name>ContactPersonText</name><comparison>TEXT_IS_LIKE</comparison><value1>"+fromFilter+"</value1>"
                + "</filter>"
            }
            //}
            
            oXML+= "<options><rf>JSON</rf><startrow>0</startrow></options>"
            +'<summaryField><name>count auditcount</name></summaryField>'
            
            + "</advancedSearch>";
        
            x4hubProxy.call(
                [this, callBack, params],
                '/ondemand/action/?method=ACTION_SEARCH',
                {
                   advanced : 1,
                   data : oXML,
                   rows : 10
                   
                }
            );
        },
        
        show_communication_details : function(communication_id){
            
            var communications_modal = $(
                '<div class = "public-communications-modal" title = "Details" id="public-communications-overview">'
                
                +'</div>'
            );
                
                
            
            //search for the modal and append
            if($.find('#public-communications-overview').length==0){
                  $('#contact-emails-body').append(communications_modal);
            }
            
            //load the modal
            $('#public-communications-overview').dialog({
                    //autoOpen: true,
                    resizable: false,
                    draggable: false,
                    width: 700,
                    height:600,
                    modal: true,
                    buttons: {
                        'Close' : function(){
                            $( this ).dialog( "close" );
                            
                        } 
                    }
                    //title : title
            });
            
            //add preloader
            $('#public-communications-overview').html(
                $('<span id="preloader-icon"><img src="/assets/images/preloader.gif?ver=0" /><br  /><span class="loader-text">loading details</span></span>')
            );
            
            //get email action
            x4hubProxy.call(
                [this, 'load_communication_details'],
                '/ondemand/messaging/?method=MESSAGING_EMAIL_ACTION_SEARCH',
                {
                   id : communication_id
                   
                }
            );
                
        },
        
        load_communication_details : function(response){
            if(response.data.rows.length>0){
                var email = response.data.rows[0];
                
                var aEmail_attachments = email.attachments.split('|');
                
                var public_communications_details = $(
                    '<div id="overview-details">'
                        //+'  <div class="email-read-header">'

                        +'      <div id="email-read-fields">'
                        +'          <div id="email-read-subject-fields">'
                        +'              <div id="email-read-subject" title="email Subject">Subject: '+email.subject+'</div>'
                        +'          </div>'
                        +'      </div>'
                    
                        +'      <div id="email-read-header-fields">'
                    
                        +'          <div id="email-read-left">'
                        +'              <div id="email-read-sent-from" title="Sender">From: '+email.from+'</div>' 
                        +'              <div id="email-read-sent-from-email" title="Sender email">'+email.fromemail+'</div>' 
                        +'              <div id="email-read-sent-to" title="email Recipient">To: '+email.to+'</div>' 
                        +'          </div>'
                    
                        +'          <div id="email-read-right">' 
                        +'              <div id="email-read-date" title="email Date">'+email.date+'</div>' 
                        //+'              <div id="email-read-attachments">'+aEmail_attachments.join(',')+'</div>'
                        +'          </div>'
                    
                        +'      </div>'
                        +'      <iframe name="ifPublicComms" id="ifPublicComms" frameborder="0" border="0" scrolling="no">'
                        +'      </iframe>'
                        //+'  </div>'
                    +'</div>'
                );
                    
                //Creates the iframe and then pushes the email content into the iframe
                setTimeout(function(){
                        while ($('#ifPublicComms').length == 0)
                        {
                        }
                        $('#ifPublicComms').contents().find('html').html('<div id="email-read-message" class="message-content" style="font-size: 11px;">' + email.message + '</div>');

                        if ($.browser.msie)
                        {
                        }
                        else
                        {	
                                var newHeight = $('#ifPublicComms',top.document).contents().find('html').height() + 100;
                        }

                        if ($.browser.msie)
                        {
                                setTimeout("setHeight()", 100);
                        }
                        else
                        {	
                                $('#ifPublicComms').height($('#ifPublicComms',top.document).contents().find('html').height())
                                //$('#ifPublicComms').width($('#ifPublicComms',top.document).contents().find('html').width())
                        }
                },300);    
                
                $('#public-communications-overview').html(public_communications_details);
                
            }else{
                alert('Error loading communication details');
            }
        }
        
        
    },
    /* end contact overview*/
    
    contact_search : {
      init : function(){
        
        
        //bind dropdown event
        /*$('#contacts-search-dropdown').change(function(){
            $('#contacts-search').find('input').attr('id','contacts-filter-'+$(this).val());
        });*/
        
        //bind search
        $('#contact-search-btn').unbind('click').click(function(){
            var filter_option = $('#contacts-search-dropdown').val();
            var filter=null;
            //reset pagination
            $('.contact-footer').find('#contacts-main-list-pagination').html('');
            /*switch(filter_option){
                case 'firstname' :
                    var firstname = $('#contacts-filter').val();
                    var filter = [{name:'firstname',comparison:'TEXT_IS_LIKE',value1: firstname}];
                    myappmaster.contacts.search(null, filter, null, null, null);
                    
                    
                break;
                
                case 'phone' :
                    var surname = $('#contacts-filter').val();
                    filter = [{name:'workphone',comparison:'TEXT_IS_LIKE',value1: surname}];
                    myappmaster.contacts.search(null, filter, null, null, null);
                break;
                
                default:
                    
                break;
            }*/
            if(filter_option!=='all'){
               var filter_text = $('#contacts-filter').val();
               filter = [{name:filter_option,comparison:'TEXT_IS_LIKE',value1: filter_text}]; 
            }    
            myappmaster.contacts.search(null, filter, null, null, null);
        })
      }  
    },
    
    
    /**added 01-11-11
    /* add contact to company (email)*/
    allocate_contact : function(response){
        console.log('Allocating contact to corresponding business')
        if(response.notes=="ADDED" || response.notes=="UPDATED"){
            var contact_id = response.id
            var contact_details = this.tmp_contact_details;
            var filters = [{name:'email',comparison:'EQUAL_TO',value1: contact_details.email}];  
            myappmaster.companies.search(null, filters, null, null, 'allocate_contact_response',
            {
                //selected_company:params.selected_company,
                callbackobj : this,
                contact_id : contact_id,
                user_notes : response.notes
            });
            //search for business for this contact
        }
    },
    
    allocate_contact_response : function(response,params){
        if(response.data.rows.length>0){
            var business_details = response.data.rows[0];
            if(params.user_notes=="ADDED"){
                /*myappmaster.contacts.save_contact({
                    id: params.contact_id,
                    contactbusiness : business_details.id
                });*/
                //update contact with new business
                x4hubProxy.call(
                    [this, 'allocate_contact_response_add',this.tmp_contact_details],
                    '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
                    {
                        id: params.contact_id,
                        contactbusiness : business_details.id
                    }
                );
            }else if (params.user_notes=="UPDATED"){
                //assign values to contact_details
                this.tmp_contact_details['contactbusiness'] = business_details.id;
                this.tmp_contact_details['contactbusinesstext'] = business_details.tradename;   
                
                //update contact with new business
                x4hubProxy.call(
                    [this, 'allocate_contact_response_update',this.tmp_contact_details],
                    '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
                    {
                        id: params.contact_id,
                        contactbusiness : business_details.id
                    }
                );
            }
        }else{//email has changed and company too
            this.tmp_contact_details['contactbusiness'] = '';
            this.tmp_contact_details['contactbusinesstext'] = '';
            //update contact, remove business
                x4hubProxy.call(
                    [this, 'allocate_contact_response_update',this.tmp_contact_details],
                    '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
                    {
                        id: params.contact_id,
                        contactbusiness : ''
                    }
                );
        }
    },
    
    //when contact is updated
    allocate_contact_response_update : function(response,contact){
        //workaround for contact phone 
        contact['workphone'] = contact.phone;
        
        // Update the row elements
        var row = this.generate_rowcontent(contact);
        $('#contact-row-' + contact.id).replaceWith(row);
        
        //check if the profile image did load
        $('#contact-row-'+contact.id+' div img').error(function() {
            //change to default image
            $(this).attr('src','/assets/images/avatar06.png');

        });
        
        //reattach triggers
        myappmaster.contacts.bind_contact_triggers(contact.id);
        //if(X4HContacts.contact_edit_referrer=='contact-list'){
            //var target_item = 'contact-edit';
        //}
        /*if(X4HContacts.contact_edit_referrer=='contact-list'){
            var target_item = 'contact-edit';
        }*/
        
        //change image after callback
        //var img_contact_id = contact.id;
        //this.change_image_from_edit(contact.id);
        /*x4hubProxy.call(
            [X4HContacts, 'change_image_from_edit',contact.id],
            '/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
            {
                    object: 32,
                    objectcontext:contact.id,
                    type: 260 //Profile Attachment type
            }
        );*/
        this.search(null, null, null, null, null);
    },
    
    //edit images when editing
    /*change_image_from_edit : function(response,contact_id){
        var target_img = [
            'contact-edit'
        ];
        
        //add to queue if editing from overview
        if(X4HContacts.contact_edit_referrer=='contact-overview'){
            target_img.push('contact-person-img');
        }
        
        $.each(target_img,function(key,target){
            X4HContacts.change_image_response(response, {
                contact_id : contact_id,
                target_item : target
            });
        });
        
        
    },*/
    
    allocate_contact_response_add : function(response,contact){
       this.search(null, null, null, null, null);
    },
    
    //enable button functions
    bind_contact_triggers : function(contact_id){
        console.log(contact_id);
        // Add edit anchors
        
        $('#contact-view-details-'+contact_id).click(function() {
            // Find out the id of what we're dealing with
            var contact_id = myappmaster.find_id($(this).attr('id'));
            //myappmaster.contacts.find(contact_id);
            var contact_name = $('#contact-row-name-'+contact_id).text();
            console.log('show contact details');
            myappmaster.contacts.contact_overview.init(contact_id, contact_name);
            
        });
        $('#contact-edit-'+contact_id).click(function() {
            console.log('edit contact');
            X4HContacts.contact_edit_referrer = 'contact-list';
            //$('.preloader-modal').dialog('open');
            //$('.preloader-modal').dialog({title: 'Contacts'});

            // Find out the id of what we're dealing with
            var contact_id = myappmaster.find_id($(this).attr('id'));
            myappmaster.contacts.find(contact_id);

        });
      
    },
	
	find_birthdays : function(oStartDate, oEndDate, container){
		console.log('Find Birthdays');
		//Must check if we are at the end of the year, this will mean two searches
		/*if(oStartDate.getMonth() == '11' && oEndDate.getMonth() == '0')
		{
			//We are at the end of the year so need to do two searches
			var first_oStartDate = new Date(oStartDate);
			var first_oEndDate = new Date(oStartDate);
			first_oEndDate.setDate(31);
			
			var second_oStartDate = new Date(oEndDate);
			var second_oEndDate = new Date(oEndDate);
			second_oStartDate.setDate(1);
						
			X4HContacts.find_birthdays(first_oStartDate, first_oEndDate, container);
			setTimeout(function() { 
					X4HContacts.find_birthdays(second_oStartDate, second_oEndDate ,container);
				}, 1000);
		}*/
		var sStartDate = $.fullCalendar.formatDate(oStartDate, 'd MMM yyyy');
		var sEndDate = $.fullCalendar.formatDate(oEndDate, 'd MMM yyyy');
		
		var filters = [{name:'dateofbirth',comparison:'BETWEEN_DAY_MONTH',value1: sStartDate, value2: sEndDate}];
		var fields = ['firstname', 'surname', 'dateofbirth', 'position', 'contactbusinesstext', 'sq6965', 'customerstatus'];
		var sort = [{name:'dateofbirth',direction:'desc'}];
		var oXML = new X4HASearch(fields, filters, this.defaultOptions, sort).getXML();
			
		x4hubProxy.call(
			[X4HContacts, 'find_birthdays_response', container],
			'/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
			{
				advanced: 1,
				data: oXML,
				rows: this.defaultPerPage
			}
		);
	},
	find_birthdays_response : function(response, container) {
		var aHTML = [];
		if(response.data.rows.length > 0) {
            //We have birthdays
			$.each(response.data.rows, function(key, row) {
                var sCurrentDate = this.dateofbirth;
				var sCurrentStatus = this.customerstatus;
				var sProfileImage = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + this.sq6965 + '&sid=' + x4hubProxy.sid;
				var sFullName = this.firstname + ' ' + this.surname;
				var sPosition = this.position;
				var sBusiness = this.contactbusinesstext;
				var aDate = this.dateofbirth.split(' ');
				var sCurrentDateShort = aDate[0] + aDate[1];
				if(sCurrentStatus == '5') //Internal
				{
					var sPersonString = '<div id="bday-person-id" class="firstfolian">' 
									  + '<div class="bday-person-pic">'
									  + '<img src="' + sProfileImage + '" width="34" height="34" />'
									  + '</div>'
									  + '<div class="bday-person-details">'
									  + '<span class="bday-name">' + sFullName + '</span><br>'
									  + '<span class="bday-job">' + sPosition + '</span>'
									  + '</div>'
									  + '</div>'
									  + '<img class="bday-separator" src="/assets/images/right-bday01.png"/>';	
				}
				else
				{
					var sPersonString = '<div id="bday-person-id" class="non-firstfolian">' 
									  + '<span class="bday-name" title="' + sPosition + ' - ' + sBusiness + '">' + sFullName + '</span>'
									  + '</div>'
				}
				
				if($('#date-' + sCurrentDateShort).length > 0)
				{
					//This already exists
					$('#date-' + sCurrentDateShort + ' .bday-people').append(sPersonString);
					
				}
				else
				{
					//Doesnt exist Create new
					aHTML.push('<div class="day-container" id="date-' + sCurrentDateShort + '">');
					aHTML.push('<span class="datetext">' + aDate[0] + ' ' + aDate[1] + '</span>');
					aHTML.push('<div class="bday-people-viewport">');
					aHTML.push('<div class="bday-people">');
					aHTML.push(sPersonString);
					aHTML.push('</div>')
					aHTML.push('</div>')
					$('#' + container).append(aHTML.join(''));
				}
				aHTML = [];
			});
		}
		else
		{
			//No Birthdays here
			//Doesnt exist Create new
			aHTML.push('<div class="day-container" id="date-NULL">');
			aHTML.push('<span class="datetext">&nbsp;</span>');
			aHTML.push('<div class="bday-people-viewport">');
			aHTML.push('<div class="bday-people">');
			aHTML.push('No Birthdays available');
			aHTML.push('</div>')
			aHTML.push('</div>')
			$('#' + container).html(aHTML.join(''));
		}
		$('#birthday-events-preloader').remove();
	},
   
   add_contact_to_group : function(contact_id, group_id, params){
       x4hubProxy.call(
            [params.callbackobj, params.callback, params],
            '/ondemand/contact/?method=CONTACT_PERSON_GROUP_MANAGE',
            {
                contactperson : contact_id,
                group : group_id
            }
        );
   },
   
   remove_contact_from_group : function(contact_group_id,params){
       x4hubProxy.call(
            [params.callbackobj, params.callback, params],
            '/ondemand/contact/?method=CONTACT_PERSON_GROUP_MANAGE',
            {
                id : contact_group_id,
                remove : 1
            }
        );
   }
}