/**
 * Created: 04/10/2011
 * Name: X4H Advanced Search
 */
function X4HASearch(fields, filters, options, sort) {
    // XML Constructor
    this.fields = (fields != null ? (fields.length > 0 ? fields : []) : []);
    this.filters = (filters != null ? (filters.length > 0 ? filters : []) : []);
    this.options = (options != null ? (options.length > 0 ? options : []) : []);
    this.sort = (sort != null ? (sort.length > 0 ? sort : []) : []);
    
    if(this.options == []) {
        //console.log('blah');
    } else { 
        //console.log(this.options); 
    }
    
    // Adds a field to the search object
    this.addField = function(field) {
        this.fields.push(field);
        return this;
    };
    
    // Adds a filter to the search object
    this.addFilter = function(field, comparison, value1, value2) {
        var filter = {
            name: field,
            comparison: comparison,
            value1: value1,
            value2: value2
        };
        
        if(value2 == null) {
            delete filter.value2;
        }
        
        this.filters.push(filter);
        return this;
    };
    
    // Adds an option to the search object
    this.addOption = function(type, value) {
        if(!this.options[type]) {
            this.options[type] = value;
        }
        return this;
    };
    
    // Adds a sort value to the search object
    this.addSort = function(field, direction) {
        if(direction == null) {
            direction = 'asc';
        }
        var sort = {
            name: field, 
            direction: direction
        };
        
        this.sort.push(sort);
        return this;
    };
    
    
    // Creates an XML string to make an advanced search 
    this.getXML = function() {
        var fieldsXML = '';
        var filtersXML = '';
        var optionsXML = '';
        var sortXML = '';
        
        
        if(this.fields.length > 0) {            
            $.each(this.fields, function(k, val) {
                fieldsXML += '<field><name>' + val + '</name></field>';
            });
            fieldsXML += '<summaryField><name>count auditcount</name></summaryField>';
        }

        if(this.filters.length > 0) {
            $.each(this.filters, function(id, filter) {
                filtersXML += '<filter>';
                $.each(filter, function(k, v) {
                    filtersXML += '<' + k + '>' + v + '</' + k + '>';
                });
                filtersXML += '</filter>';
            });
        }
        
        //console.log(this.options);
        
        if(this.options.length > 0) {
            optionsXML += '<options>';
            $.each(this.options, function(k, v) {
                optionsXML += '<' + k + '>' + v + '</' + k + '>';
            });
            optionsXML += '</options>';
        } else {
            optionsXML += '<options><rf>JSON</rf></options>';
        }
        
        if(this.sort.length > 0) {
            $.each(this.sort, function(k,v) {
                
                sortXML += '<sort><name>' + v.name + '</name><direction>' + v.direction + '</direction></sort>';
            });
        }
        
        var oXML = '<advancedSearch>' + fieldsXML + filtersXML + optionsXML + sortXML + '</advancedSearch>';
        
        //console.log(oXML);
        return oXML;
    };
}

var X4HASearchWidget = {
    search_criteria : null,
    
    search_string : null,
    
    /* flag to control advance search from sidebar */
    widget_search : false,
    
    search_filter : [],
    
    init : function(){
        var search_widget = this;    
        
        $('#left-sidebar-search-btn').click(function(){
            search_widget.search_criteria = $('#dropdown-search').val();
            search_widget.search_string = $('#left-sidebar-search-str').val();
            search_widget.widget_search = true;
            search_widget.search();
        });
    },
    
    search : function(){
        var search_widget = this;
        
        switch(this.search_criteria) {
            case 'email' :
                console.log('Searching email');
                $('#middle-nav').tabs('select', '#tab-email');
            break;
            
            case 'messages' :
                console.log('Searching Internal Communications');
                
                var filter = [
                    {
                        name : 'subject',
                        comparison : 'TEXT_IS_LIKE',
                        value1: search_widget.search_string
                    },
                    {
                        name : 'or',
                        comparison: '',
                        value1: ''
                    },
                    {
                        name : 'conversationtext',
                        comparison : 'TEXT_IS_LIKE',
                        value1: search_widget.search_string
                    }
                ];
                
                search_widget.search_filter = filter;
                
                var index = $('#middle-nav a[href="#tab-messages"]').parent().index();

                if($( "#middle-nav" ).tabs('option','selected')==index){
                    var messages_index = $('#messages-nav a[href="#conversationsOverview"]').parent().index();
                    if($( "#messages-nav" ).tabs('option','selected')==messages_index){
                        X4HCommunication.communications_panel.init();
                    
                    }else{
                        $('#messages-nav').tabs('select', '#conversationsOverview');
                    }
                    
                    //
                }else{
                    $('#middle-nav').tabs('select', '#tab-messages');
                }
            break;
            
            case 'events' :
                console.log('Searching Events');
                $('#middle-nav').tabs('select', '#tab-calendar');
                X4HCalendar.search_my_events.search_string = search_widget.search_string;
                X4HCalendar.search_my_events.add_event_list_tab();
                X4HCalendar.search_my_events.search();
                
            break;
            
            case 'files' :
                console.log('Searching Files');
                $('#middle-nav').tabs('select', '#tab-files');
            break;
            
            case 'edm' :
                console.log('Searching News');
                
                filter = [
                    {
                        name : 'subject',
                        comparison : 'TEXT_IS_LIKE',
                        value1: search_widget.search_string 
                    }
                ];
                
                search_widget.search_filter = filter;
                
                index = $('#middle-nav a[href="#tab-news"]').parent().index();

                if($( "#middle-nav" ).tabs('option','selected')==index){
                    
                    var edm_index = $('#edm-nav a[href="#edmNewsletters').parent().index();
                    
                    if($( "#edm-nav" ).tabs('option','selected')==edm_index){
                        //X4HCommunication.communications_panel.init();
                    
                    }else{
                        $('#edm-nav').tabs('select', '#edmNewsletters');
                    }
                }else{
                    $('#middle-nav').tabs('select', '#tab-news');
                }
                
                
            break;
            
            case 'contacts' :
                console.log('Searching Contacts');
                
                filter = [
                    {
                        name : 'firstname',
                        comparison : 'TEXT_IS_LIKE',
                        value1: search_widget.search_string 
                    },
                    
                    {
                        name : 'or',
                        comparison: '',
                        value1: ''
                    },
                    
                    {
                        name : 'surname',
                        comparison : 'TEXT_IS_LIKE',
                        value1: search_widget.search_string 
                    },
                    
                    {
                        name : 'or',
                        comparison: '',
                        value1: ''
                    },
                    
                    {
                        name : 'email',
                        comparison: 'TEXT_IS_LIKE',
                        value1: search_widget.search_string
                    },
                    
                    {
                        name : 'or',
                        comparison: '',
                        value1: ''
                    },
                    
                    {
                        name : 'contactbusinesstext',
                        comparison: 'TEXT_IS_LIKE',
                        value1: search_widget.search_string
                    },
                    
                    {
                        name : 'or',
                        comparison: '',
                        value1: ''
                    },
                    
                    {
                        name : 'workphone',
                        comparison: 'TEXT_IS_LIKE',
                        value1: search_widget.search_string
                    },
                    
                    
                ];
                
                search_widget.search_filter = filter;
                
                index = $('#middle-nav a[href="#tab-contacts"]').parent().index();
                
                if($( "#middle-nav" ).tabs('option','selected')==index){
                    
                    //var contact_index = $('#contacts-nav a[href="#contactsPeople').parent().index();
                    
                    //if($( "#contacts-nav" ).tabs('option','selected')==contact_index){
                        
                    
                    //}else{
                        $('#contacts-nav').tabs('select', '#contactsPeople');
                        X4HContacts.init();
                    //}
                    
                }else{
                    $('#middle-nav').tabs('select', '#tab-contacts');
                }
                
                
            break;
        }
        
    }
}
