/**
 * Created: 04/10/2011
 * Name: X4H Contact Company
 */
function X4HCompanies() {
    this.defaultFields = ['tradename', 'email', 'phonenumber', 'faxnumber', 'webaddress', 'sq6966'],
    
    
    
    this.init = function() {
        
        console.log('Initing: companies')
        
        /*$('.create-company').click(function() {
            myappmaster.companies.show_modal('Create');
            myappmaster.companies.clear_modal();
        });*/
				
        //this.search();
        
        this.list_companies();
    };
    
    
    //Added Ram Alveyra 10-28-11
    this.preloader = $(
            '<div class="preloader-company" id="preloader-company">'
            +'    <span><img src="/assets/images/preloader.gif" /><br  />loading companies</span>'
            +'</div>'
    );
    this.list_companies = function(){
        $('#companies-main-list').html(this.preloader);
        var fields = [
            'Tradename',
            'Area',
            'AreaText',
            'Industry',
            'IndustryText',
            'Notes',
            'OtherInfo',
            'Reference',
            'PhoneNumber',
            'FaxNumber',
            'Email',
            'WebAddress',
            'StreetAddressCombined',
            'StreetSuburb',
            'StreetPostCode',
            'StreetState',
            'StreetCountry',
			 'sq6966',            
        ];
        
        this.search(fields)
    };
    
    // Search for companies
    this.search = function(fields, filters, options, sort, callback, params) {
        if(fields == null) {
            fields = this.defaultFields;
        }
        if(filters == null) {
            filters = this.defaultFilters;
        }
        if(options == null) {
            options = this.defaultOptions;
        }
        if(sort == null) {
            sort = this.defaultSort;
        }
        
        //added by Ram Alveyra
        if(callback==null){
            callback = 'search_return';
        }
        if(params==null){
            params = 'companies-main-list';
            var callbackobj = this;
        }else{
            callbackobj = params.callbackobj;
        }
        
        var oXML = new X4HASearch(fields, filters, options, sort).getXML();
        this.last_query = {
            fields: fields,
            filters: filters,
            options: options,
            sort: sort
        };
       
        x4hubProxy.call(
            [callbackobj, callback, params],
            '/ondemand/contact/?method=CONTACT_BUSINESS_SEARCH',
            {
                advanced: 1,
                data: oXML,
                rows: 10
            }
        );
    };
    
    this.companies_obj = {};
    
    this.search_return = function(response, container) {
        if(response.data.rows.length > 0) {
            var rowcount = response.data.rows.length;
            $('#' + container).html('');
            $.each(response.data.rows, function(key, row) {
                var rowcontent = myappmaster.companies.generate_rowcontent(row);
                $('#' + container).append(rowcontent);
                
                //add to var
                myappmaster.companies.companies_obj[row.id]=row;
                
                if(key + 1 < rowcount) {
                    $('#' + container).append('<div class="company-person-line"></div>');
                }
            });
            
            //bind company view contacts
            $.each($('.company-contacts-btn-anchor'),function(key,elem){
               $(elem).click(function(){
                   var company_id = myappmaster.find_id($(elem).attr('id'));
                   //myappmaster.contacts.contact_overview.init(contact_id);
                   var selected_company = myappmaster.companies.companies_obj[company_id];
                   myappmaster.companies.company_contact_list.init(selected_company);
                   //console.log(myappmaster.companies.companies_obj);
               }); 
            });
            
            //bind company edit
            $.each($('.company-edit'),function(key, elem){
               var company_id =  myappmaster.find_id($(elem).attr('id'));
               
               $('#company-name-'+company_id).unbind('click').click(function(){
                   console.log(company_id);
                   //search business and prefill modal
                   var filter = [{name:'id',comparison:'EQUAL_TO',value1: company_id}];
                   
                   //set fields to get
                   var fields = [
                       'tradename', 
                       'email', 
                       'phonenumber', 
                       'faxnumber', 
                       'webaddress', 
                       'abn', 
                       'streetaddress1',
                       'streetaddress2',
                       'streetsuburb',
                       'streetstate',
                       'streetpostcode',
                       'streetcountry',
                       'streetaddresscombined'
                   ];
                   myappmaster.contacts.show_company_tab('Save');
                   
                   $('#company-create').find('div').hide();
                   
                   $('#company-create').css('float', 'none');
                   
                   $('#company-create').append($(
                   '<div class="preloader-company" id="preloader-company-create">'
                    +'    <span><img src="/assets/images/preloader.gif" /><br  />loading company details</span>'
                    +'</div>'
                   ));
                       
                   myappmaster.companies.search(fields, filter, null, null, 'prefill_modal', {callbackobj:myappmaster.companies})
                   
                   
               })
            });
            
            //search image and replace
            myappmaster.companies.change_image('company-img','company-pic');//params = target class to be replaced, target containing id, 
        }
    };
    
    this.company_contact_list = {
        init : function(selected_company){
            
            if($( "#contacts-nav").find('a[href=#companyContacts]').length==0){
                //add a new tab
                $( "#contacts-nav").tabs("add","#companyContacts","Company Contacts");
            }else{
                $('#contacts-nav').find("#companyContacts").html('');
            }
            
            var company_contacts = $('#contacts-nav').find("#companyContacts");
            
            
            company_contacts.addClass("tabbed-section");
            
            //add header
            var header = $(
                '<div id="contacts-header"  class="tabbed-content-header">'
                +    '<h1>Contacts at '+selected_company.tradename+'</h1>'
                +'</div>'
            );
                
            company_contacts.append(header);
            
            //add body container
            //company_contacts.append(this.company_contacts_body);
            
            //relocate content
            $('#contacts-panel').append(company_contacts);
            
            //select new created tab
            $('#contacts-nav').tabs('select',$('#contacts-nav').tabs("length")-1);
            
            //set content body
            this.set_content(selected_company);
            
        },
        
        company_contacts_body : $(
            '<div id="company_contacts_body" class="tabbed-content-body"></div>'
            
        ),
            
        company_contacts_preloader : $(
            '<div class="preloader-contact" id="company_contacts">'
            +'    <span><img src="/assets/images/preloader.gif" /><br  />loading contacts</span>'
            +'</div>'
        ),    
            
        set_content : function(selected_company){
            this.set_company_details(selected_company);
            this.set_company_contact_list(null,{selected_company:selected_company});
        },
        
        set_company_details : function(selected_company){
            
            var company_details = $(
                '<div class="tabbed-content-search">'
                +'    <div id="company-pic">'
                + '        <img src="/assets/images/companies02.png" width="96" id="overview-company-pic-'+selected_company.id+'" class="overview-company-img"/>'                     

                +'    </div>'/** TODO: Update image for company **/
                +'    <div id="company-info1">'
                +'      <span  id = "company-name"><strong>'+selected_company.tradename+'</strong><br /></span>'
                +'      <span  id = "company-description">'+selected_company.streetaddresscombined+'&nbsp;'+selected_company.streetsuburb+'&nbsp;'+selected_company.streetpostcode+'&nbsp;'+selected_company.streetstate+'&nbsp;'+selected_company.streetcountry+'</span>'
                +'    </div>'
                +'    <div id="company-info2">'
                +'      <span  id = "company-info-phone">Phone number: '+selected_company.phonenumber+'</span>'
                +'      <span  id = "company-info-fax">Fax: '+selected_company.faxnumber+'</span>'
                +'          <span  id = "company-info-email">Email: '+selected_company.email+'</span>'
                +'      <span  id = "company-info-web">Web: '+selected_company.webaddress+'</span>'
                +'    </div>'
                +'</div>'
            );
            $('#companyContacts').append(company_details);
            
            //myappmaster.companies.change_image('overview-company-img','overview-company-pic');
        },
        
        search_profile_image: function(contact, callback, params) 
	{
            var oXML = new X4HASearch()
                .addField('object')
                .addFilter('objectcontext', 'EQUAL_TO', 1000517229)
                .getXML();
                
            x4hubProxy.call(
            [this, callback, params],
            '/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
                {
                    //object: 32, //Person Object
                    //objectcontext: contact.id,
                    //type: 260, //Profile Attachment type
                    advanced : 1,
                    data : oXML
                }
            );
	},
        
        set_company_contact_list : function(response,params){
            
            if(response==null){
                var footer = $(
                '<div class="contact-footer">'
                +'  <div id="company_contacts_body-pagination" class="pagination-area"></div>'
                +'</div>'
                );
                this.company_contacts_body.html(this.company_contacts_preloader);
                
                
                $('#companyContacts').append(this.company_contacts_body);
                
                $('#companyContacts').append(footer);
                 
                var filters = [{name:'contactbusiness',comparison:'EQUAL_TO',value1: params.selected_company.id}];           //fields, filters, options, sort, callback, params
                myappmaster.contacts.search(null, filters, null, null, 'set_company_contact_list',
                {
                    selected_company:params.selected_company,
                    callbackobj : myappmaster.companies.company_contact_list,
                    container : 'company_contacts_body'
                });
                
            }else{
                myappmaster.companies.company_contact_list.company_contacts_body.html('');
                var contact_body = $('#company_contacts_body');
                
            
                if(response.data.rows.length>0){
                    var contacts = response.data.rows;
                    var rowcount = response.data.rows.length;
                   
                    //var sFavourite = '';
                    
                    /*myappmaster.companies.company_contact_list.search_profile_image(null,'set_company_contact_list',{
                           calltype : 'contact-details' 
                        });*/
                    $.each(contacts,function(key,row){
                        //get image and return
                        //var contact = row
                        var sLinkedIn = '';
                        var sTwitter = '';
                        var sFacebook = '';
                        var sProfileImage = '/assets/images/avatar06.png';
                        if(row.sq6856!==undefined&&row.sq6856 != '')
                        { 
                                sLinkedIn = '<a href="' + row.sq6856 + '" target="_blank" id="info-btn-sq6856-'+row.id+'"><img src="/assets/images/in-btn01.png" /></a><br />';
                        }
                        if(row.sq6857!==undefined&&row.sq6857 != '')
                        { 
                                sTwitter = '<a href="' + row.sq6857 + '" target="_blank" id="info-btn-sq6857-'+row.id+'"><img src="/assets/images/t-btn01.png" /></a><br />';
                        }
                        if(row.sq6858!==undefined&&row.sq6858 != '')
                        { 
                                sFacebook = '<a href="' + row.sq6858 + '" target="_blank" id="info-btn-sq6858-'+row.id+'"><img src="/assets/images/f-btn01.png" /></a><br />';
                        }
                        //Check if they have an attachment defined in their attachment id field
                        if(row.sq6965!==undefined&&row.sq6965 != '')
                        {
                                sProfileImage = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + row.sq6965 + '&sid=' + x4hubProxy.sid;
                        }
                        var contact_row = $(
                           
                            '<div class="company-person-info">'
                            +'    <div id="company-person-pic"><img src = "' + sProfileImage + '" class="company-contact-profile-img" id="company-contact-'+row.id+'" width="50"/></div>' /** TODO: Update image for multiple contacts **/

                            +'    <div id="contact-info-btns">'
                            + sLinkedIn
                            + sTwitter
                            + sFacebook
                            +'    </div>' 

                            +'    <span  id = "contact-row-name-'+row.id+'"><strong>'+row.firstname+'&nbsp'+row.surname+'</strong></span>'
                            +'    <span  id = "company-person-title">Position: '+row.position+'</span>'

                            +'    <div id="contact-personal">'
                            +'        <span  id = "company-person-phone">'+row.workphone+'</span>'
                            +'        <span  id = "company-person-email">'+row.email+'</span>'
                            +'        <a href="#" id="company-person-details-'+row.id+'" class="company-person-details">View Details</a>'
                            +'    </div>'
                            +'</div>'
                           
                        );
                       
                       contact_body.append(contact_row);
                       
                       if(key + 1 < rowcount) {
                            
                            contact_body.append('<div class="company-person-line"></div>');
                       }
                       
                       //check if the profile image did load
                       $('#company-contact-'+row.id).error(function() {
                            //change to default image
                            $(this).attr('src','/assets/images/avatar06.png');

                       });
                       
                       //if(key+1==rowcount){
                           
                           //$('#companyContacts').append(contact_body);
                       //}
                       
                    });
                    
                    $.each( $( '.company-person-details' ), function(counter, elem) {
                        $(elem).click(function() {
                            // Find out the id of what we're dealing with
                            var contact_id = myappmaster.find_id($(elem).attr('id'));
                            
                            var contact_name = $('#contact-row-name-'+contact_id).text();
                            myappmaster.contacts.contact_overview.init(contact_id, contact_name);
                        });
                    });
                    
                    
                    
                    
                }else{
                    var no_contacts = $(
                    '<p>There are no Contacts for this Business.</p>'
                    );
                    contact_body.append(no_contacts);
                    
                }
                
                
            }
            
            //var contact_row = $(
             //   '<div class="tabbed-content-body">'
                /*+'<div class="company-person-info">'
                +'    <div id="company-person-pic"><img src = "/assets/images/avatar08.png" /></div>'

                +'    <div id="contact-info-btns">'
                +'            <a href="#"><img src="/assets/images/in-btn01.png" /></a>'
                +'            <a href="#"><img src="/assets/images/t-btn01.png" /></a>'
                +'            <a href="#"><img src="/assets/images/f-btn01.png" /></a>'
                +'    </div>' 
                    
                +'    <span  id = "company-person-name">Gail Kelly</span>'
                +'    <span  id = "company-person-title">Position: Chief Executive Officer</span>'
                    
                +'    <div id="contact-personal">'
                +'        <span  id = "company-person-phone">02 9111 1133</span>'
                +'        <span  id = "company-person-email">gkelly@westpac.com.au</span>'
                +'        <a href="#"  id = "company-person-details">View Details</a>'
                +'    </div>'                                            
                +'</div>'*/
               // +'</div>'
           // );
            //$('#companyContacts').append(contact_row);    
        }
    };
    
    this.generate_rowcontent = function(row) {
        /*var content = ''
            + '<div class="company-row">'
            + '<span>Name: ' + row.tradename + '</span>'
            + '<span>Email: ' + row.email + '</span>'
            + '<span>WWW: ' + row.webaddress + '</span>'
            + '<span>Phone: ' + row.phonenumber + '</span>'
            + '<span>Fax: ' + row.faxnumber + '</span>'
            + '</div>';
        */
        var content = '<div class="company-row" id="company-row-'+row.id+'">'
            +'    <div id="company-pic">'
            +'        <img src="/assets/images/companies02.png" width="96" id="company-pic-' + row.id + '" class="company-img"/>'                     
            +'    </div>'
            +'    <div id="company-info1">'
            +'    <div class="company-contacts-btn">'
            +'        <a href="#" class="company-contacts-btn-anchor" id="company-contacts-anchor-'+ row.id +'">View Company Contacts</a>'
            +'    </div>'
			+'      <span  id = "company-name-'+row.id+'" class="company-edit" title="Edit Company"><strong>'+row.tradename+'</strong><br /></span>'
            +'      <span  id = "company-description">'+row.streetaddresscombined+'&nbsp;'+row.streetsuburb+'&nbsp;'+row.streetpostcode+'&nbsp;'+row.streetstate+'&nbsp;'+row.streetcountry+'</span>'
            +'    </div>'
            +'    <div id="company-info2">'
            +'      <span  id = "company-info-phone">Phone number: '+row.phonenumber+'</span>'
            +'      <span  id = "company-info-fax">Fax: '+row.faxnumber+'</span>'
            +'          <span  id = "company-info-email">Email: '+row.email+'</span>'
            +'      <span  id = "company-info-web">Web: '+row.webaddress+'</span>'
            +'    </div>'
            +'</div>'
            
        
        return content;
    };
    
    // Save the company
    this.save = function(company) {       
        // Check if id is not null
        var newCompany = false;        
        if(company.id == "" || company.id == null || parseInt(company.id) < 1) {
            newCompany = true;
            delete company.id;
        }
        
        var function_call = (newCompany ? 'save_response_new' : 'save_response_update');        
        
        x4hubProxy.call(
            [this, function_call, company],
            '/ondemand/contact/?method=CONTACT_BUSINESS_MANAGE',
            company
        );

        //myappmaster.companies.clear_modal();
    };
    // Save response - new
    this.save_response_new = function(response) {
		myappmaster.add_message('New Company has been Created.', 5);
        console.log("Created new company");
        console.log(response);
        this.list_companies();
    };
    // Save response - update
    this.save_response_update = function(response, company) {
		myappmaster.add_message('Company has been Saved.', 5);
        console.log("Updated company");
        //replace company default val
        company['streetaddresscombined'] = company.streetaddress1+' '+company.streetaddress2;
        var updated_row = this.generate_rowcontent(company);
        //replace old row
        $('#company-row-'+company.id).replaceWith(updated_row);
        
        //bind triggers that was lost by replaced
        myappmaster.companies.bind_company_triggers(company.id);
        
        //change profile pic
        myappmaster.companies.change_image('company-img','company-pic');//params = target class to be replaced, target containing id, 
    };
    
    //delete
    this.remove_company = function(id){
      var delete_confirm = confirm("Are you sure you want to delete this company?");  
      
      if(delete_confirm){
         $('#company-create').append($(
            '<div class="preloader-company" id="preloader-company-remove">'
            +'    <span><img src="/assets/images/preloader.gif" /><br  />deleting company</span>'
            +'</div>'
         ));
         //console.log(id)    
             
         x4hubProxy.call(
            [this, 'remove_company_response'],
            '/ondemand/contact/?method=CONTACT_BUSINESS_MANAGE',
            {
                id : id,
                remove : 1,
                removeActions : 1
            }
        );    
      }
    };
    
    this.remove_company_response = function(response){
        if(response.notes=='REMOVED'){
            myappmaster.add_message('Company has been removed.', 5);
            this.list_companies();
            $('#contacts-nav').tabs('select', '#contactsCompanies');
        }else{
            alert('Error deleting company');
        }
        $('#preloader-company-remove').remove();
    };
    
    this.bind_company_triggers = function(company_id){
        //bind company view contacts
       $('#company-contacts-anchor-'+company_id).click(function(){
           
           //myappmaster.contacts.contact_overview.init(contact_id);
           var selected_company = myappmaster.companies.companies_obj[company_id];
           myappmaster.companies.company_contact_list.init(selected_company);
           
       });
       
       //bind company edit
        
       $('#company-name-'+company_id).click(function(){

           //search business and prefill modal
           var filter = [{name:'id',comparison:'EQUAL_TO',value1: company_id}];

           //set fields to get
           var fields = [
               'tradename', 
               'email', 
               'phonenumber', 
               'faxnumber', 
               'webaddress', 
               'abn', 
               'streetaddress1',
               'streetaddress2',
               'streetsuburb',
               'streetstate',
               'streetpostcode',
               'streetcountry',
               'streetaddresscombined'
           ];

           myappmaster.companies.search(fields, filter, null, null, 'prefill_modal', {callbackobj:myappmaster.companies})

       });
       
    };
    
    
    
    // Popup Modal to add a Business
    // MODAL DETAILS
    this.prefill_modal = function(response) {        
        if(response.data.rows.length == 1) {
            
            var contact = response.data.rows[0];            
            //set id 
            $('#field-company-id').val(contact.id);
            
            //set values
            $('#field-company-name').val(contact.tradename);
            $('#field-company-email').val(contact.email);
            $('#field-company-faxnumber').val(contact.faxnumber);
            $('#field-company-phonenumber').val(contact.phonenumber);
            $('#field-company-webaddress').val(contact.webaddress);
                
            /* AUSTRALIAN ENTITIES */
            $('#field-company-abn').val(contact.abn);
                
                
            /* ADDRESS FIELDS */
            $('#field-company-streetaddress1').val(contact.streetaddress1);
            $('#field-company-streetaddress2').val(contact.streetaddress2);
            $('#field-company-streetsuburb').val(contact.streetsuburb);
            $('#field-company-streetstate').val(contact.streetstate);
            $('#field-company-streetpostcode').val(contact.streetpostcode);
            $('#field-company-streetcountry').val(contact.streetcountry);
            
            //add profile pic
            var current_img = $('#company-pic-'+contact.id).attr('src');
            
            $('#company-pic-default').attr('src',current_img);
            
            $('#company-pic-file').html('<form name="frmonDemandFileUploadCompany" action="' + x4hubProxy.site_url + '/directory/ondemand/attach.asp" enctype="multipart/form-data" method="POST" target="ifonDemandUploadCompany" id="frmonDemandFileUploadCompany">' 
            + '<input type="hidden" name="maxfiles" id="maxfiles" value="1">'
            + '<input type="hidden" name="sid" id="sid" value="' + x4hubProxy.sid + '">'
            + '<input type="hidden" name="linktype" id="linktype" value="12">'
            + '<input type="hidden" name="linkid" id="linkid" value="' + contact.id + '">'
            + '<input type="hidden" name="filetype0" id="filetype0" value="260">'
            
            
            +'<input id="co-pic-upload" class="co-pic-upload" type="file" name="oFile0" id="oFile0"/><button id="change-co-pic">Upload</button>'
            + '<iframe name="ifonDemandUploadCompany" id="ifonDemandUploadCompany" class="interfaceUploadCompany" frameborder="0"></iframe></form>');
        
            $('#change-co-pic').button({
                
            }).click(function(){
                //remove old pic
                //get id from src
                var src_txt = $('#company-pic-default').attr('src');
                var match = RegExp('[?&]' + 'attachment' + '=([^&]*)')
                .exec(src_txt);

                var attachment_id = match && decodeURIComponent(match[1].replace(/\+/g, ' '));
                
                if(attachment_id){
                    console.log(attachment_id);
                    myappmaster.companies.remove_company_profile_image(attachment_id);
                }
                myappmaster.companies.file_upload();
            });
			
        } else {
            // Clear them all            
            this.clear_modal();
        }
        
        //this.show_modal();
        
        $('#company-create').find('div').show();
        
        $('#preloader-company-create').remove();
        
        $('#company-create').css('float', 'left');
        
    };
    this.clear_modal = function() {
        console.log('clear contents');
        //set id 
        $('#field-company-id').val('');
        //remove file upload
        $('#company-pic-file').html('');
        //set values
        $('#field-company-name').val('');
        $('#field-company-email').val('');
        $('#field-company-faxnumber').val('');
        $('#field-company-phonenumber').val('');
        $('#field-company-webaddress').val('');

        /* AUSTRALIAN ENTITIES */
        $('#field-company-abn').val('');


        /* ADDRESS FIELDS */
        $('#field-company-streetaddress1').val('');
        $('#field-company-streetaddress2').val('');
        $('#field-company-streetsuburb').val('');
        $('#field-company-streetstate').val('');
        $('#field-company-streetpostcode').val('');
        $('#field-company-streetcountry').val('');
        
        //set profile image to blank
        $('#company-pic-default').attr('src','/assets/images/companies02.png');
        
    };
    this.show_modal = function(modalType)
    {
        if(modalType == null) {
            modalType = 'Save';
        }
        
        // Define the modals Buttons
        var buttonOptions = {};
        /*
        buttonOptions['Delete'] = function() {
            myappmaster.contacts.remove_contact($('#field-contact-id').val());
            $( this ).dialog( "close" );
        }
        */
        buttonOptions['Cancel'] = function() {
            myappmaster.companies.clear_modal();
            $( this ).dialog( "close" );
        }        
        buttonOptions[modalType] = function() {
            myappmaster.companies.save({
                id: $('#field-company-id').val(),
                tradename: $('#field-company-name').val(),
                email: $('#field-company-email').val(),
                phonenumber: $('#field-company-phonenumber').val(),
                faxnumber: $('#field-company-faxnumber').val(),
                webaddress: $('#field-company-webaddress').val(),
                
                /* AUSTRALIAN ENTITIES */
                abn: $('#field-company-abn').val(),
                
                
                /* ADDRESS FIELDS */
                streetaddress1: $('#field-company-streetaddress1').val(),
                streetaddress2: $('#field-company-streetaddress2').val(),
                streetsuburb: $('#field-company-streetsuburb').val(),
                streetstate: $('#field-company-streetstate').val(),
                streetpostcode: $('#field-company-streetpostcode').val(),
                streetcountry: $('#field-company-streetcountry').val()
            });
            $( this ).dialog( "close" );
        }
        
        
        $( "#company-manage-screen .tabs" ).tabs();
        $( '#company-manage-screen' ).dialog({
                title: modalType + " Company",
                resizable: true,
                height: 600,
                width: 700,
                modal: true,
                buttons: buttonOptions
        });
        
    };
    
    this.file_upload = function()
    {

		var oForm = document.frmonDemandFileUploadCompany;
		var iOnDemandTimerCount = 0;
		//oForm.submit();
		$('#frmonDemandFileUploadCompany').submit(function(){
                    //console.log($(this).serialize());
                    //myappmaster.companies.change_image('company-img','company-pic');
                    x4hubProxy.call_queued(
                    [myappmaster.companies, 'change_image_response',{company_id:'default',target_item: 'company-pic'}],
                        '/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
                        {
                                object: 12,
                                objectcontext:$(this).find($('#linkid')).val(),
                                type: 260 //Profile Attachment type
                        }
                    );
                })
		
    };
    
    this.change_image  = function(target_class, target_item){
        ajaxQueue.clearQueue();
        ajaxQueue.stop();
        $('.'+target_class).each(function(key,img){
            var company_id = myappmaster.find_id($(this).attr('id'));
            //console.log(contact_id);
            x4hubProxy.call_queued(
                [myappmaster.companies, 'change_image_response',{company_id:company_id,target_item: target_item}],
                '/ondemand/core/?method=CORE_ATTACHMENT_SEARCH',
                {
                        object: 12,
                        objectcontext:company_id,
                        type: 260 //Profile Attachment type
                }
            );
        });
    },
    
    this.change_image_response = function(response,params){
	    if(response.data.rows.length>0){
           //var contact_image = response.data.rows[0];
           var attachment = response.data.rows[0];
           var company_image_uri = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + attachment.id + '&sid=' + x4hubProxy.sid + '&attachment=' +attachment.attachment;
           
           $('#'+params.target_item+'-'+params.company_id).attr('src',company_image_uri);
        }
    };
    
    this.remove_company_profile_image = function(attachment)
    {
        x4hubProxy.call(
        [myappmaster.companies, 'remove_company_profile_image_response'],
        '/ondemand/core/?method=CORE_ATTACHMENT_MANAGE',
        {
            id: attachment, 
            remove: 1
                    }
            );
    };

    this.remove_company_profile_image_response = function(response)
    {
		myappmaster.add_message('Company Profile Image Removed.', 5);
        var default_img = '/assets/images/companies02.png';
            $('#company-pic-default').attr('src',default_img);
    };
}