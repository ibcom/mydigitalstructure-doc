var X4HCalendar = {
    containing_element : '#calendar-overview',
    main_calendar_options : {
    /* add main calendar module variables/configs here */
    
        //number of previous months to display
        previous_month_start : null,
        
        //number of month range to display starting from current month
        month_range : 1

    },
    plugin_calendar_options : {
    /* add main plugin calendar variables/configs here */    
        
    },
    
    time_handler : {
        
    },
    
    
    calendar_theme : {
      /* calendar layout tweaks */  
    },
    
    event_categories : null,
    
    
    invited_events : {},
    
    event_host : {
        email : null
    },
    
    selected_event : null,
    
    /* calendar vars */
    my_events : null, 
    my_event_actions : null, 
    event_actions : null, 
    today : null, 
    events_array : null,
    events_array_personal : null,
    events_array_shared : null,
    selected_event_category : null, 
    overview_preloader : null, 
    my_attended_events: null, 
    accepted_event_array: null,
    personal_calendar_action_events : null,
    personal_cal_accepted_event_array : [],
    
    //for action
    defaultActionFields : [
        'ActionType',
        'ActionReference',
        'ActionBy',
        'DueDate',
        'ActionTypeText',
        'Status',
        'StatusText',
        'Description',
        'LinkId',
        'LinkType',
        'DueDateTime',
        'TotalTimeHrs',
        'TotalTimeMin',
        'CompletedTime'
        
    ],
    
    defaultActionSort: [{name: 'DueDate', direction: 'asc'}],
    
    scheduled_event_hasLoaded : false, calendar_update_flag : false,
    
    hosted_events : null,
    
    
    selected_date : null,
    
    event_attendees : null,
    
    created_events : null,
    
    action_events : null,
    
    actions_shared : null,
    
    actions_to_share : null,
    
    actions_to_delete : null,
    
    shared_actions : null,
    
    selected_calendar : $('.calendarOverview'),//default
    
    shared_calendar : {
        shared_events : [],
        calendar_events : [],
        current_calendar : null,
        init : function(){
            
            X4HCalendar.get_event_gategories();
        }
    },
    
    tab_index : 0,
    
    init : function(){
        var selected = $( "#calendar-nav" ).tabs( "option", "selected" );
        
        var today = new Date();
       
        X4HCalendar.today = $.datepicker.formatDate('dd/mm/yy', today);
        
        if(selected==0){
            
            /* Remove previous data and load pre-loader each time the tab is selected */
            $(X4HCalendar.containing_element).html('');
            $('#calendar-overview').html('');
            X4HCalendar.overview_preloader = $('#preloader-calendar-overview');
            X4HCalendar.overview_preloader.show();
            
            /* Get the IDs of events in this particular category (personal calendar events) */
            X4HCalendar.get_event_gategories();
            
            /** 
             * Set the type of calendar selected.
             * This is needed for the page to know the calendar that needs to load the events when access simultaneously i.e. widget etc.
             **/
            X4HCalendar.calendar_index = "personal";
            
            X4HCalendar.selected_calendar = $('.calendarOverview');
            /* prevent user from clicking these buttons while it has not been loaded yet */
            $('#ffoffice-calendar-widget').find('.fc-header-right .fc-button-next').addClass('fc-state-disabled');
            $('#ffoffice-calendar-widget').find('.fc-header-left .fc-button-prev').addClass('fc-state-disabled');
        }else{
            
            /* Each time the Calendar tab is selected (on init), 'My Calendar' sub-tab is selected by default */
            $('#calendar-nav').tabs('select',0);
            
        }
        
        /* By default, the details sub-tab is hidden */
        $('#calendar-nav').find('.eventDetails').parent().hide();
        
        /**
         * Controls for selecting sub-tabs inside Calendar page
         * My Calendar, Shared Calendar, Calendar Invites
         **/
        $( "#calendar-nav" ).tabs({
            
            select : function(event,ui){
                
                if(ui.index==0){
                    X4HCalendar.containing_element = '#calendar-overview';
                    
                    $(X4HCalendar.containing_element).html('');
                    
                    X4HCalendar.overview_preloader = $('#preloader-calendar-overview');
                    X4HCalendar.overview_preloader.show();
                    
                    X4HCalendar.selected_calendar = $('.calendarOverview');
                    $('#calendar-nav').find('.eventDetails').parent().hide();
                    X4HCalendar.tab_index=ui.index;
                    X4HCalendar.get_event_gategories();
                    
                    
                    X4HCalendar.calendar_index = "personal";
                    
                    
                }else if(ui.index==1){
                    $('#calendar-select').hide()//populate calendar types
                    X4HCalendar.containing_element = '#calendar-shared-overview';
                    X4HCalendar.selected_calendar = $('.sharedCalendar');
                    
                    $('#calendar-shared-overview').html('');
                    
                    X4HCalendar.overview_preloader = $('#preloader-calendar-shared');
                    X4HCalendar.overview_preloader.show();
                    
                    X4HCalendar.shared_calendar.init();
                    $('#calendar-nav').find('.eventDetails').parent().hide();
                    X4HCalendar.tab_index=ui.index;
                    
                    X4HCalendar.calendar_index = "shared";
                    
                }else if(ui.index==2){
                    
                    $('#preloader-calendar-event').show();
                    X4HCalendar.list_new_events(20);
                    $('#calendar-nav').find('.eventDetails').parent().hide();
                    X4HCalendar.tab_index=ui.index;
                }
                
                /* prevent user from clicking these buttons while it has not been loaded yet */
                $('#ffoffice-calendar-widget').find('.fc-header-right .fc-button-next').addClass('fc-state-disabled');
                $('#ffoffice-calendar-widget').find('.fc-header-left .fc-button-prev').addClass('fc-state-disabled');
            },
            
            /**
             * Added this to remove sub-tabs (child) other than the default tabs
             * Tab not removed are the default tabs identified through tab length
             * This is triggered everytime a new sub-tab is selected
             * This will also refresh Rich Text editor initialised inside the sub-tab
             **/
            show : function(event, ui){
                var tabindex = $(this).tabs("length")-1;
                if(ui.index!=tabindex){
                    if(tabindex>3){ //default tab length
                        
                        tinyMCE.execCommand('mceRemoveControl', false, 'add-event-description');
                        tinyMCE.execCommand('mceRemoveControl', false, 'decline-event-reason');
                        $(this).tabs("remove",tabindex);
                        
                    }
                }
                $('#calendar-items').dialog('close');
                
            }
            
        });
    },
    
    get_event_gategories : function(){
        
        //if(X4HCalendar.event_categories==null){
            x4hubProxy.call(
            [X4HCalendar, 'get_event_gategories_response'],
            '/ondemand/setup/?method=SETUP_EVENT_CATEGORY_SEARCH',
                {
                    
                }
            );
        /*}else{
           
           X4HCalendar.get_event_gategories_response({
               data : {
                   rows : X4HCalendar.event_categories
               }
           }); 
        }*/
    },
    
    get_event_gategories_response : function(response,params){
        //console.log(response)
        if(response.data.rows.length > 0){
            X4HCalendar.event_categories = response.data.rows;
            
            if(X4HCalendar.calendar_index=="shared"){
                
                $('#calendar-dropdown-select').html('');
                
                X4HCalendar.event_categories = X4HCalendar.event_categories.reverse();
                
                $.each(X4HCalendar.event_categories,function(key,val){
                    var cal_option = $(
                        '<option value="'+val.id+'">'+val.title+'</option>'
                    );
                    if(val.id!=27){
                    $('#calendar-dropdown-select').append(cal_option);    
                    }
                });
                
                
                /* bind only if change event does not exists */
                if($('#calendar-dropdown-select').data('events')==undefined){
                    $('#calendar-dropdown-select').change(function(){
                        //refresh calendar
                        $('#calendar-shared-overview').html('');
                        $('#preloader-calendar-shared').show();
                        X4HCalendar.selected_event_category = $('#calendar-dropdown-select').val()
                        X4HCalendar.get_events_by_category($('#calendar-dropdown-select').val());
                        $(this).attr('disabled','disabled');
                    });
                }else{
                    
                    $('#calendar-dropdown-select').val(X4HCalendar.selected_event_category)
                }

                X4HCalendar.get_events_by_category($('#calendar-dropdown-select').val());

                
                
                //refresh calendar
                $('#calendar-shared-overview').html('');
                $('#preloader-calendar-overview').show();
                
        
                
            }else if(X4HCalendar.calendar_index=="personal"||X4HCalendar.calendar_index=="widget"){
                X4HCalendar.selected_event_category = 27;
                X4HCalendar.get_events_by_category(27)//Personal Calendar;
            }
            
        }else{
            alert('Error loading calendar');
            
        }
    },
    
    get_my_attended_events : function(params){
        x4hubProxy.call(
            [X4HCalendar,'get_my_events_response',params],
            '/ondemand/event/?method=EVENT_ATTENDEE_SEARCH',
            {
                me : 1,
                status : 3,
                rows: 1000
            }
        );
    },
    
    get_my_events_response : function(response,params){
        var accepted_event_array = [];
        if(response.data.rows.length > 0) {
            X4HCalendar.my_attended_events = response.data.rows;
            
            //push to events to query
            $.each(X4HCalendar.my_attended_events,function(key,val){
                //params.event_id_array.push(val.event);
                accepted_event_array.push(val.event);
            });
            
        }
        
        //then call actions
        X4HCalendar.get_event_actions(X4HCalendar.today,{
            event_id_array : params.event_id_array,
            accepted_event_array : accepted_event_array
        });
    },
    
    get_my_events : function(){
        
        //this.get_my_events_response();
        var oXML = new X4HASearch()
        .addField('Reference')
        /*.addField('HostContPerson')
        .addField('HostContactPersonText')*/
        .addField('StartDate')
        /*.addField('EndDate')
        .addField('Status')
        .addField('StatusText')
        .addField('Description')
        .addField('Public')*/
        /*.addField('streetaddress2')
        .addField('streetsuburb')
        .addField('streetstate')
        .addField('streetcountry')
        .addField('streetpostcode')*/
        .addFilter('StartDate', 'MONTH_TO_DATE','02/11/2011')
        .getXML();
        
        x4hubProxy.call(
            [X4HCalendar,'get_my_events_response'],
            '/ondemand/event/?method=EVENT_SEARCH',
            {
                advanced:1,
                data : oXML
                
                //status : 3
            }
        );
    },
    
    get_event_actions : function(calendar_date,params){
        
        //var accepted_event_array = ()?0:params.accepted_event_array;
        
        if(params==undefined||params.filters==undefined){
            //default filters
            var filters = [
                {
                    name : 'LinkId',
                    comparison : 'IN_LIST',
                    value1 : params.event_id_array
                },
                {
                    name : 'DueDate',
                    comparison : 'IN_MONTH',
                    value1 : calendar_date
                    
                },
                {
                    name : 'LinkType',
                    comparison : 'EQUAL_TO',
                    value1 : 39
                    
                },
                {
                    name : 'ActionBy',
                    comparison : 'EQUAL_TO',
                    value1 : X4HUser.contact_person
                    
                }
            ];
        }else{
            filters = params.filters;
        }
        
        if(!(params.accepted_event_array==undefined||params.accepted_event_array.length==0)){
            filters.push(
                {
                    name : 'or',
                    comparison : '',
                    value1 : ''
                }
            );
                
            filters.push(
                {
                    name : 'LinkId',
                    comparison : 'IN_LIST',
                    value1 : params.accepted_event_array
                }
            );
                
            filters.push(
                {
                    name : 'DueDate',
                    comparison : 'IN_MONTH',
                    value1 : calendar_date
                }
            );
                
            filters.push(
                {
                    name : 'LinkType',
                    comparison : 'EQUAL_TO',
                    value1 : 39
                }
            );
                
            /*filters.push(
                {
                    name : 'ActionBy',
                    comparison : 'EQUAL_TO',
                    value1 : X4HUser.contact_person
                }
            );*/    
                
        }
        
        
        /* if public flag (for shared calendar) is true, remove condition for contact field */
        if(params!==undefined&&params.isPublic!==undefined&&params.isPublic==true){
            $.each(filters,function(key,val){
                if(val.name=='ActionBy'){
                    filters.splice(key,1);
                 
                }
            });
            
        }
        
        var oXML = new X4HASearch(X4HCalendar.defaultActionFields, filters, null, null).getXML();
        
        var callBack = 'get_event_actions_response';
        
        var callBackObj = X4HCalendar;
        
        if(params!==undefined && params.callBackObj!==undefined && params.callBack!==undefined){
            callBack = params.callBack;
            callBackObj = params.callBackObj;
        }
        
        x4hubProxy.call(
            [callBackObj,callBack,params],
            '/ondemand/action/?method=ACTION_SEARCH',
            {
                advanced:1,
                data : oXML,
                rows:1000
                
            }
        );
    },
    
    get_event_actions_response : function(response,params){
       if(response.data.rows.length > 0) {
            var event_actions = response.data.rows;
            
       }else{
            event_actions = {};
            //X4HCalendar.event_actions = {};
       }
       /*if(X4HCalendar.calendar_index == 'widget'){
           
       }else{*/
           X4HCalendar.event_actions = event_actions;
       /*}*/
       
       if(X4HCalendar.calendar_update_flag==true&&X4HCalendar.calendar_index!=='shared'){
           $('#left-sidebar-sched-content').html(X4HCalendar.scheduled_events.preloader);
           X4HCalendar.scheduled_events.get_scheduled_events();
           X4HCalendar.calendar_update_flag=false;
           
       }//else if(X4HCalendar.calendar_update_flag==true&&X4HCalendar.calendar_index=='shared'){
           //console.log(X4HCalendar.selected_event_category);
           /* if calendar details has been updated and calendar type is 'Firstfolio Corporate */
           //console.log('update corporate upcoming ');
       //}
       X4HCalendar.load_events(params);
    },
    
    get_time_from_date : function(date_obj){
        var date_obj_hours = date_obj.getHours();
        var date_obj_mins = date_obj.getMinutes();

        if (date_obj_mins < 10) {date_obj_mins = "0" + date_obj_mins;}
        
        var date_obj_am_pm = (date_obj_hours < 12) ? 'am': 'pm';
        
        // This turns midnight into 12 AM, so ignore if it's already 0
        if (date_obj_hours != 0) {
            date_obj_hours = ((date_obj_hours + 11) % 12) + 1;
        }else{
            date_obj_hours=12;
        }
        
        
        
        if (date_obj_hours < 10) {date_obj_hours = "0" + date_obj_hours;}
        

        return date_obj_hours+":"+date_obj_mins+' '+date_obj_am_pm; 
    },
    
    load_events : function(params){
        if(X4HCalendar.calendar_index=="shared"){
            console.log('shared');
           
            X4HCalendar.shared_calendar.shared_events =  X4HCalendar.event_actions;
        }else if(X4HCalendar.calendar_index=="personal"||X4HCalendar.calendar_index=="widget"){
            console.log(X4HCalendar.calendar_index);
            
            X4HCalendar.my_action_events = X4HCalendar.event_actions;
            if(X4HCalendar.calendar_index=="personal"){
                X4HCalendar.personal_calendar_action_events = X4HCalendar.event_actions;
            }
        }
        //check if calendar is loaded
        if(X4HCalendar.calendar_index=="widget"){
            if($('#ffoffice-calendar-widget').size()==0){
                X4HCalendar.widget.load_calendar();
            }else{
                X4HCalendar.check_calendar_events(params);
            }
            
        }else if(X4HCalendar.calendar_index=="personal"||X4HCalendar.calendar_index=="shared"){
            
            if($(X4HCalendar.containing_element).children().size()==0){
                X4HCalendar.load_calendar(X4HCalendar.calendar_index);
            }else{
                X4HCalendar.check_calendar_events(params);
                X4HCalendar.event_summary.load_events_summary(X4HCalendar.calendar_index);
                X4HCalendar.upcoming_events.load_upcoming_events();
            }
            
            
        }
        
        //during initial load, initialize scheduled events
        if(X4HCalendar.scheduled_event_hasLoaded==false){
            X4HCalendar.scheduled_event_hasLoaded = true;
            X4HCalendar.scheduled_events.init();
        }
    },
    
    
    get_events_by_category : function(selected_item){
        
        x4hubProxy.call(
            [X4HCalendar,'get_events_by_category_response'],
            '/ondemand/event/?method=EVENT_CATEGORY_SEARCH',
            {
               
               category : selected_item,
               rows: 1000
            }
        );
    },
    
    get_events_by_category_response : function(response){
        var event_id_array = [];
        
        if(response.data.rows.length>0){
            X4HCalendar.events_array = response.data.rows;
             
             if(X4HCalendar.calendar_index=='personal'||X4HCalendar.calendar_index=='widget'){
                 X4HCalendar.events_array_personal = X4HCalendar.events_array;
                
             }else{
                 X4HCalendar.events_array_shared = X4HCalendar.events_array;
             }
            
            $.each(X4HCalendar.events_array,function(key,val){
                event_id_array.push(val.event);
            });
            
            
            
        }else{
        /* if there are no relevant events, then force to 0 to prevent action from searching other events */
            event_id_array = [0];
            X4HCalendar.events_array = [];
            X4HCalendar.events_array_shared = [];
            
        }
        
        //check for accepted events first - personal calendar
        if(X4HCalendar.calendar_index=='personal'||X4HCalendar.calendar_index=='widget' || X4HCalendar.calendar_index=="schedule-widget"){
            
            X4HCalendar.get_my_attended_events({
                calendar_date : X4HCalendar.today,
                event_id_array : event_id_array
            });
        }else{
            var params = {
                event_id_array : event_id_array
            }
            /* 'Firstfolio Corporate' (29) - Public Shared Calendar */
            if(X4HCalendar.selected_event_category==29){
                params['isPublic']=true;
            }
            
            X4HCalendar.get_event_actions(X4HCalendar.today,params);
        }
        
        
        
    },
    
    get_contact_action_events :function(){
       
          var tmpevents = [];
          $.each(X4HCalendar.event_actions,function(akey,aval){
              //if(val.)
              $.each(X4HCalendar.events_array,function(skey,sval){
                  if(sval.event==aval.linkid){
                      tmpevents.push(aval);
                  }
              });
          });
          
         return tmpevents;
        
    },
    
    get_selected_calendar_events : function(response){
        if(response.data.rows.length>0){
            X4HCalendar.shared_calendar.calendar_events = response.data.rows;
            
        }
    },
    
    /*get_shared_events_response : function(response){
      //console.log(response)
      if(response.data.rows.length>0){
          //X4HCalendar.shared_calendar.shared_events = response.data.rows;
      }
      X4HCalendar.load_calendar("shared");  
    },*/
    
    //Calendar creator, extends fullCalendar plugin
    create_calendar : function(options){
        var calendar_id = options.id;
        var calendar_options = options.fullCalendar_options;
        var calendar_width = options.calendar_width;//hack to set width;
        var calendar_obj = $('<div id="'+calendar_id+'" style="width: '+calendar_width+'px;"></div>');
        return calendar_obj.fullCalendar(calendar_options);
    },
    
    load_calendar : function(calendar_index){
        $(this.containing_element).html('');
        
        var today = new Date();
        var currentMonth = today.getMonth();
        var currentYear = today.getFullYear();
        var range = (X4HCalendar.main_calendar_options.previous_month_start!=null)?X4HCalendar.main_calendar_options.previous_month_start:currentMonth;
        
        var callback;
        
        for(var i=range;i<range+X4HCalendar.main_calendar_options.month_range;i++){
            var calendar = X4HCalendar.create_calendar({
                id : 'ffoffice_calendar'+i+'_'+calendar_index,
                calendar_width : (i==currentMonth)?391:196,
                fullCalendar_options : {
                    month : i,
                       titleFormat : {
                           month : 'MMMM yyyy'
                       },
                       header : {
                           left : 'prev',
                           center : '',
                           right : 'next'

                       },
                       buttonText: {
                           prev: '&nbsp;&lt;&lt',
                           next: '&nbsp;&gt;&gt;'
                       },
                       viewDisplay: function(view) {
                         var calendar_object = this;
                         //reset calendar event marks
                           $(calendar_object).find('.mark-date1').removeClass('mark-date1');
                           
                           /* prevent user from clicking these buttons while it has not been loaded yet */
                           $(this).find('.fc-header-right .fc-button-next').addClass('fc-state-disabled');
                           $(this).find('.fc-header-left .fc-button-prev').addClass('fc-state-disabled');
                         
                           $(this).find('.fc-header-center').html(view.title);
                           var today = $(this).fullCalendar('getDate');
                           cYear = today.getFullYear();
                           cMonth = today.getMonth();
                           
                           var calendar_current_date = $.datepicker.formatDate('dd/mm/yy', today);
                           
                           //assuming events by category has been loaded
                           var event_id_array = [];
                           var accepted_event_array = [];

                           //switch between loaded events
                           X4HCalendar.events_array = X4HCalendar['events_array_'+calendar_index];

                           $.each(X4HCalendar.events_array,function(key,val){
                                event_id_array.push(val.event);
                           });
                           
                           if(event_id_array.length==0){
                               event_id_array = [0];
                           }

                           if(calendar_index=="personal"){

                               //assuming event attendee have been searched
                               //push to events to query
                               if(X4HCalendar.my_attended_events!==null){
                                $.each(X4HCalendar.my_attended_events,function(key,val){
                                    //params.event_id_array.push(val.event);
                                    accepted_event_array.push(val.event);
                                });
                               }
                                X4HCalendar.personal_cal_accepted_event_array = accepted_event_array;
                           }
                           
                           if(!(X4HCalendar.today==calendar_current_date)){
                               
                               
                               
                               X4HCalendar.get_event_actions(calendar_current_date,{
                                   
                                  calendar_object : calendar_object,
                                  cYear : cYear,
                                  cMonth : cMonth,
                                  calendar_index : calendar_index,
                                  event_id_array : event_id_array,
                                  accepted_event_array : accepted_event_array
                               
                               });
                               
                               //remove old data;
                                $('#calendar-summary-events-list table').html('');
                                $('#calendar-upcoming-events-list').html('');
                                //show preloader
                                $('#calendar-summary-preloader').show();
                                //upcoming preloader
                                var upcoming_preloader = $('<div id="calendar-upcoming-preloader">'
                                +'          <span>Loading Events <img src="/assets/images/preloader2.gif" /></span>'
                                +'      </div>');
                                $('#calendar-upcoming-events-list').html(upcoming_preloader);
                                
                           }else{
                               
                               X4HCalendar.check_calendar_events({
                                  calendar_object : calendar_object,
                                  cYear : cYear,
                                  cMonth : cMonth,
                                  calendar_index : calendar_index
                               });
                           }
                           
                           /* Hide the popup every time the calendar view changes */
                           $('#calendar-items').dialog('close');
                       },
                       events: function(start, end, callback) {
                            X4HCalendar.calendar_index=calendar_index;
                            
                       },
                       /*editable: false,*/
                       dayClick : function(date,allDay, jsEvent, view){
                        if(view.element.parent().parent().hasClass("ffcalendar-current")){
                            X4HCalendar.show_calendar_items(date, jsEvent,calendar_index);
                        }
                        
                       }
                    
                }
                
            });
           if(i==currentMonth){
               calendar.addClass('ffcalendar-current');
           }else{
               calendar.addClass('ffcalendar');
           }

           // fullCalendar Tweaks
           var removeThis = calendar.find('.fc-widget-header');
           var removeThisParent = removeThis.parent().parent().remove();
           $(X4HCalendar.containing_element).append(calendar);
           
           /*calendar.find('.fc-button-content').click(function(){
               console.log('event trigger')
               calendar.find('.mark-date1').removeClass('mark-date1');
           })*/
           
           //load event summary panel
           X4HCalendar.event_summary.init(calendar_index); 
           
           //load upcoming events
           X4HCalendar.upcoming_events.init();
           
           /* enable search */
           X4HCalendar.search_my_events.init();
           
           
        }
        
        $(this.containing_element).parent().find('.preloader-calendar').hide();
        if(calendar_index=="shared"){
            /* display only if there are events to share */
            
            if(X4HCalendar.event_actions){
                var btn_share_calendar = $(
                    '<div class="shared-calendar-footer"><button id="share-calendar">Share Calendar Events</button></div>'
                );

                var btn_cancel_sharing_calendar = $(
                    '<button id="cancel-sharing-calendar">Cancel Shared Events</button>'
                );


                /* this should be removed for public calendar (Firstfolio Corporate) */
                if(X4HCalendar.selected_event_category!=29){
                    
                    //Disabling for now will resolving issue
                    
                    //$(X4HCalendar.containing_element).append(btn_share_calendar);

                    //$('.shared-calendar-footer').append(btn_cancel_sharing_calendar);

                    $('#share-calendar').button()   
                    .unbind('click').click(function(){
                        myappmaster.calendar.event_invitation.share();
                    });
                       
                    

                    //cancel shared events
                    $('#cancel-sharing-calendar').button()
                    .unbind('click').click(function(){
                        myappmaster.calendar.event_invitation.unshare();
                    });
                        
                    
                }
            }
            
        }
    },
    
    check_calendar_events : function(params){
        
        var calendar_object = params.calendar_object;
        var cYear = params.cYear;
        var cMonth = params.cMonth;
        var calendar_index = params.calendar_index;
        
        
        $(calendar_object).find('.fc-day-number').each(function(dkey,val){
           
           lDay = parseInt($(this).text());
           if($(this).parents('td').hasClass('fc-other-month'))
            {
                lYear = parseInt(cYear);
                
                //belongs to the previous month
                if(lDay>15)
                {
                    lMonth = parseInt(cMonth) - 1;
                    lDate = new Date(lYear,lMonth,lDay);

                }
                else //belongs to the next month
                {
                    lMonth = parseInt(cMonth) + 1;
                    lDate = new Date(lYear,lMonth,lDay);

                }
            }
            else
            {
                lYear = parseInt(cYear);
                lMonth = parseInt(cMonth);
                lDate = new Date(lYear,lMonth,lDay);

            }
            
            
            var current_calendar_month = $(calendar_object).fullCalendar('getDate').getMonth();
            //only the current date must display events
            if(X4HCalendar.event_actions.length>0 && cMonth==current_calendar_month)
            X4HCalendar.hasEvent(lDate,calendar_index,val);
        });
    },
    
    hasEvent : function(lDate,calendar_index,val){
        
        if(calendar_index=="personal"||calendar_index=="widget"){
            
            if(X4HCalendar.my_action_events!==null){
               $(X4HCalendar.my_action_events).each(function(key,row){
                   //if(row.status==3){
                       //console.log(new Date($.datepicker.parseDate('dd-M-yy',row.eventstartdate)))
                       
                       var duedate = new Date($.datepicker.parseDate('dd-M-yy',(row.duedate).replace(/\s/g,'-')));
                       
                       if(lDate.toString()==duedate.toString()){
                           
                           $(val).parent().parent().addClass('mark-date1');
                       }
                   //}
               });
            }
        }else if(calendar_index=="shared"){
            if(X4HCalendar.shared_calendar.shared_events.length>0){
                $(X4HCalendar.shared_calendar.shared_events).each(function(key,row){
                    if(row.linktype==39&&row.linkid!=''){
                        
                        var duedate = new Date($.datepicker.parseDate('dd-M-yy',(row.duedate).replace(/\s/g,'-')));
                        if(lDate.toString()==duedate.toString()){
                            $(val).parent().parent().addClass('mark-date1');
                        }
                    }
                });
            }
        }
    },
    
    show_calendar_items : function(date, jsEvent,calendar_index){
        X4HCalendar.selected_date = date;
        
        $('#popup-calendar-main').hide();
        
        $('#preloader-calendar-popup').show();
        
        $('#calendar-items').find('#popup-event-list').find('ul').html('');
        
        $('#events-container').find('#popup-accepted-event-list').remove();
        
        $('#events-container').find('#accepted-events-header').remove();
        
        var popup =  $('#calendar-items');
        var calendarMain = $('.ffcalendar-current');
        
        var scrollTop = $(window).scrollTop();
        var scrollLeft = $(window).scrollLeft();
        var elemX = jsEvent.pageX-scrollLeft;
        var elemY = jsEvent.pageY-scrollTop;
        
        
        $( '#calendar-items' ).dialog({
                resizable: false,
                /*height: 200,*/
                width: 300,
                stack: false,
                position : [elemX,elemY],
                dialogClass : 'calendar-popup',
                draggable : false      
        });
        $('#calendar-items').dialog('option','title',$.datepicker.formatDate('dd/mm/yy', date));
        
        if(calendar_index=='personal'){
            var dayHasEvents = false;
            var dayHasAcceptedEvents = false;
            
            $('#popup-calendar-main #created-events-header').text('Created Events');
            //For accepted events
            
            $('#events-container').append('<h1 id="accepted-events-header">Accepted Events</h1>');
            
            $('#events-container').append('<div id="popup-accepted-event-list" class="popup-event-list-container"> <ul></ul></div>');
            
            
            
            if(X4HCalendar.personal_calendar_action_events!==null){
                var appended_events_personal = [];
                var appended_events_accepted = [];
                $.each(this.personal_calendar_action_events,function(mekey,meval){
                        
                    
                        var eventdate = new Date($.datepicker.parseDate('dd-M-yy',(meval.duedate).replace(/\s/g,'-')));

                        if(eventdate.toString()==date.toString()){
                            

                            var event_row  = $(
                            '<li class="event"><a href="#" class="popup-event" id="popup-event-'+meval.linkid+'">'+meval.actionreference+'</a></li>'
                            );
                            if($.inArray(meval.linkid,X4HCalendar.personal_cal_accepted_event_array)==-1){ 
                                dayHasEvents = true;
                                $('#calendar-items').find('#popup-event-list').find('ul').append(event_row);
                            }else{
                                dayHasAcceptedEvents = true;
                                
                                if($.inArray(meval.linkid,appended_events_accepted)==-1){
                                    $('#calendar-items').find('#popup-accepted-event-list').find('ul').append(event_row);
                                    appended_events_accepted.push(meval.linkid);
                                }
                                
                            }
                        }
                    
                });

                
           }
           
           
           if(!dayHasEvents){
               $('#calendar-items').find('#popup-event-list').find('ul').html('<li>There are no events for this day.</li>');
           }
           
           
           
           if(!dayHasAcceptedEvents){
               $('#events-container').append(
               '<div id="popup-accepted-event-list" class="popup-event-list-container"><ul><li style="padding-bottom:10px;">There are no items to display.</li></ul></div>');
               
           }
        }else if(calendar_index=='shared'){
            
            dayHasEvents = false;
            $('#popup-calendar-main #created-events-header').text('Shared Events');
            
            if(X4HCalendar.shared_calendar.shared_events.length>0){
                $.each(X4HCalendar.shared_calendar.shared_events,function(mekey,meval){
                    var eventdate = new Date($.datepicker.parseDate('dd-M-yy',(meval.duedate).replace(/\s/g,'-')));
                    
                    if(eventdate.toString()==date.toString()){
                        //invited_events.push(meval);
                        dayHasEvents = true;
                        var event_row  = $(
                        '<li class="event"><a href="#" class="popup-event" id="popup-event-'+meval.linkid+'">'+meval.actionreference+'</a></li>'
                        );
                        $('#calendar-items').find('#popup-event-list').find('ul').append(event_row);
                    }
                });
            }
            
            if(!dayHasEvents){
                $('#calendar-items').find('#popup-event-list').find('ul').html('<li>There are no events for this day.</li>');
            }
        }
        
        //Add event button
        var create_btn = $('<a class="create-event" href="#">Create Event</a>');
        $('#popup-event-footer').html(create_btn);
        
        $('.create-event').click(function(){
            X4HCalendar.selected_date = date;
            /* modal */
            //X4HCalendar.show_event_modal('add',null,calendar_index);
            
            /* tab */
            $('#calendar-items').dialog('close');
            myappmaster.calendar.calendar_event.create(calendar_index);
            
        });
        
        //bind click on items
           $.each($('.popup-event'),function(counter, elem){
               $(elem).click(function(){
                   $('#calendar-nav').find('.eventDetails').parent().show();
                   $('#calendar-items').dialog('close');
                   $('#eventDetails').find('.event-details-row').hide();
                   $('#cancel-invite').hide();
                   $('#back-to-calendar').hide();
                   $('#preloader-event-details').show();
                   $('.event-attendees').hide();
                   $('#event-attendees-footer').hide();
                   $('#calendar-nav').find('.eventDetails').trigger('click');
                   var event_id = myappmaster.find_id($(elem).attr('id'));

                   var callType = ($(this).hasClass('hosted-event')==true)?'event-add-details':'event-details';

                   //search event by id
                   X4HCalendar.search_event(event_id, 'show_event_details',{calendar_index:calendar_index});


               });
           });
        
       
        
       $('#calendar-items').show();
       $('#popup-calendar-main').show();
       $('#preloader-calendar-popup').hide();
    },
    
    search_event : function(id,callback,params){
        var oXML = new X4HASearch()
        .addField('Reference')
        .addField('HostContPerson')
        .addField('HostContactPersonText')
        .addField('StartDate')
        .addField('EndDate')
        .addField('Status')
        .addField('StatusText')
        .addField('Description')
        .addField('Public')
        /*.addField('streetaddress2')
        .addField('streetsuburb')
        .addField('streetstate')
        .addField('streetcountry')
        .addField('streetpostcode')*/
        .addFilter('id', 'EQUAL_TO', id)
        .getXML();
        
        var callbackobj = X4HCalendar;
        
        if(params.callbackobj!==undefined){
            callbackobj = params.callbackobj
        }
        
        x4hubProxy.call(
            [callbackobj, callback,params],
            '/ondemand/event/?method=EVENT_SEARCH',
            {
                advanced: 1,
                data: oXML
            }
        );
        
    },
    
    show_event_details : function(response,params){
        //console.log(response);
        $('#edit-event').remove();
        $('#delete-event').remove();
        //$('.event-attendees').hide();
        
        if(response.data.rows.length>0){
            var thisevent = response.data.rows[0];
            
            X4HCalendar.selected_event = thisevent;
            
            $.each(thisevent, function(k, v) {
                thisevent[k] = myappmaster.html_decode(v);
            });
            
            //var event_startdate = new Date(thisevent.startdate.replace(/\s\d\d:\d\d:\d\d/g, ''));
            var event_startdate = new Date(thisevent.startdate);
            
            if(thisevent.enddate!==''){
                //var event_enddate = new Date(thisevent.enddate.replace(/\s\d\d:\d\d:\d\d/g, ''));
                var event_enddate = new Date(thisevent.enddate);
                //get time
                var event_endtime = this.get_time_from_date(event_enddate);
                
                $('#event-details-enddate').html($.datepicker.formatDate('dd/mm/yy', event_enddate)+' '+event_endtime);
            }else{
                $('#event-details-enddate').html('');
            }
            
            $('#event-details-reference').html(thisevent.reference);
            $('#event-details-host').html(thisevent.hostcontactpersontext);
            
            //get time
            var event_starttime = this.get_time_from_date(event_startdate);
            
            $('#event-details-startdate').html($.datepicker.formatDate('dd/mm/yy', event_startdate)+' '+event_starttime);
            
            //all day
            if(event_starttime == event_endtime){
                $('#event-details-startdate').html($.datepicker.formatDate('dd/mm/yy', event_startdate));
                $('#event-details-enddate').html($.datepicker.formatDate('dd/mm/yy', event_enddate));
                if($('#event-details-all-day').size()==0){
                    $('#event-details-enddate').parent().append('<span id="event-details-all-day"><em>* All day</em></span>');
                }
            }else{
                $('#event-details-all-day').remove();
            }
            
            $('#event-details-status').html(thisevent.statustext);
            //$('#event-details-attendee-status').html();
            $('#event-details-description').html(thisevent.description);
            
            
            /*$('#preloader-event-details').hide();
            
            $('#eventDetails').find('.event-details-row').show();*/
            
            
               $('#event-attendees-list').find('.event-attendees-row').remove();
               
               X4HCalendar.search_event_attendee(thisevent.id, 'get_attendee_details', {});
               
               if(thisevent.hostcontperson==X4HUser.contact_person){
                    
                    var edit_event = $(
                        '<button id="edit-event">Edit Event</button>'
                    );
                    var delete_event = $(
                        '<button id="delete-event">Delete Event</button>'
                    );
                    $('#event-attendees-footer').append(edit_event);
                    $('#event-attendees-footer').append(delete_event);
                    
                    $('#edit-event').button()
                    .unbind('click').click(function(){
                    
                              /* tab */
                              $('#calendar-items').dialog('close');
                              myappmaster.calendar.calendar_event.edit(thisevent,params.calendar_index);
                           
                    });
                    
                    
                    $('#delete-event ').button()
                    .unbind('click').click(function(){
                      
                      var delete_event = confirm("Are you sure you want to delete this Event? Attendess will be deleted as well.");
                      if(delete_event==true){
                          $('.event-details-row').hide();
                          $('.event-attendees').hide();
                          $('#event-attendees-footer button').hide();
                          $('#preloader-event-details').show();
                          X4HCalendar.delete_event_action(thisevent);
                      }
                   });
                       
                    
                    
                    
               }else{
                   $('#cancel-invite').button()
                   .unbind('click').click(function(){
                      var invite_id;
                        
                        $.each(X4HCalendar.event_attendees,function(key,attendees){
                            if(attendees.event==thisevent.id){
                                invite_id=attendees.id;
                                return false;
                                console.log(attendees.id)
                            }
                            
                        });
                        
                        myappmaster.calendar.event_invitation.respond(thisevent.id,'decline-only',invite_id); 
                   });
                   /*{
                   
                   create : function(event){
                        $('#cancel-invite').click(function(){
                            
                        
                        });
                   }
                   });*/
                   
                   //$('#cancel-invite').show();
               }
           /*}*/
          
           
           $('#back-to-calendar').button()    
           .unbind('click').click(function(){
            $(X4HCalendar.selected_calendar).trigger('click');
           });
               
           
           
            
            $('#event-attendees-footer').hide();
            
        }else{
            alert('There was a problem loading the event');
            $('#calendar-nav').tabs('select',X4HCalendar.tab_index);
            
        }
        
        /* Enable widget controls */
        $('#ffoffice-calendar-widget').find('.fc-header-right .fc-button-next').removeClass('fc-state-disabled');
        $('#ffoffice-calendar-widget').find('.fc-header-left .fc-button-prev').removeClass('fc-state-disabled');
    },
    
    show_cancel_invite : function(thisevent){
        //console.log(thisevent);
        $('#cancel-invite-host').text(thisevent.hostcontactpersontext);
        $('#cancel-invite-subject').text(X4HUser.first_name+" "+X4HUser.last_name+" "+"cancelled the invitation to"+" "+thisevent.reference);
        $( '#calendar-cancel-invite' ).dialog({
                title: "Events",
                resizable: true,
                height: 600,
                width: 700,
                modal: true,
                buttons: {
                    'Cancel Invitation' : function(){
                        //X4HCalendar.cancel_invite(thisevent.hostcontperson);
                        X4HCalendar.search_contact(thisevent.hostcontperson,'cancel_invite',{eventid : thisevent.id});
                    },
                    'Back to Details' : function(){
                        $('#cancel-invite-host').html('');
                        $('#cancel-invite-subject').html('');
                        
                        $( this ).dialog( "close" );
                    } 
                } 
        });
        $( "#calendar-cancel-invite .tabs" ).tabs();
        $("#cancel-invite-reason").text('');
        tinyMCE.execCommand('mceAddControl', true, 'cancel-invite-reason');
        var tmp_instance = tinyMCE.get('cancel-invite-reason');
        if(tmp_instance != undefined) {
            tmp_instance.setContent('');
        }
    },
    
    cancel_invite : function(response,params){
        var contact = response.data.rows[0];
        var tmp_instance = tinyMCE.get('cancel-invite-reason');
        if(tmp_instance != undefined) {
            var reason = tinyMCE.get('cancel-invite-reason').getContent();
        }
        if(reason!==''){
            var host_email = contact['email'];
          
            var decline_subject = $('#cancel-invite-subject').text();
            
            //get attendee id
            var eventid = params.eventid;
            var event_attendee_id = null;
            $.each(X4HCalendar.my_events,function(key,val){
                if(val.event==eventid){
                    event_attendee_id = val.id;
                }
            });
            
            //console.log(contact);
            x4hubProxy.call(
            [X4HCalendar, 'send_decline_invite_email_response',event_attendee_id], 
            '/ondemand/messaging/?method=MESSAGING_EMAIL_SEND',
                {
                    subject : decline_subject,
                    to : host_email,
                    message : reason
                }
            );
        }else{
           alert('You need to add a reason to decline this invite.');
        }
        
    },
    
    cancel_event_invite : function(invite_id){
        x4hubProxy.call(
            [X4HCalendar, 'cancel_event_invite_response'], 
            '/ondemand/event/?method=EVENT_ATTENDEE_MANAGE',
            {
                id : invite_id,
                status : 4
            }
        );
        
        
    },
    
    cancel_event_invite_response : function(response){
        if(response.notes=='UPDATED'){
            
            $('#calendar-nav').tabs('remove','#eventInvitation');
        }else{
            myappmaster.add_message('Unable to decline invite.', 5);
            
            X4HCalendar.scheduled_events.refresh_schedule_list();
           
            X4HCalendar.list_new_events(20);
        }
    },
    
    send_decline_invite_email_response : function(response,invite_id){
        
        if(response.notes=="SENT"){
			myappmaster.add_message('You have cancelled your invite for this event.', 5);
            //alert('You have cancelled your invite for this event');
            X4HCalendar.cancel_event_invite(invite_id);
            
        }else{
            myappmaster.add_message('Unable to decline invite.', 5);
            
            X4HCalendar.scheduled_events.refresh_schedule_list();
           
            X4HCalendar.list_new_events(20);
        }
    },
    
    search_contact : function(id,callback,params){
        var oXML = new X4HASearch()
            .addField('firstname')
            .addField('surname')
            .addField('email')
            .addField('homephone')
            .addField('workphone')
            .addField('mobile')
            .addField('streetaddress1')
            .addField('streetaddress2')
            .addField('streetsuburb')
            .addField('streetstate')
            .addField('streetcountry')
            .addField('streetpostcode')
            .addFilter('id', 'EQUAL_TO', id)
            .getXML();
            
        x4hubProxy.call(
                [X4HCalendar, callback,params],
                '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
                {
                    advanced: 1,
                    data: oXML
                }
            );    
    },
    list_new_events : function(rows){
        //console.log(rows)
        $('#calendar-event-main-list').html('');
        
        x4hubProxy.call(
            [X4HCalendar, 'list_new_events_response', 'calendar-event-main-list'], 
            '/ondemand/event/?method=EVENT_ATTENDEE_SEARCH',
            {
                rows: rows,
                me : 1
            }
        );
    },
    
    list_new_events_response : function(response,container){
       var numrows = 0;
       if(response.data.rows.length > 0) {
          var rowHeader = $('<div id="calendar-event-row" class="calendar-event-row-header">'
                                            +'<div class="calendar-event-subject">Reference</div>'
                                            +'<div class="calendar-event-subject">Start Date</div>'
                                            +'<div class="calendar-event-subject">End Date</div>'
                                            +'<div class="calendar-event-option">Options</div>'
                                        +'</div>');
          $('#' + container).append(rowHeader);
          
          $.each(response.data.rows, function(key, row) {
              if(row.status==2){
                  numrows+=1;
                  var rowElement = $(
                    '<div id="calendar-event-' + row.id + '" class="calendar-event-row event-item">'
                        + '<div class="calendar-event-row-item"><span class="calendar-event-details" id="calendar-event-details'+key+'-' + row.event + '">' + row.eventreference + '</span></div>'
                        + '<div class="calendar-event-row-item"><span class="calendar-event-details" id="calendar-event-details'+key+'-' + row.event + '">' + row.eventstartdate + '</span></div>'
                        + '<div class="calendar-event-row-item"><span class="calendar-event-details" id="calendar-event-details'+key+'-' + row.event + '">' + row.eventenddate + '</span></div>'
                        + '<div class="calendar-event-option"><span id="calendar-event-accept-' + row.id + '" class="calendar-event-accept-anchor">Accept Invitation</span>&nbsp;/&nbsp;<span id="calendar-event-decline-' + row.event + '" class="calendar-event-decline-anchor">Decline Invitation</span></div>'    
                    +'</div>'
                );
                $('#' + container).append(rowElement);
              }
          });
          
          //bind element triggers
          $.each($('.calendar-event-details'),function(counter, elem){
            $(elem).click(function(){
                var event_id = myappmaster.find_id($(elem).attr('id'));
                var invite_id = myappmaster.find_id($(elem).parent().parent().attr('id'));
                //X4HCalendar.search_event(event_id, 'invite_respond', {modalType: 'accept'});
                myappmaster.calendar.event_invitation.respond(event_id,'accept',invite_id);
            })
          });
          
          $.each($('.calendar-event-accept-anchor'),function(counter, elem){
            $(elem).click(function(){
                $('#calendar-event-main-list').html('');
                $('#preloader-calendar-event').show();
                var invite_id = myappmaster.find_id($(elem).attr('id'));
                X4HCalendar.accept_event_invite(invite_id);
            });
          });
          
          $.each($('.calendar-event-decline-anchor'),function(counter, elem){
            $(elem).unbind('click').click(function(){
                var event_id = myappmaster.find_id($(elem).attr('id'));
                var invite_id = myappmaster.find_id($(elem).parent().parent().attr('id'));
                //X4HCalendar.search_event(event_id, 'invite_respond', {modalType: 'decline'});
                myappmaster.calendar.event_invitation.respond(event_id,'decline',invite_id);
            });
          });
         
         
       }
       
       if(numrows==0){
           var row = $('<div class="calendar-event-row-nohover">There are no new Events to display.</div>');
            $('#' + container).html(row);
       }
       $('#preloader-calendar-event').hide();
    },
    
    invite_respond : function(response, params){
        
        if(response.data.rows.length == 1){
            tinyMCE.execCommand('mceAddControl', true, 'decline-event-reason');
            
            var thisevent = response.data.rows[0];
            
            // Replace HTML entities
            $.each(thisevent, function(k, v) {
                thisevent[k] = myappmaster.html_decode(v);
            });
            
            //get attendee id
            var eventid = thisevent.id;
            var event_attendee_id = null;
            
            //console.log(X4HCalendar.my_attended_events)
            
            $.each(X4HCalendar.my_attended_events,function(key,val){
                if(val.event==eventid){
                    event_attendee_id = val.id;
                }
            });
            var event_startdate = new Date(thisevent.startdate.replace(/\s\d\d:\d\d:\d\d/g, ''));
            var event_enddate = new Date(thisevent.enddate.replace(/\s\d\d:\d\d:\d\d/g, ''));
            
            $('#static-event-reference').html(thisevent.reference);
            $('#decline-event-subject').html(X4HUser.first_name+" "+X4HUser.last_name+' has declined your invite to '+thisevent.reference);
            
            //valiDate
            if(myappmaster.validate_date(event_startdate)) {
                $('#static-event-startdate').html($.datepicker.formatDate('dd/mm/yy', event_startdate));
                
            }
            
            if(myappmaster.validate_date(event_enddate)) {
                $('#static-event-enddate').html($.datepicker.formatDate('dd/mm/yy', event_enddate));
            }
            
            $('#static-event-host').html(thisevent.hostcontactpersontext);
            
            $('#decline-event-host').html(thisevent.hostcontactpersontext);
            
            $('#static-event-description').html(thisevent.description);
            
            
            
            $( '#calendar-event-manage' ).dialog({
                ttitle: "Events",
                resizable: true,
                height: 600,
                width: 700,
                modal: true
                //buttons: 
            });
            
            
            var set_buttons = function(modalType){
                if(modalType=='accept'){
                    $( '#calendar-event-manage' ).dialog(
                                "option", "buttons",{
                                    'Accept Invite' : function(){
                                        X4HCalendar.accept_event_invite(event_attendee_id);
                                        //$( this ).dialog( "close" );  
                                    },  
                                    'Cancel'  : function(){
                                        $( this ).dialog( "close" );
                                    }
                                 }
                    );
                }else if(modalType=='decline'){
                    $( '#calendar-event-manage' ).dialog(
                                "option", "buttons",{
                                    'Decline' : function(){
                                        X4HCalendar.search_contact(thisevent.hostcontperson,'decline_invite',{attendee_id : event_attendee_id});
                                        //X4HCalendar.decline_event_invite(thisevent)
                                        //$( this ).dialog( "close" );
                                    },  
                                    'Cancel'  : function(){
                                        $( this ).dialog( "close" );
                                    }
                                 }
                    );
                }
            }
            
            set_buttons(params.modalType);
            
            $( "#calendar-event-manage .tabs" ).tabs({
                select : function(event,ui){
                    if(ui.index==0){//details/accept
                        set_buttons('accept');
                    }else if(ui.index==1){//respond-decline
                        set_buttons('decline');
                    }
                }
            });
            
            if(params.modalType=='decline'){
                $( "#calendar-event-manage .tabs" ).tabs('select',1);
            }
            
        }else{
            alert('Error fetching event.')
        }
        
    }, 
    
    accept_event_invite : function(id){
        x4hubProxy.call(
            [X4HCalendar, 'accept_event_invite_response'], 
            '/ondemand/event/?method=EVENT_ATTENDEE_MANAGE',
            {
                id : id,
                status : 3 //Invite accepted
            }
        );
    },
    accept_event_invite_response : function(response){
        if(response.notes=='UPDATED'){
			myappmaster.add_message('Invitation accepted.', 5);
            
           X4HCalendar.scheduled_events.refresh_schedule_list();
           
            X4HCalendar.list_new_events(20); 
           $('#calendar-nav').tabs('select', '#calendarEvents');
            
        }else{
			myappmaster.add_message('Unable to accept invite.', 5);
            
            X4HCalendar.scheduled_events.refresh_schedule_list();
           
            X4HCalendar.list_new_events(20);
        }
    },
    
    decline_invite : function(response,params){
        var contact = response.data.rows[0];
        var tmp_instance = tinyMCE.get('decline-event-reason');
        if(tmp_instance != undefined) {
            var reason = tinyMCE.get('decline-event-reason').getContent();
        }
        if(reason!==''){
            //console.log(contact)
            var host_email = contact['email'];
            var decline_subject = $('#decline-event-subject').text();
            x4hubProxy.call(
            [X4HCalendar, 'send_decline_email_response',params.attendee_id], 
            '/ondemand/messaging/?method=MESSAGING_EMAIL_SEND',
            {
                subject : decline_subject,
                to : host_email,
                message : reason
            }
            );
            
        }else{
            alert('You need to add a reason to cancel this invite.');
        }
    },
    send_decline_email_response : function(response,attendee_id){
        //console.log(response);
        if(response.notes=="SENT"){
			myappmaster.add_message('Decline email sent.', 5);
            X4HCalendar.decline_event_invite(attendee_id)
        }else{
			myappmaster.add_message('Error sending decline email.', 5);
            //alert('Error declining invite.');
        }
        
        
    },
    decline_event_invite : function(attendee_id){
        console.log(attendee_id)
        x4hubProxy.call(
            [X4HCalendar, 'decline_event_invite_response'], 
            '/ondemand/event/?method=EVENT_ATTENDEE_MANAGE',
            {
                id : attendee_id,
                status : 4 //Invite declined
            }
        );
        
        
    },
    
    decline_event_invite_response : function(response){
        if(response.notes=='UPDATED'){
            myappmaster.add_message('Invite has been declined.', 5);
            $('#calendar-nav').tabs('select', '#calendarEvents');
        }else{
			myappmaster.add_message('Error declining event.', 5);
            //alert('Error declining event');
        }
        
        $('#calendar-event-manage').show();
        $('#invite-attendee #preloader-event-invite').remove();
    },
    
    show_event_modal : function(action,thisevent,calendar_index){
        var selected_date = X4HCalendar.selected_date;
        tinyMCE.execCommand('mceAddControl', true, 'add-event-description');
       
        var dialog_title;
        
        if(action=='edit'){
            //console.log(tinyMCE.get('add-event-description'))
            dialog_title = 'Edit Event';
            $("#add-event-reference").val(thisevent.reference);
            
            $("#add-event-startdate").val(thisevent.startdate);
            $("#add-event-enddate").val(thisevent.enddate);
            
            $('input[name=add-event-status][value='+thisevent.status+']').attr('checked', true);
            $('input[name=add-event-sharing][value='+thisevent['public']+']').attr('checked', true);
            
            $('#add-event-description').text(thisevent.description);
            var tmp_instance = tinyMCE.get('add-event-description');
            if(tmp_instance != undefined) {
                tmp_instance.setContent(thisevent.description);
            }
            
            $("#add-event-startdate").datetimepicker({dateFormat: 'dd M yy',ampm:true});
            $("#add-event-startdate").datetimepicker('setDate',new Date(thisevent.startdate))
        
            $("#add-event-enddate").datetimepicker({dateFormat: 'dd M yy',ampm:true});
            $("#add-event-enddate").datetimepicker('setDate',new Date(thisevent.enddate))
        
            
        }else if(action=='add'){
            //reset
            dialog_title = 'Add Event';
            $("#add-event-reference").val('');
            $("#add-event-startdate").val('');
            $("#add-event-enddate").val('');
            $('input[name=add-event-status][value=1]').attr('checked', true);
            $('input[name=add-event-sharing][value=Y]').attr('checked', true);
        
            tmp_instance = tinyMCE.get('add-event-description');
            if(tmp_instance != undefined) {
                tmp_instance.setContent('');
            }
            $("#add-event-startdate").datetimepicker({dateFormat: 'dd M yy',ampm:true});
            $("#add-event-startdate").val($.datepicker.formatDate('dd M yy', selected_date));
            $("#add-event-enddate").datetimepicker({dateFormat: 'dd M yy',ampm:true});
            $("#add-event-enddate").val($.datepicker.formatDate('dd M yy', selected_date));
            
        }
        
        $("#add-event").dialog({
            title: dialog_title,
                resizable: true,
                height: 600,
                width: 700,
                modal: true,
                buttons: {
                    'Save Event' : function(){
                        $('.preloader-modal').dialog('open');
                        if(action=='add'){
                            
                            $('.preloader-modal').dialog({title: 'Add Event'});
                            X4HCalendar.save_event({calendar_index:calendar_index});
                        }else if(action=='edit'){
                            $('.preloader-modal').dialog({title: 'Edit Event'});
                            X4HCalendar.save_event({id:thisevent.id,calendar_index:calendar_index});
                        }
                    },
                    'Cancel' : function(){
                        $( this ).dialog( "close" );
                    } 
                } 
        });
        
        $( "#add-event .tabs" ).tabs();
        
    },
    
    calendar_event : {
        selected_date : null,
        header : $(
            '<div id="tab-event-create-header" class="">'
            +'<h1>Event Details</h1>'
            +'</div>'
        ),
            
        buttons : $(
            '<button id="calendar-event-save">Save Event</button>'
            +'<button id="calendar-event-cancel">Cancel</button>'
        ),    
        content :
            '<div class="tabbed-content-body" id="calendar-event-details-content">'
            +'<div id="add-event">'
            +'<div class="tabs">'
            +'<ul>'                    
            +'    <li><a href="#addeventDetails">Details</a></li>'
            +'    <li><a href="#addeventDescription">Description</a></li>'
            +'</ul>'
        
            +'<div id="add-calendar-event-panel">'
            
            +'  <div id="addeventDetails" class="tabbed-section">'
            +'  <div class="event-form-row">'
            +'    <label for="add-event-reference"><strong>Event Reference:</strong></label>'
            +'    <input type="text" id="add-event-reference" />'
            +'  </div>'
        
            +'  <div class="event-form-row">'
            +'    <label for="add-event-startdate"><strong>Event Start Date:</strong></label>'
            +'    <input type="text" id="add-event-startdate" class="datepicker" />'
            +'  </div>'
            
            +'  <div class="event-form-row">'
            +'    <label for="add-event-enddate"><strong>Event End Date:</strong></label>'
            +'    <input type="text" id="add-event-enddate" class="datepicker" />'
            +'  </div>'
            
            +'<div class="event-form-row">All day <input type="checkbox" id="event-all-day-toogle"/></div>'
        
            
            +'  <div class="event-form-row">'
            +'  <div class="event-form-column">'
            +'  <p><strong>Status</strong></p>'
            +'  <p><input type="radio" id="add-event-status-planning" name="add-event-status" value="1"/>Planning</p>'
            +'  <p><input type="radio" id="add-event-status-inprogress" name="add-event-status" value="2"/>In Progress</p>'
            +'  <p><input type="radio" id="add-event-status-completed" name="add-event-status" value="3"/>Completed</p>'
            +'  <p><input type="radio" id="add-event-status-cancelled" name="add-event-status" value="4"/>Cancelled</p>'
            +'  <p><input type="radio" id="add-event-status-confirmed" name="add-event-status" value="5"/>Confirmed</p>'
            +'  </div>'
            +'  <div class="event-form-column">'
            +'  <p><strong>Sharing</strong></p>'
            +'  <p><input type="radio" id="add-event-sharing-public" name="add-event-sharing" value="Y"/>Public</p>'
            +'  <p><input type="radio" id="add-event-sharing-private" name="add-event-sharing" value="N"/>Private</p>'
            +'  </div>'
            +'  </div>'
            +'  </div>'
        
            +'<div id="addeventDescription" class="tabbed-section">'
            +'    <div style="clear: both;">&nbsp;</div>'
            +'    <textarea id="add-event-description"></textarea>'
            +'</div>'
        
            +'</div>'
            +'</div>'
            +'</div>'
            +'</div>'
        ,
        create_tab : function(title){
            
            if($( "#calendar-nav").find('a[href=#calendarEvent]').length==0){
                
                $('#calendar-nav').tabs("add","#calendarEvent",title);
            
                var calendar_event_panel = $('#calendar-nav').find("#calendarEvent");

                calendar_event_panel.addClass("tabbed-section");

                $('#calendar-panel').append(calendar_event_panel);
                
                $('#calendar-nav').tabs('select', "#calendarEvent");
                
                calendar_event_panel.append(this.header);
                
                calendar_event_panel.append(this.content);
                
                $( "#add-event .tabs" ).tabs();
                
                $('#calendar-event-details-content').append(this.buttons);
                
                
                $('#event-all-day-toogle').change(function(){
                    if($(this).prop('checked')){
                        $("#add-event-startdate").val($.datepicker.formatDate('dd M yy', new Date($("#add-event-startdate").val())));

                        $("#add-event-enddate").val($.datepicker.formatDate('dd M yy', new Date($("#add-event-enddate").val())));
                    }
                });

                $('#add-event-startdate').change(function(){
                    if($('#event-all-day-toogle').prop('checked')){
                        $(this).val($.datepicker.formatDate('dd M yy', new Date($(this).val())));
                    }
                });

                $('#add-event-enddate').change(function(){
                    if($('#event-all-day-toogle').prop('checked')){
                        $(this).val($.datepicker.formatDate('dd M yy', new Date($(this).val())));
                    }
                });
                
                
                $('#calendar-event-cancel').button({
                    create : function(){
                        $(this).click(function(){
                            //$(X4HCalendar.selected_calendar).trigger('click');
                            var tab = X4HCalendar.selected_calendar.attr('href');
                            $('#calendar-nav').tabs('select', tab);
                        });
                    }
                });
                
            }else{
                
                $('#calendar-nav').tabs('select', "#calendarEvent");
                
            }
            
        },
        create : function(calendar_index){
            var calendar_event = this;
            calendar_event.create_tab('Add Event');
            
            this.selected_date = X4HCalendar.selected_date;
            tinyMCE.execCommand('mceAddControl', true, 'add-event-description');
            $("#add-event-reference").val('');
            $("#add-event-startdate").val('');
            $("#add-event-enddate").val('');
            $('input[name=add-event-status][value=1]').attr('checked', true);
            $('input[name=add-event-sharing][value=Y]').attr('checked', true);
        
            var tmp_instance = tinyMCE.get('add-event-description');
            if(tmp_instance != undefined) {
                tmp_instance.setContent('');
            }
            
            //set all day as default
            $('#event-all-day-toogle').prop('checked',true);
            
            $("#add-event-startdate").datetimepicker({dateFormat: 'dd M yy',ampm:true});
            $("#add-event-enddate").datetimepicker({dateFormat: 'dd M yy',ampm:true});
            
            $("#add-event-startdate").val($.datepicker.formatDate('dd M yy', this.selected_date));
            
            $("#add-event-enddate").val($.datepicker.formatDate('dd M yy', this.selected_date));
            
            
            $('#calendar-event-save').button()
            .unbind('click').click(function(){
                if($("#add-event-reference").val()!==''){
                    X4HCalendar.save_event({calendar_index:calendar_index});
                    //$('#calendar-nav').tabs('select',X4HCalendar.tab_index)
                }else{
                    alert('Please enter an Event name.');
                }
            });
        },
        
        edit : function(selected_event,calendar_index){
            var calendar_event = this;
            calendar_event.create_tab('Edit Event');
            $("#add-event-reference").val(selected_event.reference);
            
            $("#add-event-startdate").val(selected_event.startdate);
            $("#add-event-enddate").val(selected_event.enddate);
            
            $('input[name=add-event-status][value='+selected_event.status+']').attr('checked', true);
            $('input[name=add-event-sharing][value='+selected_event['public']+']').attr('checked', true);
            
            $('#add-event-description').text(selected_event.description);
            
            tinyMCE.execCommand('mceAddControl', true, 'add-event-description');
            
            var tmp_instance = tinyMCE.get('add-event-description');
            if(tmp_instance != undefined) {
                tmp_instance.setContent(selected_event.description);
            }
            $("#add-event-startdate").datetimepicker({dateFormat: 'dd M yy',ampm:true});
            $("#add-event-startdate").datetimepicker('setDate',new Date(selected_event.startdate))
        
            $("#add-event-enddate").datetimepicker({dateFormat: 'dd M yy',ampm:true});
            $("#add-event-enddate").datetimepicker('setDate',new Date(selected_event.enddate));
            
            $('#calendar-event-save').button()
            .unbind('click').click(function(){
                if($("#add-event-reference").val()!==''){
                    X4HCalendar.save_event({id:selected_event.id,calendar_index:calendar_index});
                    $('#calendar-nav').tabs('select',X4HCalendar.tab_index)
                }else{
                    alert('Please enter an Event name.');
                }
            });
               
            var startdatetime = X4HCalendar.get_time_from_date(new Date(selected_event.startdate));
            var enddatetime = X4HCalendar.get_time_from_date(new Date(selected_event.enddate));
            
            //All day
            if(startdatetime==enddatetime){
                $('#event-all-day-toogle').prop('checked',true);
                //remove time
                $("#add-event-startdate").val($.datepicker.formatDate('dd M yy', new Date($("#add-event-startdate").val())));

                $("#add-event-enddate").val($.datepicker.formatDate('dd M yy', new Date($("#add-event-enddate").val())));
            }else{
                
            }
            
            
            //console.log((new Date(selected_event.startdate)).getHours()==(new Date(selected_event.enddate)).getHours());
        }
    },/* end calendar event */
    
    event_invitation : {
        header : $(
            '<div id="tab-event-invite-header">'
            +'<h1></h1>'
            +'<div id="event-contact-search">'
            +'  <input type="text" id="event-contact-filter"/>'
            +'  <form>'
            +'      <div>'
            +'      <select id="event-contact-search-dropdown" name="event-contact-search">'
            +'          <option value="all" selected=selected>All</option>'
            +'          <option value="firstname">First Name</option>'
            +'          <option value="surname">Last Name</option>'
            +'          <option value="email">Email</option>'
            +'          <option value="contactbusinesstext">Company</option>'
            +'          '
            +'      </select>'
            +'      </div>'
            +'  </form>'
            +'  <a href="#" id="event-contact-search-btn"><img src="/assets/images/search-btn01.png" /></a>'
            +'</div>'
            +'</div>'
        ),
        preloader : $(
        '<div id="preloader-event-invite">'
        +'<span><img src="/assets/images/preloader.gif" />&nbsp; loading</span>'
        +'</div>'
        ),    
        content : 
            '<div id="invite-attendee" class="tabbed-content-body">'
            //+'<div id="invite-attendee-panel">'
            //+'  <div id="attendeeSearch">'
            +'      <div id="invite-contact-list">'                            
            +'      </div>'
            //+'      <div id="invite-contact-list-pagination" class="pagination-area"></div>'
            //+'  </div>'
            //+'</div>'
            +'</div>'
        ,
        
        respond_content : '<div id="calendar-event-manage">'
        +'  <div class="tabs" id="invite-response-nav">'
        +'      <ul>'
        +'      <li><a href="#respondeventDetails">Event Details</a></li>'
        +'      <li><a href="#eventRespondDecline">Decline Invite</a></li>'
        +'      </ul>'
    
        +'      <div id="events-panel">'
        +'          <div id="respondeventDetails" class="tabbed-section">'
        +'              <div class="form-row">'
        +'                  <label><strong>Event Reference:</strong></label><p id="static-event-reference"></p>'
        +'              </div>'

        +'              <div class="form-row">'
        +'                  <label><strong>Start date:</strong></label><p id="static-event-startdate"></p>'
        +'              </div>'

        +'              <div class="form-row">'
        +'                  <label><strong>End date:</strong></label><p id="static-event-enddate"></p>'
        +'              </div>'

        +'              <div class="form-row">'
        +'                  <label><strong>Event Host:</strong></label><p id="static-event-host"></p>'
        +'              </div>'

        +'              <div class="form-row">'
        +'                  <label><strong>Description:</strong></label><p id="static-event-description"></p>'
        +'              </div>'
        +'          </div>'
    
        +'          <div id="eventRespondDecline" class="tabbed-section">'
        +'              <div class="form-row">'
        +'                  <label><strong>To:</strong></label><p id="decline-event-host"></p>'
        +'              </div>'
        +'              <div class="form-row">'
        +'                  <label><strong>Subject:</strong></label><p id="decline-event-subject"></p>'
        +'              </div>'
        +'              <div class="form-row">'
        +'                  <label><strong>Reason</strong></label>'
        
        +'              </div>'
        
        +'              <div style="clear: both;">&nbsp;</div>'
        +'              <textarea id="decline-event-reason"></textarea>'
        
        
        
        +'                  '
        +'          </div>'
        +'         </div>'
    
        +'  </div>'
        +'</div>'
        ,
        
        footer : '<div id="tab-event-invite-footer" class="">'
        +'            <div id="invite-contact-list-pagination" class="pagination-area"></div>'
        +'</div>'
        ,
        
        buttons : {
            cancel  : '<button id="event-invite-cancel">Cancel</button>',
            accept  : '<button id="event-invite-accept">Accept Invite</button>',
            decline : '<button id="event-invite-decline">Decline Invite</button>'
        },
        create_tab : function(title){
            if($( "#calendar-nav").find('a[href=#eventInvitation]').length==0){
                
                $('#calendar-nav').tabs("add","#eventInvitation",title);
            
                var event_invitation_panel = $('#calendar-nav').find("#eventInvitation");

                event_invitation_panel.addClass("tabbed-section");

                $('#calendar-panel').append(event_invitation_panel);
                
                $('#calendar-nav').tabs('select', "#eventInvitation");
               
                event_invitation_panel.append(this.header);
                
                event_invitation_panel.append(this.content);
                
                $('#invite-contact-list').html(this.preloader);
                
                event_invitation_panel.append(this.footer);
                
                //event_invitation_panel.append(this.buttons);
                
                if($('#event-contact-search-span').size()!=0){
                    $('#event-contact-search-span').remove();
                }
                
                $('#event-contact-search-dropdown').each(function(){
                var title = $(this).attr('title');
                if( $('option:selected', this).val() != ''  ) title = $('option:selected',this).text();
                $(this)
                    .css({'z-index':10,'opacity':0,'-khtml-appearance':'none'})
                    .after('<span id = "event-contact-search-span">' + title + '</span>')
                    .change(function(){
                        val = $('option:selected',this).text();
                        $(this).next().text(val);
                        })
                });
                
                /* bind event contact search button */
                $('#event-contact-search-btn').unbind('click').click(function(){
                    var filter_option = $('#event-contact-search-dropdown').val();
                    var filter=null;
                    
                    if(filter_option!=='all'){
                        var filter_text = $('#event-contact-filter').val();
                        filter = [{name:filter_option,comparison:'TEXT_IS_LIKE',value1: filter_text}]; 
                    }
                    
                    myappmaster.contacts.search(null,filter,null,null,'load_contacts',{
                    callbackobj : X4HCalendar,
                    container : 'invite-contact-list',
                    actionType:'event-invite',
                    rows: 20
                    });
                    
                    //reset pagination
                    console.log('resetting pagination')
                    $('#invite-contact-list-pagination').html('');
                });
                
            }else{
                $('#calendar-nav').tabs('select', "#eventInvitation");
            }
            
            
        },
        
        invite : function(){
            this.create_tab('Invite Attendee');
            $('#tab-event-invite-header h1').text('Search Contact');
            
            $('#event-contact-search').show();
            
            myappmaster.contacts.search(null,null,null,null,'load_contacts',{
                    callbackobj : X4HCalendar,
                    container : 'invite-contact-list',
                    actionType:'event-invite',
                    rows: 20
            });
            
            /* reset the buttons */
            $('#eventInvitation button').remove();
            $('#eventInvitation').append(this.buttons.cancel); 
            
            $('#event-invite-cancel').button({
                    create : function(){
                        $(this).click(function(){
                            
                            $('#calendar-nav').tabs('select', '#eventDetails');
                        });
                    }
                });
                
            
        },
        
        share : function(){
            this.create_tab('Share Calendar');
            $('#tab-event-invite-header h1').text('Search Contact');
            
            $('#event-contact-search').show();
            
            myappmaster.contacts.search(null,null,null,null,'load_contacts',{
                callbackobj : X4HCalendar,
                container : 'invite-contact-list',
                actionType:'share-calendar',
                rows: 20
            });
            
            /* reset the buttons */
            $('#eventInvitation button').remove();
            $('#eventInvitation').append(this.buttons.cancel); 
            
            $('#event-invite-cancel').button({
                create : function(){
                    $(this).click(function(){
                        //console.log(X4HCalendar.tab_index);
                        $('#calendar-nav').tabs('select',X4HCalendar.tab_index);

                    });
                }
            });
            
            /* remap contact search button for sharing */
            /* bind event contact search button */
                $('#event-contact-search-btn').unbind('click').click(function(){
                    var filter_option = $('#event-contact-search-dropdown').val();
                    var filter=null;
                    
                    if(filter_option!=='all'){
                        var filter_text = $('#event-contact-filter').val();
                        filter = [{name:filter_option,comparison:'TEXT_IS_LIKE',value1: filter_text}]; 
                    }
                    
                    myappmaster.contacts.search(null,filter,null,null,'load_contacts',{
                    callbackobj : X4HCalendar,
                    container : 'invite-contact-list',
                    actionType:'share-calendar',
                    rows: 20
                    });
                    
                    //reset pagination
                    $('#invite-contact-list-pagination').html('');
                });
            
        },
        
        unshare : function(){
            this.create_tab('Cancel Sharing');
            
            $('#tab-event-invite-header h1').text('Search Contact');
            
            $('#event-contact-search').hide();
            
            /* reset the buttons */
            $('#eventInvitation button').remove();
            $('#tab-event-invite-footer').append(this.buttons.cancel); 
            
            $('#event-invite-cancel').button({
                create : function(){
                    $(this).click(function(){

                        $('#calendar-nav').tabs('select', '#sharedCalendar');
                    });
                }
            });
            
            X4HCalendar.cancel_sharing(null,null);
            
            
        },
        
        
        respond : function(event_id, type, invite_id){
            
            this.create_tab("Event Invitation");
            
            $('#event-contact-search').hide();
            
            $('#tab-event-invite-header h1').text('Respond');
            
            
            
            $('#calendar-event-manage').html(this.preloader);
            
            
            X4HCalendar.search_event(event_id, 'invite_respond', {type: type, callbackobj: this, invite_id : invite_id});
            
            
        },
        
        invite_respond : function(response,params){
            
            var event_invitation = this;
            
            $('#invite-attendee').html(this.respond_content);
            
            /* reset the buttons */
            $('#eventInvitation button').remove();
            
            if(response.data.rows.length == 1){
                
                tinyMCE.execCommand('mceAddControl', true, 'decline-event-reason');
                
                var thisevent = response.data.rows[0];
            
                // Replace HTML entities
                $.each(thisevent, function(k, v) {
                    thisevent[k] = myappmaster.html_decode(v);
                });

                //get attendee id
                var eventid = thisevent.id;
                var event_attendee_id = null;
                
                $.each(X4HCalendar.my_attended_events,function(key,val){
                    if(val.event==eventid){
                        event_attendee_id = val.id;
                    }
                });
                
                var event_startdate = new Date(thisevent.startdate.replace(/\s\d\d:\d\d:\d\d/g, ''));
                var event_enddate = new Date(thisevent.enddate.replace(/\s\d\d:\d\d:\d\d/g, ''));

                $('#static-event-reference').html(thisevent.reference);
                $('#decline-event-subject').html(X4HUser.first_name+" "+X4HUser.last_name+' has declined your invite to '+thisevent.reference);

                //valiDate
                if(myappmaster.validate_date(event_startdate)) {
                    $('#static-event-startdate').html($.datepicker.formatDate('dd/mm/yy', event_startdate));

                }

                if(myappmaster.validate_date(event_enddate)) {
                    $('#static-event-enddate').html($.datepicker.formatDate('dd/mm/yy', event_enddate));
                }

                $('#static-event-host').html(thisevent.hostcontactpersontext);

                $('#decline-event-host').html(thisevent.hostcontactpersontext);

                $('#static-event-description').html(thisevent.description);
                
                
                
                
                $('#tab-event-invite-footer').append(this.buttons.accept);
                $('#tab-event-invite-footer').append(this.buttons.decline);
                $('#tab-event-invite-footer').append(this.buttons.cancel);


                $('#calendar-event-manage .tabs').tabs({
                show : function(event, ui){
                    if(ui.index==0){
                        if(params.type=='decline-only'){
                            $('#event-invite-accept').hide();
                        }else{
                            $('#event-invite-accept').show();
                        }
                        $('#event-invite-decline').hide();
                    }else if(ui.index==1){
                        $('#event-invite-accept').hide();
                        $('#event-invite-decline').show();
                    }
                }
                });
            
                $('#event-invite-cancel').button({
                    create : function(){
                        $(this).click(function(){

                            $('#calendar-nav').tabs('select', '#calendarEvents');
                        });
                    }
                });

                $('#event-invite-accept').button({
                    create : function(){
                        $(this).click(function(){
                            //console.log(params.invite_id)
                            X4HCalendar.accept_event_invite(params.invite_id);

                        });
                    }
                });

                $('#event-invite-decline').button({
                    create : function(){
                        $(this).click(function(){
                            $('#calendar-event-manage').hide();
                            $('#tab-event-invite-footer button').hide();
                            $('#invite-attendee').append(event_invitation.preloader);
                            X4HCalendar.search_contact(thisevent.hostcontperson,'decline_invite',{attendee_id : params.invite_id});
                        });
                    }
                });

                /* if decline */

                if(params.type=='decline'||params.type=='decline-only'){

                    $('#invite-response-nav').tabs('select','#eventRespondDecline');

                }
            }else{
                myappmaster.add_message('Unable to respond to invite.', 5);
                $('#calendar-nav').tabs('select', '#calendarEvents');
            }
            
            
        }
        
    },/* end event invitation*/
    
    save_event : function(params){
        var id = (params.id==undefined)?null:params.id;
        var startdate = (params.date==undefined)?null:params.date;
        //$("#add-event").find('.tabs').hide();
        var eventfields = {
           reference : $('#add-event-reference').val(),
           startdate   :   $("#add-event-startdate").val(),
           enddate     :   $("#add-event-enddate").val(),
           description :   tinyMCE.get('add-event-description').getContent()
           //status      :   $("input[name='add-event-status']:checked").val()
        }
        
        x4hubProxy.call(
            [X4HCalendar, 'save_event_response',{eventfields: eventfields, calendar_index: params.calendar_index}], 
            '/ondemand/event/?method=EVENT_MANAGE',
            {
                id          :   (id)?id:'',
                title       :   $('#add-event-reference').val(),
                reference   :   $('#add-event-reference').val(),
                startdate   :   $("#add-event-startdate").val(),
                enddate     :   $("#add-event-enddate").val(),
                status      :   $("input[name='add-event-status']:checked").val(),
                'public'    :   $("input[name='add-event-sharing']:checked").val(),
                description :   tinyMCE.get('add-event-description').getContent()
                
            }
        
        );
    },
    
    save_event_response : function(response,params){
		
        var message;
        var eventfields = params.eventfields;
        var calendar_index = params.calendar_index;
        if(calendar_index=='personal'){
            var category_id = 27; //personal;
        }else{
            category_id = $('#calendar-dropdown-select').val();
        }
        if(response.notes=='ADDED'){
			myappmaster.add_message('Event saved.', 5);
            var event_id = response.id;
            X4HCalendar.calendar_update_flag = true; //Calendar has been updated;
            eventfields['event_id'] = event_id;
            eventfields['category_id'] = category_id;
             x4hubProxy.call(
                [X4HCalendar, 'event_category_add_response',eventfields], 
                '/ondemand/event/?method=EVENT_CATEGORY_MANAGE',
                {
                    event : event_id,
                    category : category_id //Invite declined
                }
            );
            
        }else if(response.notes=='UPDATED'){
			myappmaster.add_message('Event updated.', 5);
            X4HCalendar.calendar_update_flag = true; //Calendar has been updated;
            event_id = response.id;
            eventfields['event_id'] = event_id;
            
            if(calendar_index=="personal"){
                var events_array = X4HCalendar.my_action_events;
            }else if(calendar_index=="shared"){
                events_array = X4HCalendar.shared_calendar.shared_events;
            }
            
            $.each(events_array,function(key,val){
                if(val.linkid==event_id){
                    eventfields['actionid'] = val.id;
                    X4HCalendar.edit_action(eventfields, 'edit_action_response');
                }
            })
            
        }else{
            
            myappmaster.add_message('Unable to save event.', 5);
            $('#calendar-nav').tabs('select',X4HCalendar.tab_index);
        }
        
        
        
    },
    
    event_category_add_response : function(response,eventfields){
        if(response.notes=='ADDED'){
            myappmaster.add_message('Event category has been saved.', 5);
            eventfields['actionby'] = X4HUser.contact_person;
            X4HCalendar.create_action(eventfields, 'create_action_response');
            
        }else{
            /*var message = "Error processing request.";
            alert(message);*/
            myappmaster.add_message('An error occurred when saving event category.', 5);
            $('#calendar-nav').tabs('select',X4HCalendar.tab_index);
        }
    },
    
    create_action : function(eventfields,callback){
         var totaltimeminutes = myappmaster.calendar.get_date_duration({
            enddate : eventfields.enddate,
            startdate : eventfields.startdate,
            format : 'MM'
         });
        x4hubProxy.call(
            [X4HCalendar, callback], 
            '/ondemand/action/?method=ACTION_MANAGE',
            {
                actionby     : eventfields.actionby,
                actiontype   : 313, //Event
                object       : 39, //Event Object,
                //linktype     : 39,
                //linkid       : eventfields.event_id,
                date : eventfields.startdate,
                enddate : eventfields.enddate,
                objectcontext : eventfields.event_id,
                'private' : 'N', //default
                description : eventfields.description,
                subject : eventfields.reference,
                totaltimeminutes : totaltimeminutes
                /*actionstatus : */
            }
        );
    },
    
    edit_action : function(eventfields,callback){
        var totaltimeminutes = myappmaster.calendar.get_date_duration({
            enddate : eventfields.enddate,
            startdate : eventfields.startdate,
            format : 'MM'
         });
        x4hubProxy.call(
            [X4HCalendar, callback], 
            '/ondemand/action/?method=ACTION_MANAGE',
            {
                id  :   eventfields.actionid,
                actiontype   : 313, //Event
                object       : 39, //Event Object
                date : eventfields.startdate,
                enddate : eventfields.enddate,
                objectcontext : eventfields.event_id,
                'private' : 'N', //default
                description : eventfields.description,
                subject : eventfields.reference,
                totaltimeminutes : totaltimeminutes
                /*actionstatus : */
            }
        );
    },
    
    edit_action_response : function(response){
        myappmaster.add_message('Event updated.', 5);
        
        $('.preloader-modal').dialog('close');
        $("#add-event").dialog("close");
        $('#calendar-nav').tabs('select',X4HCalendar.tab_index);
        //refreshing schedule widget
        
    },
    
    create_action_response : function(response){
       
        if(response.notes=="ADDED"){
            myappmaster.add_message('Event saved.', 5);
		
            $("#add-event").dialog("close");
            $('#calendar-nav').tabs('select',X4HCalendar.tab_index);
            $('#calendar-select').hide()//populate calendar types
            $('#calendar-items').dialog('close');
            
            $(X4HCalendar.containing_element).html('');
            X4HCalendar.overview_preloader.show();
            //X4HCalendar.shared_calendar.current_calendar = X4HCalendar.shared_calendar.calendars[0];
            //X4HCalendar.shared_calendar.init();
            $('#calendar-nav').find('.eventDetails').parent().hide();
            
            //X4HCalendar.tab_index=1;
        }
        
        X4HCalendar.get_event_gategories();
        
    },
    
    search_event_attendee : function(event_id,callback,params){
        x4hubProxy.call([X4HCalendar, callback, params],
            '/ondemand/event/?method=EVENT_ATTENDEE_SEARCH',
            {
                event: event_id,
                includecontact : 1,
                advanced : 1
            }
        );
    },
    
    get_attendee_details : function(response,params){
        var load_invite_controls = false;
        //check if user is allowed to invite attendees
        if(X4HCalendar.event_actions!==null&&X4HCalendar.event_actions.length>0){
           $.each(X4HCalendar.event_actions,function(key,action){
               if(action.linkid==X4HCalendar.selected_event.id&&action.actionby==X4HUser.contact_person){
                   
                   load_invite_controls = true;
                   return false;
               }else{
                   if(X4HCalendar.corporate_upcoming_actions[X4HCalendar.selected_event.id]!==undefined){
                       if(X4HCalendar.corporate_upcoming_actions[X4HCalendar.selected_event.id].actionby==X4HUser.contact_person){
                           load_invite_controls = true;
                       }
                   }
                   
               }
           });
           
           
        }
        if(load_invite_controls == true){
            //console.log($('.event-attendees-invite').size())
            if($('.event-attendees-invite').size()==0){
                var invite_btn = $(
                    '<a class="event-attendees-invite">'
                    +'<span>Invite Attendee</span>'
                    +'</a>'
                );
                $('#event-attendees-invite-row').append(invite_btn);
            }
            $('.event-attendees-invite').unbind('click').click(function(){
                /* to tab */
                myappmaster.calendar.event_invitation.invite();
            });
        }else{
            $('.event-attendees-invite').remove();
        }
        
        
        
        if(response.data.rows.length>0){
            var attendees = response.data.rows;
            X4HCalendar.event_attendees = attendees;
            
            var attendee_ids = [];
            
            $.each(attendees,function(key,row){
                attendee_ids.push(row.contactperson);
                if(row.contactperson==X4HUser.contact_person&&row.status==3){
                    $('#cancel-invite').show();
                }
            });
            
            var oXML = new X4HASearch()
                .addField('firstname')
                .addField('surname')
                .addField('email')
                .addField('homephone')
                .addField('workphone')
                .addField('mobile')
                .addField('streetaddress1')
                .addField('streetaddress2')
                .addField('streetsuburb')
                .addField('streetstate')
                .addField('streetcountry')
                .addField('streetpostcode')
                .addFilter('id', 'IN_LIST',attendee_ids)
                .getXML();
                
                x4hubProxy.call([X4HCalendar, 'load_attendee'],
                '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
                    {
                        advanced: 1,
                        data: oXML,
                        rows: 100 //temp
                    }
                );
                
        }else{
            $('#event-attendees-list').html('<div class="event-attendees-row">There are no attendees.</div>');
            $('#preloader-event-details').hide();
            $('#eventDetails').find('.event-details-row').show();
            $('.event-attendees').show();
            $('#event-attendees-footer').show();
            $('#back-to-calendar').show();
        }
    },
    
    load_contacts : function(response,params){
        // Remove children
        $("#invite-contact-list").html('');
        $('#' + params.container).find('.contact-row').remove();
        if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                
                var sProfileImage = '/assets/images/avatar06.png';
                
                //Check if they have an attachment defined in their attachment id field
                if(row.sq6965!==undefined&&row.sq6965 != '')
                {
                        sProfileImage = x4hubProxy.site_url + '/ondemand/core/?method=CORE_IMAGE_SEARCH' + '&id=' + row.sq6965 + '&sid=' + x4hubProxy.sid;
                }
                
                var newrow = $(
                    '<div id="invite-contact-row-' + row.id + '" class="calendar-contact-row">'
                        + '<div class="calendar-contact-img-div">' + '<img src = "'+sProfileImage+'" class="calendar-contact-img" id="calendar-contact-img-'+row.id+'" width="60" height="50"/>' + '</div>'
                        + '<div class="contact-details calendar-contact-details">'
                        + '<div class="contact-firstname"> Name: ' + row.firstname + '&nbsp;' + row.surname +'</div>'
                        + '<div class="contact-email">Email: ' + row.email + '</div>'
                        + '<div class="contact-position"> Position: ' + row.position + '</div>'
                        + '<div class="contact-phone">Phone:' + row.workphone + '</div>'
                        + '<div class="contact-company"> Company: ' + row.contactbusinesstext + '</div>'
                        + '<div class="contact-mobile">Mobile: ' + row.mobile + '</div>'
                    	+'</div>'
                        + '<div class="calendar-contact-options"><span id="contact-invite-' + row.id + '" class="contact-invite-anchor">'+((params.actionType=='share-calendar')?'Share Calendar':'Invite')+'</span></div>'
                        + 
                    '</div>'
                );
                    
                    
                    
                $('#' + params.container).append(newrow);
                
                //check if the profile image did load
                $('#invite-contact-row-'+row.id+' div img').error(function() {
                    //change to default image
                    $(this).attr('src','/assets/images/avatar06.png');

                });
                
                if(key + 1 < response.data.rows.length) {
                    $('#' + params.container).append('<div class="calendar-contact-line"></div>');
                }
            });
            
            //change images
            //myappmaster.contacts.change_image('calendar-contact-img','calendar-contact-img');
        }else{
            $('#' + params.container).append('<p>There are no contacts to display.</p>');
        }
        
        if(params.actionType=='event-invite'){
            $.each( $( '.contact-invite-anchor' ), function(counter, elem) {
                $(elem).unbind('click').click(function() {
                    
                    
                    var contact_id = myappmaster.find_id($(elem).attr('id'));

                    var oXML = new X4HASearch()
                    .addField('firstname')
                    .addField('surname')
                    .addField('email')
                    .addField('homephone')
                    .addField('workphone')
                    .addField('mobile')
                    .addField('streetaddress1')
                    .addField('streetaddress2')
                    .addField('streetsuburb')
                    .addField('streetstate')
                    .addField('streetcountry')
                    .addField('streetpostcode')
                    .addFilter('id', 'EQUAL_TO', contact_id)
                    .getXML();

                    x4hubProxy.call([X4HCalendar, 'invite_contact'],
                    '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
                        {
                            advanced: 1,
                            data: oXML
                        }
                    );
                    
                    //add a preloader image
                    $(this).append('<img src="/assets/images/preloader2.gif" class="invite-contact-anchor-preloader" />');
                });
            });
        }else if(params.actionType=='share-calendar'){
            //get event on this calendar categories
            
            var eventIds = [];
            $.each(X4HCalendar.events_array_shared,function(key,val){
                eventIds.push(val.event);
            });
            //console.log(X4HCalendar.events_array_shared);
            //console.log(eventIds);
            $.each( $( '.contact-invite-anchor' ), function(counter, elem) {
                $(elem).unbind('click').click(function() {
                    //$('.preloader-modal').dialog('open');
                    //$('.preloader-modal').dialog({title: 'Share Calendar'});
                    var contact_id = myappmaster.find_id($(elem).attr('id'));
                    //console.log('share-calendar');
                    
                    var oXML = new X4HASearch()
                    .addField('Reference')
                    .addField('HostContPerson')
                    .addField('HostContactPersonText')
                    .addField('StartDate')
                    .addField('EndDate')
                    .addField('Status')
                    .addField('StatusText')
                    .addField('Description')
                    .addField('Public')
                    .addField('Type')
                    .addFilter('id', 'IN_LIST',eventIds)
                    .addFilter('HostContPerson','EQUAL_TO',X4HUser.contact_person)
                    .getXML();
                    
                     x4hubProxy.call([X4HCalendar, 'share_calendar_events',{contact_id : contact_id}],
                    '/ondemand/event/?method=EVENT_SEARCH',
                        {
                            //iamcreator : 1,
                            advanced : 1,
                            data : oXML
                        }
                    );
                    
                });
                
            });
        }
    },
    invite_contact : function(response){
        var selected_event = X4HCalendar.selected_event;
        if(response.data.rows.length > 0){
            var contact = response.data.rows[0];
            x4hubProxy.call(
            [X4HCalendar, 'invite_attendee_response'], 
            '/ondemand/event/?method=EVENT_ATTENDEE_MANAGE', 
                {
                    //id : id,
                    event : selected_event.id,
                    contactperson: contact.id,
                    firstname : contact.firstname,
                    surname : contact.surname,
                    email : contact.email,
                    phone : contact.workphone,
                    homephone : contact.homephone,
                    mailingaddress1 : contact.streetaddress1,
                    mailingaddress2 : contact.streetaddress2,
                    mailingsuburb : contact.streetsuburb,
                    mailingstate : contact.streetstate,
                    mailingcountry : contact.streetcountry,
                    mailingpostcode : contact.streetpostcode,
                    status: 2
                    //reference : reference

                }
            );
        }else{
            $('.invite-contact-anchor-preloader').remove();
        }
        
    },
    invite_attendee_response : function (response){
        if(response.notes=="ADDED" || response.notes=="UPDATED"){
			myappmaster.add_message('Contact has been invited to this event.', 5);
            //alert('Contact has been invited to this event.');
            X4HCalendar.search_event(X4HCalendar.selected_event.id, 'show_event_details',{calendar_index:X4HCalendar.calendar_index});
        }else{
            myappmaster.add_message('Unable to invite contact.', 5);
        }
        $('.invite-contact-anchor-preloader').remove();
        
    },
    
    load_attendee : function(response){
        var load_invite_controls = false;
        //check if user is allowed to invite attendees
        if(X4HCalendar.event_actions!==null&&X4HCalendar.event_actions.length>0){
           $.each(X4HCalendar.event_actions,function(key,action){
               if(action.linkid==X4HCalendar.selected_event.id&&action.actionby==X4HUser.contact_person){
                   load_invite_controls = true;
                   return false;
               }else{
                   if(X4HCalendar.corporate_upcoming_actions[X4HCalendar.selected_event.id]!==undefined){
                       if(X4HCalendar.corporate_upcoming_actions[X4HCalendar.selected_event.id].actionby==X4HUser.contact_person){
                           load_invite_controls = true;
                       }
                   }
                   
               }
           });
        }
        
        $('#preloader-event-details').hide();
        $('#eventDetails').find('.event-details-row').show();
        $('.event-attendees').show();
        $('#event-attendees-footer').show();
        $('#back-to-calendar').show();
        
        if(response.data.rows.length > 0){
            var contacts = response.data.rows;
            $('#event-attendees-list').html('')
            $.each(X4HCalendar.event_attendees,function(key,eval){
                $.each(contacts,function(key,cval){
                   if(cval.id==eval.contactperson){
                   var contact_row = $(
                    '<div class="event-attendees-row"><div class="contact-details"><div id="contact-details-header">Name: </div><div id="contact-details-title">'+cval.firstname+ '&nbsp;' + cval.surname +'</div></div>'
                    +'<div class="contact-details"><div id="contact-details-header">Email: </div><div id="contact-details-title">' + cval.email + '</div></div>'
                    +'<div class="contact-details"><div id="contact-details-header">Status: </div><div id="contact-details-title"><span id="attendee-statustext-'+eval.id+'">' + eval.statustext + '</span></div></div>'
                    +'<div class="contact-details"><!--<span><a href="#" class="contact-remove" id="contact-remove-'+eval.id+'">Remove Attendee</a></span>&nbsp;--><span><a href="javascript:void(0);" class="status-edit" id="contact-change-status-'+eval.id+'">Change Attendee Status</a></span></div>'
                    +'</div>'
                    );
                    
                    $('#event-attendees-list').append(contact_row);
                    
                    
                   } 
                });
            });
            
            
            if(load_invite_controls == true){
                $('.status-edit').unbind('click').click(function(){
                    var changebutton = $(this);
                    var attendee_id = myappmaster.find_id($(this).attr('id'));

                    changebutton.parent().parent().hide();
                    var statuses = $(
                         '<div id="invite-status-option">'
                        +'<input type="radio" name="attendeestatus-'+attendee_id+'" value="2" class="attendeestatus" /><label>Invited</label><br />' 
                        +'<input type="radio" name="attendeestatus-'+attendee_id+'" value="3" class="attendeestatus" /><label>Accepted</label><br />'
                        +'<input type="radio" name="attendeestatus-'+attendee_id+'" value="4" class="attendeestatus" /><label>Declined</label><br />'
                        +'<input type="radio" name="attendeestatus-'+attendee_id+'" value="5" class="attendeestatus" /><label>Accepted - Did Not Show</label><br />'
                        +'<input type="radio" name="attendeestatus-'+attendee_id+'" value="6" class="attendeestatus" /><label>On Standby</label><br />'
                        +'<input type="radio" name="attendeestatus-'+attendee_id+'" value="7" class="attendeestatus" /><label>Did not attend</label><br />'
                        +'<input type="radio" name="attendeestatus-'+attendee_id+'" value="8" class="attendeestatus" /><label>Attended</label><br />'
                        +'<input type="radio" name="attendeestatus-'+attendee_id+'" value="9" class="attendeestatus" /><label>Accepted - Did Not Attend</label><br />'
                        +'</div>'
                    );
                    $('#attendee-statustext-'+attendee_id).html('');
                    
                    if(changebutton.parent().parent().parent().find('#invite-status-option').size()==0){
                        changebutton.parent().parent().parent().append(statuses);
                    }
                });
                
                //if($('.attendeestatus').data('events')==undefined){
                //console.log($('.attendeestatus').data('events'))
                $('.attendeestatus').die('click').live('click',function(){
                    var attendee_id = myappmaster.find_id($(this).attr('name'));
                    var changebutton = $('#contact-change-status-'+attendee_id);    

                    x4hubProxy.call(
                        [X4HCalendar, 'change_attendee_status'], 
                        '/ondemand/event/?method=EVENT_ATTENDEE_MANAGE',
                        {
                            id: attendee_id,
                            status : $(this).val()

                        }
                    );

                    $(this).parent().remove();
                    $('#attendee-statustext-'+attendee_id).html($(this).next().text());    
                    changebutton.parent().parent().show();
                });
              //}
            }else{
                $('.status-edit').parent().remove();
            }
        }
    },
    change_attendee_status : function(response){
		myappmaster.add_message('Attendee has been updated.', 5);
	},
    
    share_calendar_events : function(response,params){
        if(response.data.rows.length>0){
            var ownedevents = response.data.rows;
            
            X4HCalendar.search_actions_by_contact(params.contact_id,'create_action_by_events',{ownedevents : ownedevents,contact_id: params.contact_id})
            
        }else{
            alert('No events to share for this Calendar');
        }
    },
    
    create_action_by_events : function(response,params){
        var actionToCreate = [];
        X4HCalendar.actions_shared = [];
        X4HCalendar.actions_to_share = 0;
        if(response.data.rows.length>0){
            $.each(params.ownedevents,function(ekey,eval){
                var exists = false;
                $.each(response.data.rows,function(rkey,rval){
                    if(eval.id==rval.objectcontext){
                        exists = true;
                        return;
                    }

                });
                if(!exists){
                    actionToCreate.push(eval)
                }

            });    
        }else{
            actionToCreate = params.ownedevents;
        }
        if(actionToCreate.length>0){
            X4HCalendar.actions_to_share = actionToCreate.length;
            //console.log(X4HCalendar.actions_to_share)
            $.each(actionToCreate,function(key,val){
                var eventfields = val;
                eventfields['actionby'] = params.contact_id;
                eventfields['event_id'] = val.id
                X4HCalendar.create_action(eventfields, 'create_action_by_events_response');
                
            });
        }else{
            alert('There are no events to be shared');
            $('.preloader-modal').dialog('close');
        }
    },
    
    create_action_by_events_response : function(response){
        //X4HCalendar.action_shared+=1;
        X4HCalendar.actions_shared.push(response);
        if(X4HCalendar.actions_to_share==X4HCalendar.actions_shared.length){
            myappmaster.add_message('Events on this calendar have been shared.', 5);
            
            $('#calendar-nav').tabs('select',X4HCalendar.tab_index);
        }/*else{
            myappmaster.add_message('There was an error on your request.', 5);
            
            
        }*/
            
    },
    
    
    search_actions_by_contact : function(contact_id,callback,params){
        x4hubProxy.call([X4HCalendar,callback,params],
        '/ondemand/action/?method=ACTION_SEARCH',
            {
                object :  39,
                actionby : contact_id,
                rows: 1000

            }
        );
    },
    
    delete_event_action : function(selected_event){
        //console.log(selected_event);
        if(selected_event.hostcontperson==X4HUser.contact_person){
            //search action
            x4hubProxy.call([X4HCalendar,'delete_event_action_response',{selected_event: selected_event}],
                '/ondemand/action/?method=ACTION_SEARCH',
                {
                    object :  39,
                    objectcontext  : selected_event.id
                    
                }
            );
            
        }
    },
    
    delete_event_action_response : function(response,params){
        if(response.notes=="RETURNED"){
            if(response.data.rows.length>0){
                X4HCalendar.actions_to_delete = response.data.rows;
                
                $.each(X4HCalendar.actions_to_delete,function(key,row){
                    //delete action
                    X4HCalendar.delete_action('delete_event_action_response', 
                    {
                        selected_event:params.selected_event,
                        object : 39,
                        actionid : row.id,
                        deletekey : (key+1)
                    });
                });
            }
        }
        else if(response.notes=="REMOVED"){
            if(params.deletekey==X4HCalendar.actions_to_delete.length){
                x4hubProxy.call(
                    [X4HCalendar, 'delete_event_response'], 
                    '/ondemand/event/?method=EVENT_MANAGE',
                    {
                        id: params.selected_event.id,
                        remove : 1
                    }
               );
            }    
            
        }else{
            alert("Error deleting event.");
            $('#calendar-nav').tabs('select',X4HCalendar.tab_index);
            
        }
        
        
    },
    
    delete_action : function(callback,params){
        x4hubProxy.call([X4HCalendar,callback,params],
        '/ondemand/action/?method=ACTION_MANAGE',
            {
                id : params.actionid,
                object :  params.object,
                objectcontext  : params.selected_event.id,
                remove : 1
            }
        );
    },
    
    
    delete_event_response : function (response){
        if(response.notes=="REMOVED"){
			myappmaster.add_message('Event has been removed.', 5);
            
            X4HCalendar.calendar_update_flag = true; //Calendar has been updated;
        }else{
			myappmaster.add_message('Error deleting event.', 5);
            //alert('Error deleting event.');
        }
        $('#calendar-nav').tabs('select',X4HCalendar.tab_index);

    },
    
    cancel_sharing : function(response,params){
        
        /*if(){
            //X4HCalendar.search_event(null, 'cancel_sharing', null);
            x4hubProxy.call(
            [X4HCalendar, 'cancel_sharing',{callType:'event'}],
            '/ondemand/event/?method=EVENT_SEARCH',
                {
                    iamcreator : 1
                }
            );
        }*/if(response==null){
            var eventIds = [];
            $.each(X4HCalendar.events_array_shared,function(key,val){
                eventIds.push(val.event);
            });
            
            var oXML = new X4HASearch()
                    .addField('ActionBy')
                    .addField('ActionType')
                    .addField('ActionTypeText')
                    .addField('LinkId')
                    .addField('ContactPersonText')
                    .addField('DueDate')
                    .addField('ContactPerson')
                    .addField('Status')
                    .addField('StatusText')
                    .addField('Description')
                    //.addField('Public')
                    //.addField('Type')
                    .addFilter('LinkId', 'IN_LIST',eventIds)
                    .addFilter('LinkType','EQUAL_TO',39)
                    .addFilter('ActionBy','NOT_EQUAL_TO',X4HUser.contact_person)
                    .getXML();
            
            /*x4hubProxy.call([X4HCalendar,'cancel_sharing',{callType:'action',eventIds : eventIds}],
            '/ondemand/action/?method=ACTION_SEARCH',
                {
                    object :  39,
                    advanced: 1,
                    data : oXML

                }
            );*/
                
                x4hubProxy.call([X4HCalendar,'cancel_sharing',{
                    callType:'action'    
                }],
            '/ondemand/action/?method=ACTION_SEARCH',
                {
                    object :  39,
                    advanced: 1,
                    data : oXML,
                    rows:1000

                }
            );
        }else if (params.callType=='action'){
            if(response.data.rows.length>0){
                var actions = response.data.rows;
                var shared_actions = [];
                var contacts = [];
                //get relevant actions

                $.each(actions,function(key,row){
                    /*if(row.actionby!==X4HUser.contact_person){
                        $.each(params.eventIds,function(ekey,erow){
                           if(erow==row.objectcontext){
                               shared_actions.push(row);
                               contacts.push(row.actionby);
                           } 
                        });
                    }*/

                    shared_actions.push(row);
                    if($.inArray(contacts,row.actionby)==-1){        
                        contacts.push(row.actionby);
                    }
                });

                X4HCalendar.shared_actions = shared_actions;

                //populate contact who you share events to
                var oXML = new X4HASearch()
                .addField('firstname')
                .addField('surname')
                .addField('email')
                .addField('homephone')
                .addField('workphone')
                .addField('mobile')
                .addField('streetaddress1')
                .addField('streetaddress2')
                .addField('streetsuburb')
                .addField('streetstate')
                .addField('streetcountry')
                .addField('streetpostcode')
                .addFilter('id', 'IN_LIST', contacts)
                .getXML();

                x4hubProxy.call(
                    [X4HCalendar, 'cancel_sharing',{callType:'contacts'}],
                    '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
                    {
                        advanced: 1,
                        data: oXML
                    }
                );
            }else{
                $("#invite-contact-list").html('<p>There are no shared events to cancel.</p>');
                
            }
            
            
        }else if(response.data.rows.length>0 && params.callType=='contacts'){
            $("#invite-contact-list").html('');
            $( "#invite-attendee .tabs" ).find('a').html('Contact List');
            $( "#invite-attendee .tabs" ).tabs();
            
            //populate contact list
            var contact_header = $(
                '<div id="cancel-sharing-header"><span><strong>Events are being shared to:</strong></span></div>'
            );
                
            $("#invite-contact-list").append(contact_header);
            
            $.each(response.data.rows,function(key,row){
                var contact_row = $(
                    '<div id="invite-contact-row-'+row.id+'" class="shared-contact"><span id="invite-contact-name-'+row.id+'" class="invite-contact-name">'+row.firstname+'&nbsp;'+row.surname+'</span><span id="invite-contact-unshare-'+row.id+'" class="invite-contact-unshare"><a href="#" id="unshare-'+row.id+'" class="unshare-to-contact">Unshare Events</a></span></div>'
                );
                
                $("#invite-contact-list").append(contact_row);
            });
            
            //bind click on items
           $.each($('.unshare-to-contact'),function(counter, elem){
               $(elem).click(function(){
                   
                   var contactid = myappmaster.find_id($(elem).attr('id'));
                   X4HCalendar.actions_to_delete = [];
                   
                   //remove actions
                   $.each(X4HCalendar.shared_actions,function(key,row){
                      if(row.actionby==contactid){
                          
                          X4HCalendar.actions_to_delete.push(row);
                      } 
                   });
                   
                   $.each(X4HCalendar.actions_to_delete,function(key,val){
                       X4HCalendar.delete_action('unshare_events', {deleted : key+1,actionid : val.id,selected_event: {id:null}, object: 39})
                   });
                   
               });
           });
            
        }
    },
    
    unshare_events : function(response,params){
        if(response.notes=="REMOVED"){
            if(params.deleted==X4HCalendar.actions_to_delete.length){
                
                myappmaster.add_message('Events sharing has been removed for this contact.', 5);
                
                X4HCalendar.cancel_sharing(null, null)
            }
        }else{
            myappmaster.add_message('Error cancel sharing.', 5);
            
        }
    },
    
    /**
     * Calendar Widget
     * 
     */
    widget : {
        calendar_footer : $(
        '<div id = "sidebar-calendar-footer">'
        /*+'  <a id = "calendar-add-btn" href="#"><img src="/assets/images/plus-img01.png" /> Add new item</a>'*/           
        +'</div>'
        ),
        
        init : function(){
          //configs here
          //init items first
          //$('.progressbar-loading').progressbar("option","value", 2);
          $('.state-loading').text('Loading Calendar');
          var today = new Date();
          X4HCalendar.today = $.datepicker.formatDate('dd/mm/yy', today);
          X4HCalendar.calendar_index="widget";
          X4HCalendar.get_event_gategories();
          
          //this.get_events();
        },
        
        get_events : function(){
          
          //this.load_calendar();  
        },
        
        load_calendar : function(){
            var calendar_widget = X4HCalendar.create_calendar({
                id : 'ffoffice-calendar-widget',
                calendar_width : 230,
                fullCalendar_options : {
                   titleFormat : {
                       month : 'MMMM yyyy'
                   },
                   header : {
                       left : 'prev',
                       center : '',
                       right : 'next'

                   },
                   buttonText: {
                       prev: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;',
                       next: '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
                   },
                   viewDisplay : function(view){
                      var calendar_object = this;
                         
                      $(calendar_object).find('.mark-date1').removeClass('mark-date1'); 
                      
                      
                      $(this).find('.fc-header-center').html(view.title);
                      
                      var today = $(this).fullCalendar('getDate');
                      cYear = today.getFullYear();
                      cMonth = today.getMonth();
                      
                      var calendar_current_date = $.datepicker.formatDate('dd/mm/yy', today);
                      if(!(X4HCalendar.today==calendar_current_date)){
                          //assuming events by category has been loaded
                           var event_id_array = [];
                           var accepted_event_array = [];
                           
                           //switch between loaded events
                           X4HCalendar.events_array = X4HCalendar.events_array_personal;

                           $.each(X4HCalendar.events_array,function(key,val){
                                event_id_array.push(val.event);
                           });
                           
                           //assuming event attendee have been searched
                           //push to events to query
                           if(X4HCalendar.my_attended_events!==null){
                            $.each(X4HCalendar.my_attended_events,function(key,val){
                                //params.event_id_array.push(val.event);
                                accepted_event_array.push(val.event);
                            });
                           }

                            X4HCalendar.accepted_event_array = accepted_event_array;

                            X4HCalendar.get_event_actions(calendar_current_date,{

                                      calendar_object : calendar_object,
                                      cYear : cYear,
                                      cMonth : cMonth,
                                      calendar_index : "widget",
                                      event_id_array : event_id_array,
                                      accepted_event_array : accepted_event_array

                            });
                            
                      }else{
                          X4HCalendar.check_calendar_events({
                              calendar_object : calendar_object,
                              cYear : cYear,
                              cMonth : cMonth,
                              calendar_index : "widget"
                           });
                      }
                      
                      
                   },
                   events: function(start, end, callback) {
                       X4HCalendar.calendar_index="widget";
                   }
                }
            });
            
            // fullCalendar Tweaks
           var removeThis = calendar_widget.find('.fc-widget-header');
           var removeThisParent = removeThis.parent().parent().remove();
           
           calendar_widget.find('.fc-content table').css("width","224")
           
           $('#calendar-widget').append(calendar_widget);
           
           $('#ffoffice-calendar-widget').append(this.calendar_footer);
        }
        
        
    },
    
    event_summary : {
        summary_panel : $(
            '<div id="calendar-summary-panel">'
            +'  <h1>Events for this Month</h1>'
            +'  <div id="calendar-summary-events-list">'
            +'      <div id="calendar-summary-preloader">'
            +'          <span>Loading Events <img src="/assets/images/preloader2.gif" /></span>'
            +'      </div>'
            +'      <table>'
            +'      </table>'
            +'  </div>'
            +'</div>'    
        ),
        init : function(calendar_index){
            
            $(X4HCalendar.containing_element).append(this.summary_panel);
            
            this.load_events_summary();
        },
        load_events_summary : function(){
            
            //load events
            var event_row = '';
            
            var this_month_event_actions = [];
            
            if(X4HCalendar.event_actions!==null&&X4HCalendar.event_actions.length>0){
                $.each(X4HCalendar.event_actions,function(key,row){
                    if($.inArray(row.linkid,this_month_event_actions)==-1){
                        event_row+='<tr>'
                        +'<td class="event-label">'+row.duedate+'</td><td>-</td>'
                        +'<td>'+row.actionreference+'</td>'
                        +'</tr>';
                        this_month_event_actions.push(row.linkid);
                    }
                    
                });
            }else{
                
                event_row+='<tr><td>There are no events for this month.</td></tr>';
            }
            
            //hide preloader
            $('#calendar-summary-preloader').hide();
            $('#calendar-summary-events-list table').html($(event_row));
            
        }
    },
    
    upcoming_events : {
        upcoming_events_panel : $(
            '<div id="calendar-upcoming-events">'
            +'  <h1 id="upcoming-event-header">Upcoming Events</h1>'
            +'  <div id="calendar-upcoming-events-list">'
            +'      <div id="calendar-upcoming-preloader">'
            +'          <span>Loading Events <img src="/assets/images/preloader2.gif" /></span>'
            +'      </div>'
            +'      <ul>'
            +'      </ul>'
            +'  </div>'
            +'</div>'
        ),
        
        init : function(){
            $(X4HCalendar.containing_element).append(this.upcoming_events_panel);
            this.load_upcoming_events();
        },
        
        load_upcoming_events : function(){
            //show preloader
            
            
            //search for actions, filter by date range
            var calendar_date = $(X4HCalendar.containing_element).find('.ffcalendar-current').fullCalendar('getDate');
            var startdate = new Date(calendar_date.getFullYear(), calendar_date.getMonth(), 1);
            var nextquarter = new Date(startdate.getFullYear(),startdate.getMonth()+3,0);
            var startdate_str  = $.datepicker.formatDate('dd/mm/yy', startdate);
            var nextquarter_str = $.datepicker.formatDate('dd/mm/yy', nextquarter);
            
            //console.log(startdate_str+":"+nextquarter_str);
            
            
            var event_id_array = [];
            $.each(X4HCalendar.events_array,function(key,val){
                event_id_array.push(val.event);
            });
            
            /* if there are no relevant events, then force to 0 to prevent action from searching other events */
            if(event_id_array.length==0){
                event_id_array = [0];
            }
            
            this.search_upcoming_events(this,'load_upcoming_events_response',
            {
                event_id_array  : event_id_array,
                startdate       : startdate_str,
                nextquarter     : nextquarter_str
            });
        },
        
        search_upcoming_events : function(callbackobj, callback, params){
            
            var filters = [
                {
                    name : 'LinkId',
                    comparison : 'IN_LIST',
                    value1 : params.event_id_array
                },
                {
                    name : 'DueDate',
                    comparison : 'BETWEEN',
                    value1 : params.startdate,
                    value2 : params.nextquarter
                    
                },
                {
                    name : 'LinkType',
                    comparison : 'EQUAL_TO',
                    value1 : 39
                    
                },
                {
                    name : 'ActionBy',
                    comparison : 'EQUAL_TO',
                    value1 : X4HUser.contact_person
                    
                }
            ];
            
            //load accepted events as well
            if(X4HCalendar.my_attended_events!==null&&X4HCalendar.calendar_index == 'personal'){
                var accepted_events_array = [];
                $.each(X4HCalendar.my_attended_events,function(key,row){
                   accepted_events_array.push(row.event); 
                });
                if(accepted_events_array.length>0){
                    filters.push(
                        {
                            name : 'or',
                            comparison : '',
                            value1 : ''
                        }
                    );
                
                    filters.push(
                        {
                            name : 'LinkId',
                            comparison : 'IN_LIST',
                            value1 :   accepted_events_array
                        }
                    );

                    filters.push(
                        {
                        name : 'DueDate',
                        comparison : 'BETWEEN',
                        value1 : params.startdate,
                        value2 : params.nextquarter

                        }
                    );

                    filters.push(
                        {
                            name : 'LinkType',
                            comparison : 'EQUAL_TO',
                            value1 : 39
                        }
                    );
                }
                
            }
            
            /* 'Firstfolio Corporate' (29) - Public Shared Calendar */
            if(X4HCalendar.selected_event_category==29){
               $.each(filters,function(key,val){
                    if(val.name=='ActionBy'){
                        filters.splice(key,1);

                    }
                });
            }
            
            var oXML = new X4HASearch(X4HCalendar.defaultActionFields, filters, null, X4HCalendar.defaultActionSort).getXML();
            
        
            x4hubProxy.call(
                [callbackobj,callback,params],
                '/ondemand/action/?method=ACTION_SEARCH',
                {
                    advanced:1,
                    data : oXML,
                    rows:1000

                }
            );
        },
        
        load_upcoming_events_response : function(response, params){
            var appended_upcoming_events = [];
            var event_row = $('<div></div>');
            $('#calendar-upcoming-events-list').html('');
            
            if(response.data.rows.length>0){
                var quarter_events = response.data.rows
                var month_array = [];
                
                //get Month
                $.each(quarter_events,function(key,row){
                    var duedate = new Date(row.duedate);
                    var event_month  = $.datepicker.formatDate('MM - yy',duedate);
                    if($.inArray(event_month, month_array)==-1){
                        month_array.push(event_month);
                        
                        var month_div_header = $(
                            '<h1 class="upcoming-month-header">'+event_month+'</h1>');
                            
                        var month_div_items=$(
                            '<ul id="upcoming-month-'+duedate.getMonth()+duedate.getFullYear()+'"></ul>'
                        );
                            
                        event_row.append(month_div_header);
                        event_row.append(month_div_items);
                        
                    }
                    var event_details_row = $(
                        '<li>'
                        +'<span class="event-row-date">'+row.duedate+' - </span>'
                        +'<span class="event-row-reference">'+row.actionreference+'</span>'
                        +'</li>'
                    );
                      
                    if($.inArray(row.linkid,appended_upcoming_events)==-1){
                    
                        event_row.find('#upcoming-month-'+duedate.getMonth()+duedate.getFullYear()).append(event_details_row);
                        appended_upcoming_events.push(row.linkid);
                    }
                    
                });
                
            }else{
                event_row=$('<ul><li>There are no events to display.</li></ul>');
            }
            
            //hide preloader
            $('#calendar-upcoming-preloader').hide();
            $('#calendar-upcoming-events-list').append(event_row);
            
            $('#calendar-dropdown-select').removeAttr('disabled');

            $('#calendar-select').show();
            
            /* this is the last call, enable controls then*/
            $('.ffcalendar-current').find('.fc-header-right .fc-button-next').removeClass('fc-state-disabled');
            $('.ffcalendar-current').find('.fc-header-left .fc-button-prev').removeClass('fc-state-disabled');
            $('#ffoffice-calendar-widget').find('.fc-header-right .fc-button-next').removeClass('fc-state-disabled');
            $('#ffoffice-calendar-widget').find('.fc-header-left .fc-button-prev').removeClass('fc-state-disabled');
        }
    },
    
    scheduled_events : {
        preloader : $(
            '<div id="scheduled-events-preloader">'
            +'<span>Loading Scheduled Events  <img src="/assets/images/preloader2.gif"></span>'
            +'</div>'
        ),
            
        scheduled_actions : [],    
        
        init : function(){
            var scheduled_events = this;
            this.get_scheduled_events();
            
            //test refresh
            /*$('#left-sidebar-sched-drop a').click(function(){
                console.log('refresh schedule');
                scheduled_events.refresh_schedule_list();
            })*/
        },
        
        refresh_schedule_list : function(){
            var scheduled_events = this;
            $('#left-sidebar-sched-content').html(scheduled_events.preloader);
            //scheduled_events.get_scheduled_events();   
            X4HCalendar.calendar_index = 'schedule-widget';
            X4HCalendar.get_events_by_category(27);
            X4HCalendar.scheduled_event_hasLoaded = false;
        },
        
        get_scheduled_events : function(){
            var scheduled_events = this;
            var today = new Date();
            var sched_item = '';
            X4HCalendar.today = $.datepicker.formatDate('dd/mm/yy', today);
            
            if(X4HCalendar.event_actions.length!==0){
                $.each(X4HCalendar.event_actions, function(key,action){
                    var action_date = $.datepicker.formatDate('dd/mm/yy', new Date(action.duedate));
                    if(action_date==X4HCalendar.today){
                        scheduled_events.scheduled_actions.push(action);
                        
                        
                        var sched_hours = parseInt(action.totaltimehrs);
                        
                        var sched_time = X4HCalendar.get_time_from_date(new Date(action.duedatetime));
                        
                        var sched_minutes = (action.totaltimemin=='')?0:parseInt(action.totaltimemin);
                        
                        //get event duration
                        var r = (sched_minutes)/60;
                        var h = Math.floor(r); 
                        var m = (sched_minutes) - (h * 60); 
                        if (m < 10){
                             m = "0" + m; 
                        }
                        
                        var sched_duration = h+' hr'+' '+m+' min';
                         
                        //var sched_duration = sched_hours+' hr'+' '+sched_minutes+' min';
                        //console.log(sched_time+":"+h+":"+sched_minutes)
                        if(sched_time=='12:00 am'&&(h==0||h>23)&&sched_minutes==0){
                            sched_time = 'All day';
                            sched_duration = '';
                        }
                        
                        sched_item +='<a class="sched-latest" href="javascript:void(0);" id="sched-'+action.linkid+'">'
                        +'  <span id="sched-time">'+sched_time+'</span>'
                        +'  <span id="sched-details">'+action.actionreference+'</span>'
                        +'  <span id="sched-length">'+sched_duration+'</span>'
                        +'</a>';
                
                    }
                });
            }
            
            if(this.scheduled_actions.length>0){
                $('#left-sidebar-sched-content').html($(sched_item)); 
                
                //bind the sched to load event details
                $.each($('.sched-latest'),function(key,elem){
                   $(elem).click(function(){
                     var event_id = myappmaster.find_id($(elem).attr('id'));
                     //console.log(event_id);  
                     $('#middle-nav').tabs('select','#tab-calendar');
                     $('#calendar-nav').find('.eventDetails').parent().show();
                     $('#calendar-items').dialog('close');
                     $('#eventDetails').find('.event-details-row').hide();
                     $('#cancel-invite').hide();
                     $('#back-to-calendar').hide();
                     $('#preloader-event-details').show();
                     $('.event-attendees').hide();
                     $('#event-attendees-footer').hide();
                     $('#calendar-nav').tabs('select','#eventDetails');
                     X4HCalendar.search_event(event_id, 'show_event_details',{calendar_index:'personal'});
                   });
                });
                
            }else{
               var no_sched = $(
               '<span id="scheduled-events-no-content">There are no scheduled items to display.</span>'
               );
               $('#left-sidebar-sched-content').html(no_sched); 
            }
        }
        
    },
	
	show_todo_popup : function(jsEvent, todo_id)
	{
		if(todo_id == undefined)
		{
			$('.todo-form-row input').val('');
			$('.todo-save').attr('id','');
		}
		else
		{
			$('.todo-save').attr('id','thistodo-' + todo_id);
			$('#field-todo-title').val($('.todo-details-' + todo_id).children('.todo-title').text());
			$('#field-todo-status').val($('.todo-details-' + todo_id).children('.todo-status').text());
			$('#field-todo-due-date').val($('.todo-details-' + todo_id).children('.todo-date').text());
			$('#field-todo-reassign').val($('.todo-details-' + todo_id).children('.todo-actionby').text());
			$('#todo-date-created').text($('.todo-details-' + todo_id).children('.todo-created').text());
			//$('#todo-date-completed').text($('.todo-details-' + todo_id).children('.todo-actionby').text());
		}
		$('.todo-save').button({
		text: false,
			icons: {
				primary: "ui-icon-disk"
			},
			label: "Save"
		});
		var scrollTop = $(window).scrollTop();
        var scrollLeft = $(window).scrollLeft();
        var elemX = jsEvent.pageX-scrollLeft;
        var elemY = jsEvent.pageY-scrollTop;
        
        $( '#todo-items' ).dialog({
                resizable: false,
                height: 220,
				title: 'To Do',
                width: 300,
                stack: false,
                position : [elemX,elemY],
                dialogClass : 'todo-popup',
                draggable : false      
        });
	
	},
	
	load_todo : function()
	{
		var d = new Date();
		var sTodayString = $.fullCalendar.formatDate(d, 'dd/MM/yyyy') + ' ' + $.fullCalendar.formatDate(d, "HH:mm");
		d.setTime(d.getTime()-(2*86400000)); // 2days
		var sTwoDaysAgoString = $.fullCalendar.formatDate(d, 'dd/MM/yyyy') + ' ' + $.fullCalendar.formatDate(d, "HH:mm");
		d.setTime(d.getTime()-(4*86400000)); // 4days ago
		var sSixDaysAgoString = $.fullCalendar.formatDate(d, 'dd/MM/yyyy') + ' ' + $.fullCalendar.formatDate(d, "HH:mm");
		var filters = 
					[
						//Finds the actions completed within the past two days that belong to the contactperson logged in
					   {name:'(',comparison:'',value1: '', value2: ''},
					   {name:'actiontype',comparison:'EQUAL_TO',value1: '991', value2: ''}, 
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'contactperson',comparison:'EQUAL_TO',value1: X4HUser.contact_person, value2: ''},
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'status',comparison:'EQUAL_TO',value1: '1', value2: ''},
					   {name:'and',comparison:'',value1: '', value2: ''},
					   {name:'completed',comparison:'BETWEEN',value1: sTwoDaysAgoString, value2: sTodayString},
					   {name:')',comparison:'',value1: '', value2: ''},
					   
					   {name:'or',comparison:'',value1: '', value2: ''},
					   
					   //Find the actions that I have assigned, that have been modified in the last 6 days
					   {name:'(',comparison:'',value1: '', value2: ''},
					   {name:'actiontype',comparison:'EQUAL_TO',value1: '991', value2: ''}, 
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'contactperson',comparison:'EQUAL_TO',value1: X4HUser.contact_person, value2: ''},
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'actionby',comparison:'NOT_EQUAL_TO',value1: X4HUser.id, value2: ''},
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'modifieddate',comparison:'BETWEEN',value1: sSixDaysAgoString, value2: sTodayString},
					   {name:')',comparison:'',value1: '', value2: ''},
					   
					   {name:'or',comparison:'',value1: '', value2: ''},
					   
					   //Find the actions that have been assigned to me by others
					   {name:'(',comparison:'',value1: '', value2: ''},
					   {name:'actiontype',comparison:'EQUAL_TO',value1: '991', value2: ''}, 
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'actionby',comparison:'EQUAL_TO',value1: X4HUser.id, value2: ''},
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'contactperson',comparison:'NOT_EQUAL_TO',value1: X4HUser.contact_person, value2: ''},
					   {name:')',comparison:'',value1: '', value2: ''},
					   
					   {name:'or',comparison:'',value1: '', value2: ''},
					   
					   //Find the actions I have assigned to myself which are inprogress
					   {name:'(',comparison:'',value1: '', value2: ''},
					   {name:'actiontype',comparison:'EQUAL_TO',value1: '991', value2: ''}, 
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'actionby',comparison:'EQUAL_TO',value1: X4HUser.id, value2: ''},
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'contactperson',comparison:'EQUAL_TO',value1: X4HUser.contact_person, value2: ''},
					   {name:'and',comparison:'',value1: '', value2: ''}, 
					   {name:'status',comparison:'EQUAL_TO',value1: '4', value2: ''},
					   {name:')',comparison:'',value1: '', value2: ''}
					];
		var fields = ['actionreference', 'contactperson', 'sq6975', 'contactpersontext', 'completed', 'completedtime', 'actionby', 'actionbytext', 'duedatetime', 'duedate', 'createddate', 'createduser', 'createdusertext', 'status'];
		var sort = [{name:'duedatetime',direction:'asc'}];
		var oXML = new X4HASearch(fields, filters,'', sort).getXML();
			
		x4hubProxy.call(
			[X4HCalendar, 'load_todo_response'],
			'/ondemand/action/?method=ACTION_SEARCH',
			{
				advanced: 1,
				data: oXML,
				rows: '30'
			}
		);
	},
	
	load_todo_response : function(response)
	{
		var aAssignedHTML = [];
		console.log('Search To Do');
		var aHTML = [];
		var aNoDueDate = [];
		//Check if there are any to-do's returned
		if(response.data.rows.length > 0) {
		    $.each(response.data.rows, function(key, row) {
				if(this.status == '1')
				{
					var sClass = 'todo-item-title-done';
					var sDue = 'Completed: ' + this.completed;
					var sOptions = '';
				}
				else
				{
					var sClass = 'todo-item-title-text';
					var sDue = 'Due: ' + this.duedate;
					var sOptions = '<div class="todo-item-drop" id="todooptions-' + this.id + '"><a href="#"><img src="/assets/images/drop03.png"></a></div>';
				}
				
				var sColor = 'style="background-color: ' + this.sq6975 + '"';
				
				//This action does not belong to me but I have assigned it to someone and they are yet to accept/reject	
				if(this.actionby != X4HUser.id && this.status == '2')
				{
					aAssignedHTML.push('<div class="todo-item assigned-todo-waiting assigned-todo-format"' + sColor + '>'
											+ '<div class="todo-item-title assigned-title">'
											+ '<div class="todo-assignee">'
											+ '<div class="assigned-icon"><img title="Awaiting Acknowledgement" src="/assets/images/flag01.png"></div>'
											+ '<span title="Due: '+ this.duedate +'" class="todo-item-title-pending">' + this.actionbytext + '</span>'
											+ sOptions
											+ '</div>'
											+'<div class="todo-assigner-title">'
											+ '<span title="Due: '+ this.duedate +'" class="todo-item-title-pending">' + this.actionreference + '</span>'
											+ '</div>'
											+'</div>'
										+ '</div>');
				}
				
				//This action does not belong to me but I have assigned it to someone and they have accepted
				if(this.actionby != X4HUser.id && this.status == '4')
				{
					aAssignedHTML.push('<div class="todo-item assigned-todo-format"' + sColor + '>'
											+ '<div class="todo-item-title assigned-title">'
											+ '<div class="todo-assignee">'
											+ '<div class="assigned-icon"><img title="Accepted" src="/assets/images/bubble01.png"></div>'
											+ '<span title="Due: ' + this.duedate + '" class="todo-item-title-accepted">' + this.actionbytext + '</span>'
											+'</div>'
											+'<div class="todo-assigner-title">'
											+ '<span title="Due: '+ this.duedate +'" class="todo-item-title-accepted">' + this.actionreference + '</span>'
											+ '</div>'
											+ '<div class="todo-item-drop">'
											+ '</div>'
											+'</div>'
										+ '</div>');
				}
				
				//This action does not belong to me but I have assigned it to someone and they have rejected
				if(this.actionby != X4HUser.id && this.status == '3')
				{
					aAssignedHTML.push('<div class="todo-item assigned-todo-format"' + sColor + '>'
											+ '<div class="todo-item-title assigned-title">'
											+ '<div class="todo-assignee">'
											+ '<div class="assigned-icon"><img title="To Do Rejected" src="/assets/images/close01.png"></div>'
											+ '<span title="Due: ' + this.duedate + '" class="todo-item-title-rejected">' + this.actionbytext + '</span>'
											+'</div>'
											+'<div class="todo-assigner-title">'
											+ '<span title="Due: '+ this.duedate +'" class="todo-item-title-rejected">' + this.actionreference + '</span>'
											+ '</div>'
											+ '<div class="todo-item-drop">'
											+ '</div>'
											+'</div>'
										+ '</div>');
				}
				
				//This action does not belong to me but I have assigned it to someone and they have completed
				if(this.actionby != X4HUser.id && this.status == '1')
				{
					aAssignedHTML.push('<div class="todo-item assigned-todo-format"' + sColor + '>'
											+ '<div class="todo-item-title assigned-title">'
											+ '<div class="todo-assignee">'
											+ '<div class="assigned-icon"><img title="Completed" src="/assets/images/bubble02.png"></div>'
											+ '<span title="Completed: ' + this.completed + '" class="todo-item-title-completed">' + this.actionbytext + '</span>'
											+'</div>'
											+'<div class="todo-assigner-title">'
											+ '<span title="Completed: '+ this.completed +'" class="todo-item-title-completed">' + this.actionreference + '</span>'
											+ '</div>'
											+ '<div class="todo-item-drop">'
											+ '</div>'
											+'</div>'
										+ '</div>');
				}
				
				//This action has been assigned to me by another first folian but I have not acknowledged
				if(this.actionby == X4HUser.id && this.contactperson != X4HUser.contact_person && this.status == '2')
				{
					var sRowString = '<div class="todo-item assigned-todo"' + sColor + '>'
									+ '<div class="todo-details-' + this.id + '" style="display:none;">'
									+ '<span class="todo-title">' + this.actionreference + '</span>'
									+ '<span class="todo-date">' + this.duedate + '</span>'
									+ '<span class="todo-actionby">' + this.actionby + '</span>'
									+ '<span class="todo-status">' + this.status + '</span>'
									+ '<span class="todo-created">' + this.createddate + '</span>'
									+ '</div>'
									+ '<div class="todo-item-title">'
									+	'<img src="/assets/images/alert01.png" title="Pending Action"/>'
									+		'<span class="todo-item-title-assigned" title="' +  this.contactpersontext + ', Due: ' + this.duedate + '">' + this.actionreference + '</span>'
									+			'<div class="todo-item-response">'
									+				'<a href="#"><img class="accepttodobutton" id="accepttodo-' + this.id + '" src="/assets/images/plus-img01.png" title="Accept To Do"/></a>'
									+ 			'</div>'
									+			'<div class="todo-item-response">'
									+				'<a href="#"><img class="rejecttodobutton" id="rejecttodo-' + this.id + '" src="/assets/images/close01.png " title="Reject To Do"/></a>'
									+			'</div>'
									+ '</div>'
									+ '</div>'
				}
				
				//This action has been assigned to me by another first folian and I have acknowleged, I have accepted
				if(this.actionby == X4HUser.id && this.contactperson != X4HUser.contact_person && this.status == '4')
				{
					var sRowString = '<div class="todo-item assigned-todo"' + sColor + '>'
									+ '<div class="todo-details-' + this.id + '" style="display:none;">'
									+ '<span class="todo-title">' + this.actionreference + '</span>'
									+ '<span class="todo-date">' + this.duedate + '</span>'
									+ '<span class="todo-actionby">' + this.actionby + '</span>'
									+ '<span class="todo-status">' + this.status + '</span>'
									+ '<span class="todo-created">' + this.createddate + '</span>'
									+ '</div>'
									+ '<div class="todo-item-title">'
									+	'<img src="/assets/images/bubble01.png" title="Accepted"/>'
									+		'<span class="todo-item-title-accepted" title="' + this.contactpersontext + ', Due: ' + this.duedate + '">' + this.actionreference + '</span>'
									+ sOptions
									+ '</div>'
									+ '</div>'
				}
				
				//This action has been assigned to me by another first folian and I have acknowleged, I have accepted, I have Completed
				if(this.actionby == X4HUser.id && this.contactperson != X4HUser.contact_person && this.status == '1')
				{
					var sRowString = '<div class="todo-item assigned-todo"' + sColor + '>'
									+ '<div class="todo-details-' + this.id + '" style="display:none;">'
									+ '<span class="todo-title">' + this.actionreference + '</span>'
									+ '<span class="todo-date">' + this.duedate + '</span>'
									+ '<span class="todo-actionby">' + this.actionby + '</span>'
									+ '<span class="todo-status">' + this.status + '</span>'
									+ '<span class="todo-created">' + this.createddate + '</span>'
									+ '</div>'
									+ '<div class="todo-item-title">'
									+	'<img src="/assets/images/bubble02.png" title="Completed"/>'
									+		'<span class="todo-item-title-completed" title="' + this.contactpersontext + ', Completed: ' + this.completed + '">' + this.actionreference + '</span>'
									+ '<div class="todo-item-drop">'
									+ '</div>'
									+ '</div>'
									+ '</div>'
				}
				
				//This action belongs to me and only me, I wrote the cheque and cashed it!
				if(this.actionby == X4HUser.id && this.contactperson == X4HUser.contact_person)
				{
					var sRowString = '<div class="todo-item"' + sColor + '>'
									+ '<div class="todo-details-' + this.id + '" style="display:none;">'
									+ '<span class="todo-title">' + this.actionreference + '</span>'
									+ '<span class="todo-date">' + this.duedate + '</span>'
									+ '<span class="todo-actionby">' + this.actionby + '</span>'
									+ '<span class="todo-status">' + this.status + '</span>'
									+ '<span class="todo-created">' + this.createddate + '</span>'
									+ '</div>'
									+ '<div class="todo-item-title">'
									+	'<span class="' + sClass + '" id="todo-' + this.id + '" title="' + sDue + '">' + this.actionreference + '</span>'
									+ sOptions
									+ '</div>'
									+ '</div>'
				}
				
				
				if(this.duedate == '')
				{
					aNoDueDate.push(sRowString);
				}
				else
				{
					aHTML.push(sRowString);
				}
			});
		}
		else
		{
			aHTML.push('<div class="todo-item">' 
							+ '<div class="todo-item-title">'
							+	'<span class="todo-item-title-text">Nothing To Do</span>'
							+ '</div>'
							+ '</div>');
		}
		$('#birthday-events-preloader').remove();
		$('.todo-items-container').html(aHTML.join('') + aNoDueDate.join(''));
		$('.todo-items-assigned-container').html(aAssignedHTML.join(''));
		this.bind_todo_elements();
	},
	
	bind_todo_links : function()
	{
		//Bind Add To Do Link
		$('body').delegate('#create-new-item', 'click', function(event) {
			event.preventDefault();
			X4HUser.manager = X4HUser.id;
			X4HUser.search_users('search_users_return','field-todo-reassign');
			
			X4HCalendar.show_todo_popup(event);
		});
		
		//Bind Accept To Do
		$('body').delegate('.accepttodobutton', 'click', function(event) {
			event.preventDefault();
			var todo = new Object();
			if(myappmaster.find_id($(this).attr('id')) != undefined)
			{
				todo.id = myappmaster.find_id($(this).attr('id'));
				todo.actionstatus = '4'; // In progress
				X4HCalendar.save_todo(todo);
			}
			else
			{
				//No ID on the to do
				alert('no id');
			}
		});
		
		//Bind Reject To Do
		$('body').delegate('.rejecttodobutton', 'click', function(event) {
			event.preventDefault();
			var todo = new Object();
			if(myappmaster.find_id($(this).attr('id')) != undefined)
			{
				todo.id = myappmaster.find_id($(this).attr('id'));
				todo.actionstatus = '3'; // Cancelled
				X4HCalendar.save_todo(todo);
			}
			else
			{
				//No ID on the to do
				alert('no id');
			}
		});
		
		//Bind To Do Click
		$('.todo-save').click(function(event)
		{
			var todo = new Object();
			if(myappmaster.find_id($(this).attr('id')) != undefined)
			{
				todo.id = myappmaster.find_id($(this).attr('id'));
			}
			todo.subject = $('#field-todo-title').val();
			todo.date = $('#field-todo-due-date').val();
			
			if(X4HUser.id != $('#field-todo-reassign').val())
			{
				//This is being assigned to another
				todo.actionby = $('#field-todo-reassign').val();
				//Not Started as its pending approval, or rejection
				todo.actionstatus = '2';
			}
			else
			{
				todo.actionstatus = $('#field-todo-status').val();
			}
			todo.contactperson = X4HUser.contact_person;
			todo.actiontype = '991';
			
			X4HCalendar.save_todo(todo);
		});
		
		
	},
	
	save_todo : function(todo)
	{
		x4hubProxy.call(
			[X4HCalendar, 'save_todo_response'],
			'/ondemand/action/?method=ACTION_MANAGE',
			todo
		);
	},
	
	save_todo_response : function(response)
	{
		$( '#todo-items' ).dialog( "close" );
		this.load_todo();
	},
	
	show_todo_options : function(jsEvent, todo_id, todo_type)
	{
		var sHeight = '150';
		$('.todo-option-select').hide();
		if(todo_type == 'assigned')
		{
			$('.todo-option-select, .todo-color-select').hide();
			$('.todo-completed, .todo-cancel').show();
			var sHeight = '50';
		}
		else if(todo_type == 'assigned-waiting')
		{
			$('.todo-option-select, .todo-color-select').hide();
			$('.todo-cancel').show();
			var sHeight = '50';
		}
		else
		{	
			$('.todo-option-select, .todo-color-select').show();
			$('.todo-cancel').hide();		
		}
		var scrollTop = $(window).scrollTop();
        var scrollLeft = $(window).scrollLeft();
        var elemX = jsEvent.pageX-scrollLeft;
        var elemY = jsEvent.pageY-scrollTop;
        
        $( '#todo-options' ).dialog({
			open: function(event, ui) { 
				//Bind
				$('#todo-options').unbind().mouseleave(function(event)
				{
					setTimeout(function() 
					{
						$( '#todo-options' ).dialog( 'close');
					}, 1000);
				});
			},
            resizable: false,
            height: sHeight,
			width: 80,
            stack: false,
            position : [elemX,elemY],
            dialogClass : 'todo-popup',
            draggable : false      
        });
		$('#todo-options').prev('.ui-dialog-titlebar').hide();
		$('#todo-options').css('width', '');
		$('#todo-options').css('height', '');
		
		//Bind Options Select
		$('.todo-option-select').unbind().click(function(event)
		{
			var todo = new Object();
			if($(this).hasClass('todo-completed'))
			{
				var d = new Date();
				todo.id = todo_id;
				todo.status = 1;
				todo.se6975 = 'white;';
				//Pass the completed date too
				todo.completeddate = $.fullCalendar.formatDate(d, "dd/MM/yyyy");
				
				X4HCalendar.save_todo(todo);
				$( '#todo-options' ).dialog( "close" );
			}
			if($(this).hasClass('todo-assign'))
			{
			
			}
			if($(this).hasClass('todo-postpone'))
			{
			
			}
			if($(this).hasClass('todo-setalert'))
			{
			
			}
			if($(this).hasClass('todo-delete'))
			{
				todo.id = todo_id;
				todo.actionstatus = 3;
				X4HCalendar.save_todo(todo);
				$( '#todo-options' ).dialog( "close" );
			}
			if($(this).hasClass('todo-cancel'))
			{
				todo.id = todo_id;
				todo.actionstatus = 3;
				X4HCalendar.save_todo(todo);
				$( '#todo-options' ).dialog( "close" );
			}
		});
		
		$('.todo-color-size').unbind().click(function(event)
		{
			var todo = new Object();
			todo.id = todo_id;
			todo.se6975 = $(this).css('background-color');
		
			X4HCalendar.save_todo(todo);
		});
	},
	
	bind_todo_elements : function()
	{
		//Bind To Do Click
		$('.todo-item-drop').unbind().click(function(event)
		{
			event.preventDefault();
			var todo_id = myappmaster.find_id($(this).attr('id'));
			if($(this).parents('.todo-item').hasClass('assigned-todo'))
			{
				var todo_type = 'assigned';
			}
			else if($(this).parents('.todo-item').hasClass('assigned-todo-waiting'))
			{
				var todo_type = 'assigned-waiting';
			}
			else
			{
				var todo_type = '';
			}
			//Show the drop down
			X4HCalendar.show_todo_options(event, todo_id, todo_type);
		});
		
		$('.todo-item-title-text').unbind().click(function(event)
		{
			var todo_id = myappmaster.find_id($(this).attr('id'));
			X4HCalendar.show_todo_popup(event, todo_id);
		});
	},
        
        search_my_events : {
            
            search_string : null,
            
            init : function(){
                var search_my_events = this;
                
                /* bind the search button once */
                if($('#calendar-search a').data('events')==undefined){
                    
                    $('#calendar-search a').click(function(){
                        console.log('search my calendar events');
                        search_my_events.search_string = $('#calendar-search input').val();
                        search_my_events.add_event_list_tab();
                        search_my_events.search();
                    });
                }
            },
            
            add_event_list_tab : function(){
                
                var header = $(
                    '<div id="tab-calendar-header">'
                    
                    +    '<h1>Events list</h1>'
                    +'</div>' 
                );
                    
                var content = $(
                    '<div id="my-event-list" class="tabbed-content-body">'
                    +'</div>'    
                );
                    
                var footer = $(
                    '<div id="my-event-list-footer">'
                    +'<div id="my-event-list-pagination" class="pagination-area"></div>'
                    +'</div>'
                );
                    
                var preloader = $(
                    '<div class="preloader-communications-list">'
                    +'    <span><img src="/assets/images/preloader.gif" /><br  />loading events</span>'
                    +'</div>'
                );    
            
                
                if($( "#calendar-nav").find('a[href=#eventsList]').length==0){
                    $('#calendar-nav').tabs("add","#eventsList","Events List");
                    
                    var event_list_panel = $('#calendar-nav').find("#eventsList");
                    
                    event_list_panel.addClass("tabbed-section");
                    
                    $('#calendar-panel').append(event_list_panel);
                    
                    event_list_panel.append(header);

                    event_list_panel.append(content);
                    
                    event_list_panel.append(footer);
                    
                }
                /* add preloader */
                $('#my-event-list').html(preloader);
                
                $('#calendar-nav').tabs('select', "#eventsList");
            },
            search : function(){
                var search_my_events = this;
                var accepted_event_array = [];
                var event_id_array = [];
                
                $.each(X4HCalendar['events_array_personal'],function(key,val){
                    event_id_array.push(val.event);
                });
                
                if(X4HCalendar.my_attended_events!==null){
                    $.each(X4HCalendar.my_attended_events,function(key,val){
                        //params.event_id_array.push(val.event);
                        accepted_event_array.push(val.event);
                    });
                }
                
                /* action filter */
                var filters = [
                    {
                        name : 'LinkId',
                        comparison : 'IN_LIST',
                        value1 : event_id_array
                    },
                    {
                        name : 'LinkType',
                        comparison : 'EQUAL_TO',
                        value1 : 39

                    },
                
                    {
                        name : 'ActionBy',
                        comparison : 'EQUAL_TO',
                        value1 : X4HUser.contact_person

                    },
                    {
                        name : 'ActionReference',
                        comparison : 'TEXT_IS_LIKE',
                        value1 : search_my_events.search_string

                    },
                
                    {
                        name : 'or',
                        comparison : '',
                        value1 : ''
                    },
                
                    {
                        name : 'LinkId',
                        comparison : 'IN_LIST',
                        value1 : accepted_event_array
                    },
                
                    {
                        name : 'LinkType',
                        comparison : 'EQUAL_TO',
                        value1 : 39

                    },
                
                    {
                        name : 'ActionBy',
                        comparison : 'EQUAL_TO',
                        value1 : X4HUser.contact_person

                    },
                    {
                        name : 'ActionReference',
                        comparison : 'TEXT_IS_LIKE',
                        value1 : search_my_events.search_string

                    },
                    
                ];
                
                X4HCalendar.get_event_actions(null, {
                    filters : filters,
                    callBackObj : search_my_events,
                    callBack : 'search_response'
                })
            },
            
            search_response : function(response){
                if(response.data.rows.length > 0){
                    
                    X4HCalendar.event_actions = response.data.rows;
                    //console.log(X4HCalendar.event_actions)
                    var header = $(
                        '<div class="event-list-row event-list-row-header">'
                        +'  <div class="event-list-label-title"><strong>Event Title</strong></div>'
                        /*+'  <div class="event-list-label-description"><strong>Event Description</strong></div>'*/
                        +'  <div class="event-list-label-date"><strong>Event Date</strong></div>'
                        +'</div>'
                    );
                    
                    $('#my-event-list').html(header);
                    
                    //var event_row = '';
                    
                    $.each(response.data.rows, function(key,event){
                        
                        var rowClass = ((key==0)?'data-top':'');
                        
                        var sched_hours = parseInt(event.totaltimehrs);
                        
                        var sched_time = X4HCalendar.get_time_from_date(new Date(event.duedatetime));
                        
                        var sched_minutes = (event.totaltimemin=='')?0:parseInt(event.totaltimemin);
                        
                        //get event duration
                        var r = (sched_minutes)/60;
                        var h = Math.floor(r); 
                        var m = (sched_minutes) - (h * 60); 
                        if (m < 10){
                             m = "0" + m; 
                        }
                        
                        if(sched_time=='12:00 am'&&(h==0||h>23)&&sched_minutes==0){
                            sched_time = 'All day';
                        }
                        
                        var event_row=$('<div class="event-list-row event-list-row-data '+rowClass+'" id="event-row-'+event.linkid+'">'
                        +'  <div class="event-list-label-title">'+((event.actionreference=='')?'&nbsp;':event.actionreference)+'</div>'
                        
                        +'  <div class="event-list-label-date">'+event.duedate+' - '+sched_time+'</div>'
                        +'</div>');
                    
                    $('#my-event-list').append(event_row);
                    
                    
                    
                    });
                    
                    /* Bind the result after */
                    $.each($('.event-list-row-data'),function(key,elem){
                        $(elem).click(function(){
                            var event_id = myappmaster.find_id($(elem).attr('id'));
                            //console.log(event_id);
                           $('#calendar-nav').find('.eventDetails').parent().show();
                           $('#calendar-items').dialog('close');
                           $('#eventDetails').find('.event-details-row').hide();
                           $('#cancel-invite').hide();
                           $('#back-to-calendar').hide();
                           $('#preloader-event-details').show();
                           $('.event-attendees').hide();
                           $('#event-attendees-footer').hide();
                           $('#calendar-nav').find('.eventDetails').trigger('click');
                           X4HCalendar.search_event(event_id, 'show_event_details',{calendar_index:'personal'});
                        })
                    });
                    
                        
                }else{
                    $('#my-event-list').html('<p>Your search returned no result.</p>');
                }
                
                /* Enable widget controls */
                $('#ffoffice-calendar-widget').find('.fc-header-right .fc-button-next').removeClass('fc-state-disabled');
                $('#ffoffice-calendar-widget').find('.fc-header-left .fc-button-prev').removeClass('fc-state-disabled');
            }
            
        },
        
        /* Firstfolio Corporate (29) */
        corporate_events : {
            init : function(){
                this.get_corporate_events();
            },
            
            get_corporate_events : function(){
                x4hubProxy.call(
                    [this,'get_corporate_events_response'],
                    '/ondemand/event/?method=EVENT_CATEGORY_SEARCH',
                    {

                       category : 29, //Firstfolio Corporate
                       rows: 1000
                    }
                );
            },
            
            get_corporate_events_response : function(response){
                var upcoming_events = [];
                
                if(response.data.rows.length>0){
                    $.each(response.data.rows,function(key,val){
                        upcoming_events.push(val.event);
                    });
                }else{
                    upcoming_events = [0];
                }
                
                this.load_corporate_upcoming_events(upcoming_events);
            },
            
            load_corporate_upcoming_events : function(upcoming_events){
                /* search actions */
                var event_id_array = upcoming_events;
                
                var filters = [
                    {
                        name : 'LinkId',
                        comparison : 'IN_LIST',
                        value1 : event_id_array
                    },
                    {
                        name : 'DueDate',
                        comparison : 'GREATER_THAN',
                        value1 : $.datepicker.formatDate('dd/mm/yy', new Date()) //today
                        

                    },
                    {
                        name : 'LinkType',
                        comparison : 'EQUAL_TO',
                        value1 : 39

                    },
                    
                ];
                
                var oXML = new X4HASearch(X4HCalendar.defaultActionFields, filters, null, X4HCalendar.defaultActionSort).getXML();
            
        
                x4hubProxy.call(
                    [this,'load_corporate_upcoming_events_response'],
                    '/ondemand/action/?method=ACTION_SEARCH',
                    {
                        advanced:1,
                        data : oXML,
                        rows:1000

                    }
                );
            },
            
            load_corporate_upcoming_events_response : function(response){
                if(response.data.rows.length>0){
                    X4HCalendar.corporate_upcoming_actions = {};
                    $.each(response.data.rows,function(key,row){
                        var sched_hours = parseInt(row.totaltimehrs);
                        
                        var sched_time = X4HCalendar.get_time_from_date(new Date(row.duedatetime));
                        
                        var sched_minutes = (row.totaltimemin=='')?0:parseInt(row.totaltimemin);
                        
                        //get event duration
                        var r = (sched_minutes)/60;
                        var h = Math.floor(r); 
                        var m = (sched_minutes) - (h * 60); 
                        if (m < 10){
                             m = "0" + m; 
                        }
                        
                        if(sched_time=='12:00 am'&&(h==0||h>23)&&sched_minutes==0){
                            sched_time = 'All day';
                        }
                        
                        var upcoming_event = $(
                            '<tr id="corporate-upcoming-event-'+row.linkid+'" class="corporate-upcoming-event">'
                            +'<td id="events-date">'+row.duedate+'</td>'
                            //+'<td id="events-time">'+sched_time+'</td>'
                            +'<td ><span>'+row.actionreference+'</span></td>'
                            +'</tr>'
                        );
                            
                        $('#corporate-upcoming-events').append(upcoming_event);
                        X4HCalendar.corporate_upcoming_actions[row.linkid]=row;
                    });
                    
                }else{
                    $('#corporate-upcoming-events').html(
                        '<tr><td style="padding-left:10px;">There are no upcoming events.</td></tr>'
                    )
                }
                
                /* bind triggers */
                $.each($('.corporate-upcoming-event'),function(key,elem){
                        $(elem).unbind('click').click(function(){
                           var event_id = myappmaster.find_id($(elem).attr('id'));
                            
                           $('#middle-nav').tabs('select', '#tab-calendar'); 
                           $('#calendar-nav').find('.eventDetails').parent().show();
                           $('#calendar-items').dialog('close');
                           $('#eventDetails').find('.event-details-row').hide();
                           $('#cancel-invite').hide();
                           $('#back-to-calendar').hide();
                           $('#preloader-event-details').show();
                           $('.event-attendees').hide();
                           $('#event-attendees-footer').hide();
                           $('#calendar-nav').find('.eventDetails').trigger('click');
                           
                           X4HCalendar.search_event(event_id, 'show_event_details',{calendar_index:'shared'});
                        });
                });
            }
            
        },
        
        /* will calculate for date duration in minutes */
        get_date_duration : function(options){
            var startdate = new Date(options.startdate);
            var enddate   = new Date(options.enddate);
            
            var timediff = Math.abs(enddate.getTime()-startdate.getTime());
            
            if(options.format=='ss'){
                return timediff/1000;
            }else if(options.format=='MM'){
                return (timediff/1000)/60
            }
        }
        
        
        
}