var x4hubProxy = {
    // Variables
    site_id: 1320,
	site_url: 'https://firstfolio-test.1blankspace.com',
    //site_url: 'https://beta.1blankspace.com',
    proxy_host: '/proxy/',
    displayName: null,    
    ff_one_id: 1,
    sid: 0,
    user: 0,
    
    error_handler: function() {
        alert('Issue connecting to X4Hub');
    },
    save_cookie: function(sid, user) {
        $.cookie('mds_sid', sid);
        $.cookie('mds_user', user);
        
        this.sid = sid;
        this.user = user;
    },
    check_cookie: function(ff_user_id) {
        if(ff_user_id == null || ff_user_id == "") {
            alert("Please specify ")
        }        
        x4hub = this;
        x4hub.ff_one_id = ff_user_id;
        x4hub.sid = $.cookie('mds_sid');
        x4hub.user = $.cookie('mds_user');
        
        var uri = 'http://firstfolio-test.1blankspace.com/ondemand/core/?method=CORE_GET_USER_DETAILS';
        $.getJSON(
            this.proxy_host,
            {
                target: uri,
                ff_one_id: x4hub.ff_one_id,
                sid: x4hub.sid
            },
            function(data) {
                if(data == null || data == '') {
                    this.error_handler();
                } else {
                    // Ok - we got something to process
                    if( (data.status == 'OK') && ('userlogonname' in data) ) {
                        $('.progressbar-loading').progressbar("option","value", 15);
                        $('.state-loading').text('Loading Messaging Accounts');
                        
                        //Show the Loading Screen with the updates on load of dash
			myappmaster.init_dashboard(data);
                        
                        /* notification handler */
                        pollHandler.init({target_element: document.body});
                        
                    } else {
                        // Show login Screen
                        myappmaster.init_login();
                    }
                }
            }
        );
        
    },
    login: function(username, password) {
        $('#interfaceMasterLogonStatus').html("");
        if(username == '' || username == null) {
            $('#interfaceMasterLogonStatus').html("Please enter a username");
            $('.preloader-login').hide();
            return false;
        }
        
        if(password == '' || password == null) {
            $('#interfaceMasterLogonStatus').html("Please enter a password");
            $('.preloader-login').hide();
            return false;
        }
        
        
        x4hub = this;
        $.getJSON(
            this.proxy_host + '?target=http://firstfolio-test.1blankspace.com/ondemand/logon/',
            {
                logon: username, 
                password: password,
                ff_one_id: this.ff_one_id
            },
            function(data) {
                if( data.status == 'ER' ) {
                    // We have an error taking effecttime 
                    var errorMessage = '';
                    switch(data.error.errornotes) {
                        case 'LOGONFAILED': {
                            errorMessage = 'Invalid username and/or password';
                            break;
                        }
                        default: {
                            errorMessage = "Error: " + data.error.errornotes;
                            break;
                        }
                    }
                    $('#interfaceMasterLogonStatus').html(errorMessage);
                } else if( data.status = 'OK' ) {
                    if(data.passwordStatus == 'OK') {
                        // Log the user in
                        x4hub.save_cookie(data.sid, data.user)
                        document.location.reload();
                    }
                }
                $('.preloader-login').hide();
            }
        );
    },    
    logout: function()
    {
        x4hub = this;
        setTimeout(
            function() {
                var uri = 'http://firstfolio-test.1blankspace.com/ondemand/core/?method=CORE_LOGOFF';
                $.getJSON(
                    x4hub.proxy_host,
                    {
                        target: uri,
                        ff_one_id: x4hub.ff_one_id,
                        sid: x4hub.sid
                    },
                    function(data) {
                        if(data == null || data == '') {
                            x4hub.error_handler();
                        } else {
                            x4hub.sid = 0;
                            $.cookie('mds_sid', null);
                            $.cookie('mds_user', null);
                            document.location.reload();
                        }
                    }
                );
            },
            50
        );        
    },
    call: function(callback, uri, params) {        
        
        var callback_object = x4hubProxy;
        var callback_function = callback;
        
        if(params == null) {
            params = {};
        }
                
        var callback_object = this;
        var callback_function = callback;
        var callback_container = null;

            
        if( $.isArray(callback) ) {                
            callback_object = callback[0];
            callback_function = callback[1];
            if(callback.length == 3 ) {
                callback_container = callback[2];
            }
        } else {
            this.error_handler();
            return false;
        }
                
        
        // Add data to array if they don't exist
        if(params != null && params instanceof Object) {
            params.target = this.site_url + uri;
            params.ff_one_id = this.ff_one_id;
            params.sid = this.sid;
            params.site = this.site_id;
            
            if(params.rows == undefined) {
                params.rows = myappmaster.defaultRowCount;
            }

            /*
            if(params.startrow == undefined) {
                params.startrow = 0;
            }
            */
        }
        
        var data_format = 'json';
        if(params.data_format != null) {
            data_format = params.data_format;
            delete params.data_format;
        }
        
        
        
        x4hubProxy.start_loading();
        $.ajax({
            url: this.proxy_host,
            dataType: data_format,
            type: 'POST',
            data: params,
            success: function(data) {
                if(data == null || data == '') {
                    x4hubProxy.error_handler();
                    return false;
                }
                callback_object[callback_function](data, callback_container);
                
                //if(data.morerows == "true") {
                
				if(data.summary !== undefined && callback_container !== null && data.morerows == "true") {
					myappmaster.generate_pagination_links(callback_container, callback_object, callback_function, uri, params, data.rows, data.startrow, data.summary.auditcount);
                }
            },
            error: function(request, status, error) {
                console.log("Error in call");
                console.log("Status: " + status);
                console.log(error);
                console.log(request);
                
                if(status=='parsererror'){
                    //console.log(request.responseText)
                    var responseText = request.responseText;
                    if(responseText.search('No Access')!==-1){
                        //delete cookies and initialize
                        console.log('deleting cookies');
                        $.cookie('mds_sid', null);
                        $.cookie('mds_user', null);
                        //try to reload
                        document.location.reload();
                    }
                    
                }
            }
        });

    },
    
    /** use this function for multiple ajax calls (foreach) */
    call_queued: function(callback, uri, params) {        
        
        var callback_object = x4hubProxy;
        var callback_function = callback;
        
        if(params == null) {
            params = {};
        }
                
        var callback_object = this;
        var callback_function = callback;
        var callback_container = null;

            
        if( $.isArray(callback) ) {                
            callback_object = callback[0];
            callback_function = callback[1];
            if(callback.length == 3 ) {
                callback_container = callback[2];
            }
        } else {
            this.error_handler();
            return false;
        }
                
        
        // Add data to array if they don't exist
        if(params != null && params instanceof Object) {
            params.target = this.site_url + uri;
            params.ff_one_id = this.ff_one_id;
            params.sid = this.sid;
            params.site = this.site_id;
            
            if(params.rows == undefined) {
                params.rows = myappmaster.defaultRowCount;
            }

            /*
            if(params.startrow == undefined) {
                params.startrow = 0;
            }
            */
        }
        
        var data_format = 'json';
        if(params.data_format != null) {
            data_format = params.data_format;
            delete params.data_format;
        }
        
        
        
        x4hubProxy.start_loading();
        $.ajaxQueue({
            url: this.proxy_host,
            dataType: data_format,
            type: 'POST',
            data: params,
            success: function(data) {
                if(data == null || data == '') {
                    x4hubProxy.error_handler();
                    return false;
                }
                callback_object[callback_function](data, callback_container);
                
                //if(data.morerows == "true") {
                
                if(data.summary !== undefined && callback_container !== null &&data.morerows == "true") {
                    myappmaster.generate_pagination_links(callback_container, callback_object, callback_function, uri, params, data.rows, data.startrow, data.summary.auditcount);
                }
            },
            error: function(request, status, error) {
                console.log("Error in call");
                console.log("Status: " + status);
                console.log(error);
                console.log(request);
            }
        });

    },
    
    generate_unique_id: function() {
        var newDate = new Date;
        var unique = newDate.getTime();
        unique = unique + Math.floor(Math.random()*101);
        return unique;
    },
    start_loading: function() {
        $('#data-dump').html('LOADING CONTENT');
    }, 
    finish_loading: function() {
        $('#data-dump').html('');
    },
    get_objects: function() {
        this.call('process_objects', '/ondemand/core/?method=CORE_OBJECT_SEARCH');
    },
    process_objects: function(response) {
        $.each(response.data.rows, function(key, row) {
            $( '#data-dump' ).append('<p>' + row.title + ': ' + row.id + '</p>');
        });
    }
    
    
   
}