var X4HCommunication = {
    available_conversations: {},
    conversation_categories : {},
    defaultFields: ['Conversation', 'ConversationText', 'Message', 'OwnerUser', 'OwnerUserText', 'CreatedUserText','CreatedUser','Subject','CreatedDate'],
    defaultFilters: [],
    //defaultOptions: [{rf: 'json', startrow: 0, rows: 20, returnparameters: 'true'}],
    defaultSort: [{name: 'CreatedDate', direction: 'desc'}] /** TODO: X4H support for ID */,
    
    //Limits the number of available tabs for posts
    post_tab_index : 0,
    post_tab_limit : -1,
    /** CREATE A NEW CONVERSATION **/
    create_conversation: function(name, access, sharing, id) {
        
        var fields = {
            title: name,
            participantcan : access,
            sharing : sharing
        }
        
        if(id!==null){
            fields['id'] = id;
        }
        x4hubProxy.call(
            [X4HCommunication, 'create_conversation_return'], 
            '/ondemand/messaging/?method=MESSAGING_CONVERSATION_MANAGE', 
            fields
        );
    },
    create_conversation_return: function(response) {
        if(response.notes=="ADDED"){
            //then reload conversation
            myappmaster.add_message('Conversation Added.', 5);
            myappmaster.messages.manage_communications.set_conversation_list(null);
            
            //X4HCommunication.manage_communications.set_content();
        }else if(response.notes=="UPDATED"){
            
            myappmaster.add_message('Conversation Updated.', 5);
            myappmaster.messages.manage_communications.set_conversation_list(null);
            $('#edit-category-preloader').remove();
            
            //X4HCommunication.manage_communications.set_content();
        }else{
            $('#edit-category-preloader').remove();
            alert('error saving conversation');
            
        }
    },
    
    /** DELETE A CONVERSATION **/
    delete_conversation: function(conversation_id) {
        x4hubProxy.call(
            [X4HCommunication, 'delete_conversation_return'], 
            '/ondemand/messaging/?method=MESSAGING_CONVERSATION_MANAGE',
            {
                id: conversation_id, 
                remove: 1
            }
        );
    },
    delete_conversation_return: function(response) {
        myappmaster.add_message('Conversation Deleted', 5);
        $('#preloader-delete-conversation').remove();
        X4HCommunication.manage_communications.set_content();
        X4HCommunication.communications_panel.init();
        $( "#messages-nav" ).tabs('select','#communicationsManage');
        
    },
    
    /** CREATE A NEW CONVERSATION_POST **/
    create_conversation_post: function(conversation_id, subject, message, callback, callbackobj) {
        if(callback==null){
            callback='create_conversation_post_return';
        }
        
        if(callbackobj==null){
            callbackobj=X4HCommunication;
        }
        x4hubProxy.call(
            [callbackobj, callback], 
            '/ondemand/messaging/?method=MESSAGING_CONVERSATION_POST_MANAGE',
            {
                conversation: conversation_id, 
                subject: subject, 
                message: message, 
                noalerts: 1
            }
        );
    },
    create_conversation_post_return: function(response) {
        
    },
    
    /**
     * Main function call for Posts within conversations
     * supply fields and filters params.
     * supply callObj if callback function will come from a different module
     * supply a custom callback response
     * supply row number, passed callback values, etc. to 'params'
     **/
    search_conversation_posts : function(fields, filters, options, sort, callObj, callback, params){
        if(fields == null) {
            fields = this.defaultFields;
        }
        if(filters == null) {
            filters = this.defaultFilters;
        }
        if(options == null) {
            options = this.defaultOptions;
        }
        if(sort == null) {
            sort = this.defaultSort;
        }
        
        var oXML = new X4HASearch(fields, filters, options, sort).getXML();
        this.last_query = {
            fields: fields,
            filters: filters,
            options: options,
            sort: sort
        };
        
        var rows = 10;//default
        if(params!==undefined&&params.rows!==undefined){
            rows = params.rows;
        }
        
        x4hubProxy.call(
            [callObj, callback, params],
            '/ondemand/messaging/?method=MESSAGING_CONVERSATION_POST_SEARCH',
            {
                advanced: 1,
                data: oXML,
                includeme :1,
                rows: rows
                
                
            }
        );
            
        if(X4HASearchWidget.widget_search){
            X4HASearchWidget.widget_search = false;
        }
    },
    
    /** LOAD A LIST OF ALL CONVERSATIONS USER CAN ACCESS **/
    load_conversations: function() {
        this.search_conversation_posts(null, null, null, null);
        
    },
    
    
    
    load_conversations_handler: function(response) {
        var conversations = {};
        if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                conversations[row.id] = row.title;
                
            });
        }
        
        this.available_conversations = conversations;
        $.each(this.available_conversations, function(id, title) {            
            // Make an element
            var conversation = $('<div id="list-conversation-' + id + '">' + title + '</div>');
            $( '#office-communications-list').append(conversation);
            
            var conversation_list = $('<div id="' + conversation.attr('id') + '-posts"></div>');
            conversation.append(conversation_list);
            
            conversation.click(function() {
                if(!$(conversation).hasClass('active')) {
                    // If it has child nodes - show them, otherwise load them
                    if($(conversation_list).children().length > 0) {
                        $(conversation).children().show();
                    } else {
                        x4hubProxy.call(
                            [X4HCommunication, 'load_conversation_posts', conversation_list], 
                            '/ondemand/messaging/?method=MESSAGING_CONVERSATION_POST_SEARCH', 
                            {
                                conversation: id,
                                includeme: 1
                            }
                        );
                    }
                } else {
                    $(conversation).children().hide();
                }
                $(conversation).toggleClass('active');
            });
        });       
    },   

    load_conversation_posts: function(response, container) {
        if(response.data.rows.length > 0) {
            if(container != null) {
                $.each(response.data.rows, function(key, row) {
                    var post = $('<div id="' + container.attr('id') + '_post_' + row.id + '" class="conversation-list-post">Subject: ' + row.subject + '<br/>Message: ' + row.message + '</div>');
                    container.append(post); 
                });
            } else {
                alert("container = null");
            }
        }
    },
    
    list_recent_conversations: function(response) {
        if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                $( '#data-dump' ).append('<p>' + row.id + ': ' + row.title + + ': ' + row.object + '</p>');
            });
        } else {
            $( '#data-dump' ).append('<p>Empty</p>');
        }
    },
    
    /*
     * Function to setup required params before searching conversation posts
     * supply conversation_id to select a single item
     * supply filters to params
     * default calls 'get_conversation_post_return' callback
     **/
    get_conversation_posts: function(conversation_id,callObj,callBack,params) {
        var filters = null;
        
        if(callObj==null){
            callObj = X4HCommunication;
        }
        
        if(callBack==null){
            callBack = 'get_conversation_posts_return';
        }
        
        if(conversation_id!==null){
            var endpoint_params = {
                conversation : conversation_id,
                includeme : 1
            }
        }else{
            endpoint_params = {
                includeme : 1
                //rows:5
                //showread : 1
            }
        }
        
        if(params!==undefined&&params.filters!==undefined){
            filters = params.filters;
        }
        
        if(params==undefined){
            params = {container : 'message-list-container'}
        }
        X4HCommunication.search_conversation_posts(null, filters, null, null, callObj, callBack, params)
        
        
    },
    get_conversation_posts_return: function(response) {
        if(response.data.rows.length > 0) {
            $.each(response.data.rows, function(key, row) {
                $( '#data-dump' ).append('<p>' + row.id + ': ' + row.subject + ': ' + row.message + '</p>');
            });
        } else {
            $( '#data-dump' ).append('<p>No conversation posts?</p>');
        }
    },
    conversations_summary: function() {
        x4hubProxy.call([X4HCommunication, 'conversations_summary_display'], '/ondemand/messaging/?method=MESSAGING_CONVERSATION_SUMMARY_SEARCH');
    },
    conversations_summary_display: function(response) {
        
    },
    
    /** ADDED by Ram Alveyra 02-11-2011  */
    /*
     * Will start tabs, bind commands etc.
     * Has the functionality to remove child tabs created through communications panel
     * Will also initialise the communication category management to create/edit/delete/update message categories
     **/
    init : function(){
        
        //init items only when tab is selected
        $( "#messages-nav" ).tabs({
            select : function(event,ui){
                if(ui.index==0){
                    X4HCommunication.communications_panel.init();
                    
                }
                
                if(ui.index==1){
                    //if($('.conversation-row').size()==0){
                    //$('#conversation-admin-body').html('');
                    X4HCommunication.manage_communications.set_content();
                    //}
                }
                
                
            },
            show : function(event, ui){
                var tabindex = $(this).tabs("length")-1;
                if(ui.index!=tabindex){
                    
                    if(tabindex>1){ //default tab length
                        
                            if(tabindex>2 && ui.index>1){
                                $(this).tabs("remove",tabindex);
                            }else{
                                for(var key=$('#messages-nav').tabs('length');key!=2;key--){
                        
                                    $('#messages-nav').tabs("remove",(key-1));

                                }
                            }
                            //Remove Tiny MCE too
                            tinyMCE.execCommand('mceRemoveControl', false, 'conversation-message-field');
                    
                    }
                }
            }
        });
        
        /** TODO: Add ACL once available */
        //Admin for communications
        this.manage_communications.init();
        
        if($( "#messages-nav" ).tabs('option','selected')==0){
           this.communications_panel.init();
        }
    },
    
    /*
     * Collection of objects handling the main communication panel
     * Will Initialise the communication tab HTML (headers, content, etc)
     **/
    communications_panel : {
        preloader : $(
            '<div class="preloader-communications-list" id="preloader-communications-list">'
            +'    <span><img src="/assets/images/preloader.gif" /><br  />loading conversations</span>'
            +'</div>'
        ),
            
        communications_modal : $(
            '<div class = "message-modal" title = "" id="message-overview">'
            +'</div>'
        ),
        
        footer : $(
            '<div class="conversation-footer">'
            +'<div id="message-list-container-pagination" class="pagination-area"></div>'
            +'</div>'
        ),
            
            
            
        communication_headers : $(
            '<h1>Incoming Conversations</h1>'

            +'<a id = "compose-btn2" href="#"></a>'

            +'<div id = "messages-search">'
            +'    <input type="text" value="Filter Messages" id="posts-filter-text"/>'
            +'          <form>'
            +'          <div>'
            +'              <select id="messages-dropdown-search" name="search" >'
            +'                  <option value="subject">Subject</option>'
            +'                  <option value="conversationtext">Category</option>'
            
            //+'                  <option value="all" selected=selected>All</option>'
            +'              </select>'
            +'          </div>'
            +'          </form>'
            +'    <a href="#" id="posts-filter-btn"><img src="/assets/images/search-btn01.png" /></a><br /><br />'
            +'</div>'
        ),
            
        current_conversations : {}, current_posts : {}, current_comments : {}, selected_conversation : null, selected_post : null,   
        
        /** 
         * Initialize communications panel
         * - Resets values for recall
         * - will load conversation posts
         **/
        init : function(){
            var communications = this;
            
            //reset post cache
            //communications.current_posts = {};
            
            //remove old data
            $('#conversation-list-body').remove();
            $('.message-list').remove();
            $('#message-list-container-pagination').html('');
            $('#middle-messages').find('.conversation-footer').remove();
            $('#message-list-container').remove();
            
            //preload
            //find preloader and append if not exists
            if($.find('#preloader-communications-list').length==0){
                $('#middle-messages').append(this.preloader);
            }
            
            
            //list communications
            this.list_communications();
            
            
        },
        
        /**
         * Will initialy load conversation posts
         * - If left sidebar was used to search messages, 
         * it will load communications as a search and will load the search query
         * callback 'load_communication_posts'
         **/
        list_communications : function(){
            //search conversation posts
            
            console.log("widget search:"+X4HASearchWidget.widget_search)
            
            /* added to handle advance searching */
            if(X4HASearchWidget.widget_search){
               
               var params = {
                   filters : X4HASearchWidget.search_filter,
                   container : 'message-list-container'
               };
               
               X4HCommunication.get_conversation_posts(null,this,'load_communication_posts',params);
               
            }else{
               X4HCommunication.get_conversation_posts(null,this,'load_communication_posts');
            }
            
            /** TODO: Add access to conversations */
            
        },
        
        /**
         * Function loads conversation post response as HTML
         * Binds control for each post
         *  - Subject click loads Post details and comment addition
         *  - Category click loads search tab filter by selected category
         *  - Search by 'Subject' or 'Category' (will load search result tab)
         * Adds 'Compose Message' functionality   
         ***/
        load_communication_posts : function(response){
          var communications = this;
          var post_id;
          
          if(response.data.rows.length>0){
              var posts = response.data.rows;
              
              
              //remove old data
              $('#message-list-container').remove();
              
              var messages_content = $(
                '<div class = "message-list tabbed-content-body" id="message-list-container">'
                +'  <div id = "message-title">'
                +'      <div id = "message-list-info">'
            
                +'          <div id = "message-list-subject">'
                +'              <strong>Subject</strong>'
                +'          </div>'

                +'          <div id = "message-list-author">'
                +'              <strong>Author</strong>'
                +'          </div>'

                +'          <div id = "message-list-source">'
                +'              <strong>Category</strong>'
                +'          </div>'
               
                +'          <div id = "message-list-date">'
                +'               <strong>Date</strong>'
                +'          </div>'    

                

                +'      </div>'
                +'  </div>'
                +'</div>'
                
                
              );
              
              //loop through posts
              $.each(posts,function(key,row){
                
                communications.current_posts[row.id]=row;
                
               //get the post subject, category and trim
               var post_subject = (row.subject=='')?"No subject":row.subject;
               var post_category = row.conversationtext;

               //trim to 20 chars max
               if(post_subject.length>35){
                    //post_subject = post_subject.slice(0,35)+'...';
               }
               
               if(post_category.length>20){
                    post_category = post_category.slice(0,20)+'...';
               }
                
                var post_row = $(
                    '<div id = "message-list">'

                    +'    <div id = "message-list-info">'
                    
                    +'        <div id = "message-list-subject">'
                    +'          <span class = "message-post-row post-'+row.id+'" >'
                    +'            '+post_subject
                    +'          </span>'
                    +'        </div>'
                
                    +'        <div id = "message-list-author">'
                    +'           '+row.createdusertext
                    +'        </div>'
                
                    +'        <div id = "message-list-source">'
                    +'        <span class="message-category-row" id="message-category-row-'+row.conversation+'">'
                    +post_category+'</div>'
                   
                    +'        <div id = "message-list-date">'
                    +'            '+row.createddate
                    +'        </div>'    

                    

                    +'    </div>'
                    +'</div>'
                );
                
                messages_content.append(post_row);
                    
              });
              
              //get number of comments
              /*communications.get_post_comments_number('show_post_comment_count',posts);*/
              
              
              //remove modal first
              $('#preloader-communications-list').remove();  
                
              $('#middle-messages').append(messages_content);
              
              //after appending the content, append the headers
              $('#messages-header').html(this.communication_headers);
              
              
              //bind compose button
              $('#compose-btn2').click(function(){
                communications.create_post();//converted to tab style
                
              });
                 
              //bind post overview toggle
              
              
              $.each($( '.message-post-row' ), function(counter, elem) {
                   $(elem).click(function() {
                       post_id = myappmaster.find_id($(elem).attr('class'));
                       communications.selected_post = communications.current_posts[post_id];
                       communications.load_post(post_id);
                       
                   });
              });
              
              $.each($( '.message-category-row' ), function(counter, elem) {
                   $(elem).unbind('click').click(function() {
                       var conversation_id = myappmaster.find_id($(elem).attr('id'));
                       var category = $(elem).text();
                       myappmaster.messages.conversation_search.search_category = category;
                       myappmaster.messages.conversation_search.query = 'conversationtext';
                       myappmaster.messages.conversation_search.query_text = category;
                       myappmaster.messages.conversation_search.init();
                       
                   });
              });
             
          }else{
             $('#preloader-communications-list').remove();
             
             //remove old data
              $('#message-list-container').html('');
             
             //no posts available
             var no_content = $(
                '<div id="message-list-container" class="tabbed-content-body">'
               
                +'</div>'
             );
             
             if($('#message-list-container').size()==0){
                  $('#middle-messages').append(no_content);
                   
             }
             $('#message-list-container').html('<p><strong>There are no posts to display.</strong></p>');
             
             
            
          }
          //after appending the content, append the headers
          $('#messages-header').html(this.communication_headers);

          //fix dropdown
          if($('#messages-search-span').size()!=0){
              $('#messages-search-span').remove();
          }
          $('#messages-dropdown-search').each(function(){
                var title = $(this).attr('title');
                if( $('option:selected', this).val() != ''  ) title = $('option:selected',this).text();
                $(this)
                    .css({'z-index':10,'opacity':0,'-khtml-appearance':'none'})
                    .after('<span id = "messages-search-span">' + title + '</span>')
                    .change(function(){
                        val = $('option:selected',this).text();
                        $(this).next().text(val);
                        })
          });
          
          
          
          
          //bind compose button
          $('#compose-btn2').click(function(){
            console.log('New post');

            communications.create_post();//converted to tab style

            //X4HCommunication.compose_message.init();//tab style
          });  
              
          
          //bind search
          $('#posts-filter-btn').click(function(){
              var query = $('#messages-dropdown-search').val();
              var query_text = $('#posts-filter-text').val();
              
              if(query_text=='' || query_text=='Filter Messages'){
                  alert('Please add a search string.');
              }else{
                /* search converted to tab */
                myappmaster.messages.conversation_search.search_category = $('#messages-dropdown-search option:selected').text();
                myappmaster.messages.conversation_search.query = query;
                myappmaster.messages.conversation_search.query_text = query_text;
                myappmaster.messages.conversation_search.init();
              }
          });
          
          $('#posts-filter-text').click(function(){
              $(this).val('');
          });
          
          //footer and pagination  
          $('#middle-messages').append(this.footer);
          
        },
        
        load_post : function(post_id){
           var communications = this;
            //search if tab has already been opened and select
           if($('#conversations-panel').find('#viewPost'+post_id).size()!==0){
               $.each($('#messages-nav a'),function(key,a){
                  if($(this).attr('href')=='#viewPost'+post_id){
                      //make selected
                      $('#messages-nav').tabs('select', key);
                  } 
               });
           }else{
               //create a new tab and limit by posts tab 
               if(X4HCommunication.post_tab_index!==X4HCommunication.post_tab_limit){
                   X4HCommunication.post_tab_index+=1;
                   //set post overview values

                  //will hold post details and comments
                  var post_overview = $(

                    '<div class="post-overview">'
                    +'  <div class = "message-info" id="message-info-'+post_id+'">'
                    +'      <div id="message-source-'+post_id+'" class="message-source">'
                    +'          <strong>Category:</strong>&nbsp<span id="post-source-'+post_id+'"></span>'
                    +'      </div>'

                    +'      <div class="message-author" id="message-author-'+post_id+'">'
                    +'          <strong>From:</strong>&nbsp<span id="post-from-'+post_id+'"></span>'
                    +'      </div>'

                    +'      <div class="message-date">'
                    +'          <strong>Date:</strong>&nbsp<span class="post-date" id="post-date-'+post_id+'"></span>'
                    +'      </div>'

                    /*+'      <div class="message-subject">'
                    +'          <strong>Subject:</strong>&nbsp<span class="post-subject" id="post-subject-'+post_id+'"></span>'
                    +'      </div>'*/

                    +'      <div class="message-content" id="message-content-'+post_id+'">'
                    +'      </div>'

                    +'      <div class="message-reply">'
                    +'      <textarea class="post-reply" id="post-reply-'+post_id+'"></textarea>'        
                    +'      </div>'
                    +'      <div class="message-option">'
                    +'          <a href="#" class = "post-reply-btn" id="post-reply-btn-'+post_id+'" >Add Reply</a>'
                    +'      </div>'

                    +'  </div>'

                    +'  <div class="post-comments" id="post-comments-'+post_id+'">'
                    +'  </div>'

                    +'  <div id="message-option-post-overview-'+post_id+'">'
                    +'      <a href="#" class = "post-back" id="post-close-tab-'+post_id+'" >Close</a>'
                    +'  </div>'
                    +'</div>'

                  );



                   //get the post subject and add as the tab title
                   var post_subject = communications.selected_post.subject;

                   //trim to 25 chars max
                   if(post_subject.length>25){
                        post_subject = post_subject.slice(0,25)+'...';
                   }

                   $('#messages-nav').tabs("add","#viewPost"+post_id,post_subject);

                   var post_tab = $('#messages-nav').find('#viewPost'+post_id);

                   post_tab.addClass('tabbed-section');

                   //put in the right place
                   $('#conversations-panel').append(post_tab);

                   //make selected
                   $('#messages-nav').tabs('select', $('#messages-nav').tabs("length")-1);

                   //create and append the post container
                   var post_tab_content = $(
                    '<div id="post-overview-header-'+post_id+'" class="tabbed-content-header post-overview-header">'
                    +'  <h1> Subject: "'+communications.selected_post.subject+'"</h1>'
                    +'</div>'
                    +'<div id="post-overview-body-'+post_id+'" class="tabbed-content-body"></div>'
                   );

                   post_tab.append(post_tab_content);

                   //append details
                   $('#post-overview-body-'+post_id).append(post_overview);
                   $('#post-source-'+post_id).text(communications.selected_post.conversationtext);
                   $('#post-from-'+post_id).text(communications.selected_post.createdusertext);
                   $('#post-date-'+post_id).text(communications.selected_post.createddate);
                   //$('#post-subject').text('"'+communications.selected_post.subject+'"');
                   //
                   //decode html
                   var decoded = $("<div/>").html(communications.selected_post.message).text();
                   
                   $('#message-content-'+post_id).html(decoded);
                   $('#post-reply-'+post_id).val('Write a reply here...');



                   //load this post                               //comments preloader
                   var comments_preloader = $(
                        '<div id="comments-preloader">'
                        +'    <span><img src="/assets/images/preloader2.gif" /></span>'
                        +'</div>'
                   );

                   var fields = {
                       conversation : communications.selected_post.conversation,
                       post : communications.selected_post.id,
                       includeme : 1,
                       includepost : 1,
                       rows: 100
                       //shownew: 1,
                       //showread : 1
                   };

                   //add preloader
                   $('#post-comments-'+post_id).html(comments_preloader);

                   communications.search_post_comments(fields,'show_post_comments',communications,{
                       target_container : '#post-comments-'+post_id
                   });

                  //bind buttons
                  //close the post tab
                  $( "#post-close-tab-"+post_id ).button();
                  
                  $( "#post-close-tab-"+post_id ).click(function(){
                      //search for the tab index and remove
                      $.each($('#messages-nav a'),function(key,a){
                          if($(this).attr('href')=='#viewPost'+post_id){
                              //console.log(key)
                              //select first tab
                              //$('#messages-nav').tabs('select', 0);

                              //remove the tab
                              $('#messages-nav').tabs('remove', key);

                              //reset the post tab index
                              X4HCommunication.post_tab_index-=1;
                          } 
                      });
                  });

                  $( "#post-reply-btn-"+post_id ).button();

                  $( "#post-reply-btn-"+post_id ).click(function(){

                      if($('#post-reply-'+post_id).val()==''||$('#post-reply-'+post_id).val()=='Write a reply here...'){
                          alert('Please add a reply');

                      }else{
                          //get details
                          
                          var fields = {
                            conversation : communications.selected_post.conversation,
                            post : communications.selected_post.id,
                            comment : $('#post-reply-'+post_id).val(),
                            noalerts : 1
                          }
                          $('#post-reply-'+post_id).val('');
                          //comments preloader
                           var comments_preloader = $(
                                '<div id="comments-preloader">'
                                +'    <span><img src="/assets/images/preloader2.gif" /></span>'
                                +'</div>'
                           );



                          //remove no comment note
                          $('#post-comments-'+post_id+' #no-comments').remove();


                          $('#post-comments-'+post_id).prepend(comments_preloader);
                          //remove message typed
                          $('#post-reply').val('');
                          communications.create_post_comment(fields,'create_post_comment_response',communications,{
                              target_container : '#post-comments-'+post_id
                          });
                      }
                  });

                  //post overview commands
                  //remove content when selected
                  $('#post-reply-'+post_id).click(function(){


                      if($(this).val()=='Write a reply here...'){
                          $(this).val('');
                      }
                  });
                  
                  /**add edit and delete options
                  /* Must be system admin, delete must be conversation owner **/
                  
                  if(myappmaster.users.details.systemadmin!==undefined&&myappmaster.users.details.systemadmin=="true"){
                      if($('#post-edit-'+post_id).size()==0){
                        /** TODO: Clarify edit (will comment out edit first */
                        //$('#message-option-post-overview-'+post_id).append($('<a href="#" class = "post-edit" id="post-edit-'+post_id+'" >Edit Post</a>'));
                      }
                      
                      $('#post-edit-'+post_id).button({
                
                            create : function(event){
                                $(this).click(function(){
                                    communications.edit_post(communications.selected_post);
                                    
                                });
                            }
                      });
                      
                      //if(myappmaster.users.id==communications.selected_post.owneruser){
                          if($('#post-delete-'+post_id).size()==0){
                              /** TODO: Clarify delete (will comment out edit first */
                            //$('#message-option-post-overview-'+post_id).append($('<a href="#" class = "post-delete" id="post-delete-'+post_id+'" >Delete Post</a>'));
                          }
                      
                          $('#post-delete-'+post_id).button({

                                create : function(event){
                                    $(this).click(function(){
                                        var delete_post = confirm("Are you sure you want to delete this post?");
                                        if(delete_post==true){
                                            x4hubProxy.call(
                                                [communications, 'delete_post_return'], 
                                                '/ondemand/messaging/?method=MESSAGING_CONVERSATION_POST_MANAGE',
                                                {
                                                    conversation : communications.selected_post.conversation,
                                                    id : post_id,
                                                    /*noalerts : 1,
                                                    subject : communications.selected_post.subject,
                                                    message : communications.selected_post.message,*/
                                                    remove : 1,
                                                    force : 1
                                                }
                                            );
                                        }

                                    });
                                }
                          });
                      //}
                      //console.log(communications.selected_post.owneruser)
                  }
                  


               }//end limit post tab

           }//end not yet opened
        },
        
        delete_post_return : function(response){
            
        },
        
        get_post_comments_number : function(callback,posts){
            var communications = this;
            ajaxQueue.clearQueue();
            ajaxQueue.stop();
            $.each(posts,function(key,post){
                x4hubProxy.call_queued(
                    [communications, callback,
                        {
                            target : '.post-'+post.id+' #message-list-comments'
                        }
                    ],
                    '/ondemand/messaging/?method=MESSAGING_CONVERSATION_SUMMARY_SEARCH',
                    {
                        post : post.id
                    }
                );
            });

            
            
        },
        
        show_post_comment_count : function(response,params){
            if(response.commentcount){
                //console.log($(params.target))
                $(params.target).html(response.commentcount);
            }
        },
        
        create_post_comment : function(fields,callback,callbackobj,params){
            //console.log(fields);
            x4hubProxy.call(
            [callbackobj, callback,params], 
            '/ondemand/messaging/?method=MESSAGING_CONVERSATION_POST_COMMENT_MANAGE',
                fields
            );
        },
        
        create_post_comment_response : function(response,params){
          if(response.notes=='ADDED'){
              var fields = {
                  id : response.id,
                  includeme: 1,
                  rows: 100
              }
              
              
              this.search_post_comments(fields,'append_post_comment',this,params);
          }else{
              alert('Reply not added');
          }  
        },
        
        append_post_comment : function(response,params){
            if(response.data.rows.length>0){
                var row = response.data.rows[0];
                var comment_details = row.usercontactpersonfirstname+' '+row.usercontactpersonsurname;
                var newcomment = '<div id="message-comment" class="post-comment">'
                    +'<span id="comment-reply-details"><strong>'+comment_details+' replied on '+row.daytext+', '+row.datetime+'</strong>: </span><br />'
                    //+'<span id="comment-options"><button id="comment-edit-'+row.id+'" class="comment-edit">Edit</button><button id="comment-edit-'+row.id+'" class="comment-delete">Delete</button></span> <br />'
                    +row.message
                    +'</div>';
                
                //remove preloader
                $(params.target_container+' #comments-preloader').remove();
                //append new added comment
                $(params.target_container).prepend($(newcomment));
            }
            //if(myappmaster.users.id==this.selected_post.owneruser){
                //this.bind_comment_buttons();
            //}
        },
        
        search_post_comments : function(fields,callback,callbackobj,params){
            x4hubProxy.call(
            [callbackobj, callback, params], 
            '/ondemand/messaging/?method=MESSAGING_CONVERSATION_POST_COMMENT_SEARCH',
                fields
            );
        },
        
        show_post_comments : function(response,params){
            var comments = '';
            if(response.data.rows.length>0){
               $.each(response.data.rows,function(key,row){
                    var comment_details = row.usercontactpersonfirstname+' '+row.usercontactpersonsurname;
                    comments+= '<div id="message-comment" class="post-comment">'
                    +'<span id="comment-reply-details"><strong>'+comment_details+' replied on '+row.daytext+', '+row.datetime+'</strong>: </span><br />'
                    //+'<span id="comment-options"><button id="comment-edit-'+row.id+'" class="comment-edit">Edit</button><button id="comment-edit-'+row.id+'" class="comment-delete">Delete</button></span> <br />'
                    +row.message
                    +'</div>'
               });
               
               $(params.target_container).html($(comments));
               
            }else{
               $(params.target_container).html('<div id="no-comments">There are no comments to display</div>');
            }
            //if(myappmaster.users.id==this.selected_post.owneruser){
                //this.bind_comment_buttons();
            //}
        },
        
        bind_comment_buttons : function(){
          //Edit comment
          $.each($('.comment-edit'),function(key,elem){
             $(elem).button({
                text: false,
                icons: {
                    primary: "ui-icon-gear"
                }
             }); 
          });
          $.each($('.comment-delete'),function(key,elem){
             $(elem).button({
                text: false,
                icons: {
                    primary: "ui-icon-trash"
                }
             }); 
          });
        },
        
        edit_post : function(post){
            var communications = this;
           
            var header = $(
                '<div id="conversations-header"  class="tabbed-content-header">'
                +' <div id="contacts-header-options">'
                //+'    <span><a href="#" class="edit-contact" id="edit-contact-'+contact_id+'">Edit</a></span>'
                +' </div>'
                +    '<h1>Edit Post</h1>'
                +'</div>' 
              );
            
            var post_edit = $(
                '<div id="conversation-edit-body"><div class="conversation-overview" id="edit-post">'
                +'  <div id = "message-info">'
                +'      <div id="message-source">'
                +'          <strong>Category Name:</strong> <span id="conversation-title">'+post.conversationtext+'</span>'
                +'      </div>'

                +'      <div id="message-subject">'
                +'          <strong>Subject:</strong>&nbsp;<input type="text" id="message-subject-field" value="'+post.subject+'"/>'
                +'      </div>'

                +'      <div id="conversation-message">'
                +'      <textarea id="conversation-message-field">'+post.message+'</textarea>'
                +'      </div>'
                +   '</div>'
                +'  <div id="message-option">'
                +'      <a href="#" class = "back" id = "message-back" >Cancel</a>'
                +'      <a href="#" class = "save-post" id = "save-post" >Save Post</a>'
                +'  </div>'
                +'</div></div>'
            );
            
            if($( "#messages-nav").find('a[href=#editPost]').length==0){
            
                $('#messages-nav').tabs("add","#editPost","Edit Post");

                var compose_message_panel = $('#messages-nav').find("#editPost");

                compose_message_panel.addClass("tabbed-section");

                $('#conversations-panel').append(compose_message_panel);

                $('#messages-nav').tabs('select', $('#messages-nav').tabs("length")-1);

                compose_message_panel.append(header);
                compose_message_panel.append(post_edit);
                
                $('#edit-post #save-post').button({
                
                    create : function(event){
                        $(this).click(function(){
                            $('#conversation-message-field').val(tinyMCE.get('conversation-message-field').getContent());
                            
                            if($('#message-subject-field').val()=='' || $('#conversation-message-field').val()==''){
                                alert('Please enter Post subject and Post message');
                            }else{
                                //var conversation_id = communications.selected_conversation.id;
                                var subject = $('#message-subject-field').val();
                                var message = tinyMCE.get('conversation-message-field').getContent();
                                x4hubProxy.call(
                                    [communications, 'edit_post_return'], 
                                    '/ondemand/messaging/?method=MESSAGING_CONVERSATION_POST_MANAGE',
                                    {
                                        id : post.id,
                                        conversation: post.conversation, 
                                        subject: subject, 
                                        message: message, 
                                        noalerts: 1
                                        
                                    }
                                );
                                //var callback = 'create_post_return';
                                //var callbackobj = communications;
                            }

                        });
                    }
                });
                
                $('#edit-post #message-back').button({
                
                    create : function(event){
                        $(this).click(function(){
                            $('#messages-nav').tabs("select","#viewPost"+post.id);

                        });
                    }
                });
                
                tinyMCE.execCommand('mceAddControl', true, 'conversation-message-field');
                var tmp_instance = tinyMCE.get('conversation-message-field');
                if(tmp_instance!==undefined){
                   tmp_instance.setContent($('#edit-post #conversation-message-field').text());
                }
                
            }else{
                $('#messages-nav').tabs('select', '#editPost');
                console.log('still here')
            }
            
            
            
            
            
        },
        
        edit_post_return : function(response){
            
            $('#messages-nav').tabs('select', '#conversationsOverview');
        },
        
        
        /**
         * Function called when creating new posts
         * Creates new tab with category details
         * Same function acts as endpoint callback
         *  - will callback same function that will load the response and create HTML
         * When selected via 'Incoming' tab, will display the list of available category/conversations
         *  - needs to select conversation before creating post
         * When selected via search by 'Category', it will automatically proceed to post creation page 
         **/
        create_post : function(response, params){
          var communications = this;
          var title = "Compose New Message";
          var preloader_text = 'loading conversations';
          var header = $(
            '<div id="conversations-header"  class="tabbed-content-header">'
            
            +    '<h1>Create New Message</h1>'
            +'</div>' 
          );
          
          var footer = $(
            '<div id="conversation-add-footer">'
            +'<div id="add-message-list-pagination" class="pagination-area"></div>'
            +'</div>'
          );
          
          if(response==null){
            
            /** Added to handle post edit */
            /*if(params!==undefined&&params.conversation_id!==undefined){
                title = "Edit Post";
                header.find('h1').text(title);
                preloader_text = 'Loading post details';
            }*/
            
            
              //create tab for new message
            $('#messages-nav').tabs("add","#composeMessage",title);

            var compose_message_panel = $('#messages-nav').find("#composeMessage");

            compose_message_panel.addClass("tabbed-section");
            
            $('#conversations-panel').append(compose_message_panel);

            $('#messages-nav').tabs('select', $('#messages-nav').tabs("length")-1);
            
            compose_message_panel.append(header);
            
            compose_message_panel.append(
              '<div id="conversation-add-body">'
              +'<div class="preloader-communications-list">'
              +'    <span><img src="/assets/images/preloader.gif" /><br  />'+preloader_text+'</span>'
              +'</div>'      
              +'</div>'
            );
                
            compose_message_panel.append(footer);
              //console.log(conversation);  
              var conversation_fields = ['title', 'modifieddate', 'postcount','participantcan', 'sharing', 'commentcount', 'lastpostedday'];  
              
              if(params!==undefined&&params.conversation!==undefined){
                  var filters = [{name: 'id', comparison : 'EQUAL_TO', value1: params.conversation}];
                  var conversation = params.conversation;
              }else{
                  filters = null;
                  conversation = null;
              }
              
              var oXML = new X4HASearch(conversation_fields, filters, null, null).getXML();
              
              x4hubProxy.call(
                [this, 'create_post',{container: 'add-message-list',conversation: conversation}], 
                '/ondemand/messaging/?method=MESSAGING_CONVERSATION_SEARCH', 
                {
                    advanced : 1,data: oXML,
                    includesummary:1,
                    rows:20
                    
                }
              );
          }else{
              //Call back
              if(response.data.rows.length>0){
                  var conversations = response.data.rows;
                  
                  //add headers
                  var headers = $(
                    '<div class = "add-message-list">'
                    +'<p><em>Select a category to add a new post</em></p>'
                    +'<div id = "message-title">'
                    +'  <div id = "message-list-info">'
                    +'      <div class="add-message-header" id="add-message-header-title">'
                    +'          <strong>Name</strong>'
                    +'      </div>'
                    +'      <div class="add-message-header" id="add-message-header-posts">'
                    +'          <strong>Posts</strong>'
                    +'      </div>'
                    +'      <div class="add-message-header" id="add-message-header-comments">'
                    +'          <strong>Comments</strong>'
                    +'      </div>'
                    +'      <div class="add-message-header" id="add-message-header-date">'
                    +'          <strong>Date</strong>'
                    +'      </div>'
                    +'  </div>'
                    +'</div>'
                    +'</div>'
                  );
                  
                  
                  
                  //append overview - will hold conversation details
                  var conversation_overview = $(
                        '<div class="conversation-overview" id="new-post">'
                        +'  <div id = "message-info">'
                        +'      <div id="message-source">'
                        +'          <strong>Category Name:</strong> <span id="conversation-title"></span>'
                        +'      </div>'
                        +'      <div id="message-date">'
                        +'          <strong>Last Post Date:</strong> <span id="conversation-date-time"></span>'
                        +'      </div>'
                    
                        +'      <div id="message-subject">'
                        +'          <strong>Subject:</strong>&nbsp;<input type="text" id="message-subject-field"/>'
                        +'      </div>'
                    
                        +'      <div id="conversation-message">'
                        +'      <textarea id="conversation-message-field"></textarea>'
                        +'      </div>'
                        +   '</div>'
                        +'  <div id="message-option">'
                        +'      <a href="#" class = "back" id = "message-back" >Back</a>'
                        +'      <a href="#" class = "save-post" id = "save-post" >Save Post</a>'
                        +'  </div>'
                        +'</div>'
                  );
                      
                  
                  
                  
                  
                  //add conversation rows
                  if(params!==undefined && params.conversation!==null){
                      
                      $('#conversation-add-body').html(conversation_overview);
                      communications.current_conversations[params.conversation] = conversations[0];
                      communications.selected_conversation = communications.current_conversations[params.conversation];
                      
                      $('#conversation-title').text(communications.selected_conversation.title);
                      $('#conversation-date-time').text(communications.selected_conversation.lastpostedday+', '+communications.selected_conversation.modifieddate);
                      
                      //clear values
                           $('#message-subject-field').val('');
                           $('#conversation-message-field').val('');
                           
                           tinyMCE.execCommand('mceAddControl', true, 'conversation-message-field');
                      
                      conversation_overview.show();    
                  }else{
                      
                      $('#conversation-add-body').html(headers);
                      
                      $.each(conversations,function(key,row){
                          communications.current_conversations[row.id]=row;
                          var conversation_row = $(
                            '<div class = "message-row-conversation conversation-'+row.id+'" id = "message-list">'

                            +'    <div id = "message-list-info">'
                            +'        <div class="add-message-item" id = "add-message-item-title">'
                            +'                '+row.title
                            +'        </div>'

                            +'        <div class="add-message-item" id = "add-message-item-posts">'
                            +'           '+row.postcount
                            +'        </div>'

                            +'        <div class="add-message-item" id = "add-message-item-comments">'
                            +'            '+row.commentcount
                            +'        </div>'

                            +'        <div class="add-message-item" id = "add-message-item-date">'
                            +'            '+row.modifieddate
                            +'        </div>'    



                            +'    </div>'
                            +'</div>'
                          );
                          headers.append(conversation_row);
                      });
                      $('#conversation-add-body').append(conversation_overview);
                      //hidden by default
                      conversation_overview.hide();
                  }
                  //init buttons
                  $( "#message-back" ).button();
                  
                  $( "#message-back" ).click(function(){
                      
                      if(params!==undefined && params.conversation!==null){
                          $('#messages-nav').tabs('select','#searchCommunications');
                      }else{
                          $('.conversation-overview').hide();
                          $('.add-message-list').show();
                      }
                      var tmp_instance = tinyMCE.get('conversation-message-field');

                       if(tmp_instance!==undefined){
                           tmp_instance.setContent('');
                       }
                      
                      
                  });
                  
                  
                  $( "#save-post" ).button();
                  $( "#save-post" ).click(function(){
                      //check for content
                      
                      $('#conversation-message-field').val(tinyMCE.get('conversation-message-field').getContent());
                      
                      if($('#message-subject-field').val()=='' || $('#conversation-message-field').val()==''){
                          alert('Please enter Post subject and Post message');
                      }else{
                          //save the post
                          //console.log(communications.selected_conversation);
                          var conversation_id = communications.selected_conversation.id;
                          var subject = $('#message-subject-field').val();
                          var message = tinyMCE.get('conversation-message-field').getContent();
                          var callback = 'create_post_return';
                          var callbackobj = communications;
                          
                          X4HCommunication.create_conversation_post(conversation_id, subject, message, callback, callbackobj);
                      }
                  });
                  
                  
                  //show main modal
                  //this.show_conversation_modal('New Post','500');
                  
                  
                  //bind buttons
                  $.each(headers.find( '.message-row-conversation' ), function(counter, elem) {
                       $(elem).click(function() {
                           var conversation_id = myappmaster.find_id($(elem).attr('class'));
                           
                           communications.selected_conversation = communications.current_conversations[conversation_id];
                           //add details
                           $('#conversation-title').text(communications.selected_conversation.title);
                           $('#conversation-date-time').text(communications.selected_conversation.lastpostedday+', '+communications.selected_conversation.modifieddate);
                           
                           $('.add-message-list').hide();
                           
                           //clear values
                           $('#message-subject-field').val('');
                           $('#conversation-message-field').val('');
                           
                           tinyMCE.execCommand('mceAddControl', true, 'conversation-message-field');
                           
                           conversation_overview.show();
                           
                       });
                  });
                  
                  /** If this is to edit a post, then trigger overview */
                  /*if(params!==undefined&&params.conversation_id!==undefined){
                      $('.conversation-'+params.conversation_id).trigger('click');
                  }*/
                  
              }else{
                  $('#conversation-add-body').html('<p>There are no conversations to display. </p>')
              }
          }    
          
        },
        
        create_post_return : function(response){
            if(response.notes=='ADDED'){
                this.list_communications();
                myappmaster.add_message('New post added.', 5);
                $('#messages-nav').tabs('select', '#conversationsOverview');
            }
        }
        
        
    },
    
    /*
     * Collection of objects handling create/edit/delete/update message categories
     **/
    manage_communications : {
        preloader : $(
            '<div class="preloader-communications-manage" id="preloader-communications-manage">'
            +'    <span><img src="/assets/images/preloader.gif" /><br  />loading conversations</span>'
            +'</div>'
        ),
            
        //use this for multiple calls before content loads.
        content_data : {
            conversations : null
        },
        
        selected_conversation_id : null,
        
        init : function(){
            var manage_communications = this;
            if($( "#messages-nav").find('a[href=#communicationsManage]').length==0){
                this.create_manage_panel();
            }
            
            //delete previous content
            //$('#conversation-admin-body').html('');
            
        },
        
        
        create_manage_panel : function(){
           //add new tab
           $('#messages-nav').tabs("add","#communicationsManage","Categories");
           
           var conversation_admin = $('#messages-nav').find('#communicationsManage');
           
           conversation_admin.addClass('tabbed-section');
           
           //put in the right place
           $('#conversations-panel').append(conversation_admin);
           
           //create headers and stuff
           var header = $(
                '<div id="messages-header">'
                
                +    '<h1>Categories</h1>'
                +'<div id = "categories-search">'
                +'    <input type="text" value="" id="categories-filter-text"/>'
                
                +'    <a href="#" id="categories-filter-btn"><img src="/assets/images/search-btn01.png" /></a><br /><br />'
                +'</div>'
                +'</div>'
           );
               
               
           var search_panel = $(
                '<div class="tabbed-content-search"> </div>'
           );
               
           var admin_body = $(
                '<div class="tabbed-content-body" id="conversation-admin-body"></div>'
           );
               
           var create_category = $(
                '<div id="accordion" class="create-category">'
                +'  <h3><a href="#">Create Category</a></h3>'
                +'  <div id="create-category-panel">'
            
                +'  <div class="panel-field-row">'
                +'      <label id="category-name-label">Category Name</label>' 
                +'      <input id="category-name-input" type="text" />'
                +'  </div>'
            
                +'  <div class="panel-field-row">'
                +'      <label id="category-access-label">Member Access</label>'
                +'      <select id="category-access-select">'
                +'          <option value="1">Add Posts and Comments</option>'
                +'          <option value="2">Add Comments Only</option>'
                +'          <option value="3">View Only</option>'
                +'          <option value="4">Add Posts Only</option>'
                +'      </select>'
                
                +'      <select id="category-privacy-select">'
                +'          <option value="1">Added Participants</option>'
                +'          <option value="2">Everyone (Public)</option>'
                +'          <option value="3">Internal (Private)</option>'
                +'      </select>'
                +'      <label id="category-privacy-label">Privacy</label>'
                +'  </div>'
            
                +'  <div class="panel-field-row">'
                +'  <button id="category-create-btn">Create</button>'
                +'  </div>'
            
                +'  </div>'
                +'</div>'
           );
               
           var preloader = $(
            '<div class="preloader-communications-list" id="preloader-category">'
            +'    <span><img src="/assets/images/preloader.gif" /><br  />loading conversations</span>'
            +'</div>'
           );    
               
               
           conversation_admin.append(header);
           
           conversation_admin.append(admin_body);
           
           admin_body.append(create_category);
           
           admin_body.append(preloader);
           
           admin_body.append($('<div id="conversation-categories"></div>'));
           
           admin_body.append($('<div id="conversation-categories-pagination" class="pagination-area"></div>'));
           
           $('#category-create-btn').button({
                create : function(){
                    $(this).click(function(){
                        var title = $("#category-name-input").val();
                        var access = $("#category-access-select").val();
                        var sharing = $("#category-privacy-select").val();
                        
                        //reset
                        $("#category-name-input").val('');
                        $("#category-access-select").val(1);
                        $("#category-privacy-select").val(1);
                        
                        if(title==''){
                            alert('You need to add a title to create a conversation.');
                        }else{
                            $('#preloader-category').show();
                            
                            //save the conversation
                            X4HCommunication.create_conversation(title, access, sharing, null);
                        }
                    });
                }
            });
            
            $('#categories-filter-btn').click(function(){
                var query_text = $('#categories-search input').val();
                $('#categories-search input').val('');
                
                //remove content
                $('#conversation-categories').html('');
                
                //show preloader
                $('#preloader-category').show();
                
                //search content
                var filters = [{name:'title', comparison: 'TEXT_IS_LIKE', value1 : query_text}];
                myappmaster.messages.manage_communications.set_conversation_list(null,{filters : filters, container: 'conversation-categories'});
            
            });
            
        },
        
        set_content : function(){
            //content calls for admin
            //$("#conversation-admin-body").append(this.preloader);
            
            /* init create panel */
            $( "#accordion" ).accordion({
			collapsible: true,
                        autoHeight: false
                        
            });
            
            this.set_conversation_list(null);
        },
        
        //use this to handle multiple calls
        load_content : function(){
            var content_loaded = true;
            $.each(this.content_data,function(key,value){
                
                if(value==null){
                    //console.log(key+":"+value);
                    content_loaded = false;
                    return
                }
                
            });
            //display needed content after all had finished loading
            if(content_loaded){
                 var admin_body =  $('#conversation-admin-body');
                 
                 //flush the old content first, including preloader
                 admin_body.html('');
                 
                 admin_body.append(this.content_data.conversations);
            }
            
        },
        
        set_conversation_list : function(response,params){
            var conversation_fields = ['title', 'modifieddate', 'postcount','participantcan', 'sharing', 'description', 'object','objectcontext','owneruser','ownerusertext', 'commentcount'];
            
            if(params!==undefined&&params.sort!==undefined){
                var sort = params.sort 
            }else{
                sort = X4HCommunication.defaultSort
            }
            
            if(params==undefined){
                params = {container: 'conversation-categories'}
            }
            if(response==null){
                
                if(params!==undefined&&params.filters!==undefined){
                    var filters = params.filters; 
                }else{
                    filters = X4HCommunication.defaultfilters;
                }
                
                var oXML = new X4HASearch(conversation_fields, filters , null, sort ).getXML();
                
                x4hubProxy.call(
                    [this, 'set_conversation_list',params], 
                    '/ondemand/messaging/?method=MESSAGING_CONVERSATION_SEARCH', 
                    {
                        advanced : 1,
                        data : oXML,
                        rows: 20,
                        includesummary : 1
                    }
                );
            }else if(response.data.rows.length>0){
                
                
                
                $('#preloader-category').hide();
                
                var headers = $(
                    '<div class="conversation-row conversation-header">'
                    +'<div class="conversation-name conversation-label"><span>Name</span></div>'
                    +'<div class="conversation-posts conversation-label no-hover"><span>Posts</span></div>'
                    +'<div class="conversation-updates conversation-label"><span>Last Updated</span></div>'
                    +'</div>'
                );
                
                var manage_communications = this;
                var conversation_result = response.data.rows;
                var conversations = '';
                var conversation_row='';
                
                //reset
                $('#conversation-categories').html('');
                
                $('#conversation-categories-pagination').html('');
                
                $('#conversation-categories').append(headers);
                
                $.each(conversation_result,function(key,row){
                    
                    myappmaster.messages.conversation_categories[row.id]= row;
                        
                    conversation_row += '<div class="conversation-row conversation-row-data" id="conversation-'+row.id+'">'
                    +'<div class="conversation-name conversation-data">'+row.title+'</div>'
                    +'<div class="conversation-posts conversation-data">'+row.postcount+'</div>'
                    +'<div class="conversation-updates conversation-data">'+row.modifieddate+'</div>'
                    +'</div>';
                    
                });
                
                $('#conversation-categories').append(conversation_row);
                
                //bind conversation edit
                $.each($('.conversation-row-data' ), function(counter, elem) {
                   $(elem).click(function() {
                       var conversation_id = myappmaster.find_id($(elem).attr('id'));
                       
                       X4HCommunication.compose_message.init(conversation_id);
                   });
                });
                
                //bind sort
                $.each($('.conversation-label'),function(counter,elem){
                   $(elem).click(function(){
                       if($(elem).find('span').text()=='Name'){
                           var sort = [{name:'title',direction:'asc'}]
                       }
                       myappmaster.messages.manage_communications.set_conversation_list(null,{sort: sort, container: 'conversation-categories', filters : params.filters});
                   }); 
                });
                
            }else{
                $('#preloader-category').hide();
                $('#conversation-admin-body').append(' <div class="conversation-row no-conversation">There are no conversations.</div>');
            }
        },
        
        //display conversation participants
        show_participants : function(conversation_id){
            
            //preloader
            var participant_preloader = $(
                '<div id="preloader-participants">'
                +'    <span><img src="/assets/images/preloader2.gif" /></span>'
                +'</div>'
            );
            
            //this.get_participants(conversation_id);
            $('#conversation-participants').html(participant_preloader);
            
            this.get_participants(conversation_id);
            
        },
        
        get_participants : function(conversation_id){
            x4hubProxy.call(
                [this, 'set_participants',{conversation_id: conversation_id}], 
                '/ondemand/messaging/?method=MESSAGING_CONVERSATION_PARTICIPANT_SEARCH', 
                {
                    conversation : conversation_id,
                    
                    status : 1
                }
            );
        },
        
        set_participants : function(response, params){
            var manage_communications = this;
            var participants = '';
            
            if(response.data.rows.length>0){
                var participant_response = response.data.rows;
                var participant_row;
                
                //load participants
                $.each(participant_response, function(key, row){
                    participant_row = '<div class="conversation-participant-row">'
                    +'  <div class="participant-name">'+row.firstname+'&nbsp'+row.surname+'</div>'
                    +'  <div class="remove-participant" >'
                    +'      <a href="#" class="remove-participant-'+params.conversation_id+'" id="participant-'+row.user+'">Remove</a>'
                    +'  </div>'
                    +'</div>'
                    
                    /*if(key+1>participant_response.length){
                        participant_row+='';
                    }*/
                    
                    participants+=participant_row;
                    
                });
                
                $('#conversation-participants').html($(participants));
                
                
                //bind remove participants
                $.each($('.remove-participant-'+params.conversation_id ), function(counter, elem) {
                   $(elem).click(function() {
                       var user_id = myappmaster.find_id($(elem).attr('id'));
                       manage_communications['removed_participant_id'] = user_id;
                       manage_communications.remove_participant(user_id,params.conversation_id);
                   });
                });    
                
            }else{
                participant_row = $(
                    '<div class="conversation-participant-row">'
                    +'  <p>There are no participants for this conversation.</p>'
                    +'</div>'
                );
                    
                participants=participant_row;
                $('#conversation-participants').html($(participants));
                
                
            }
            
            $('#conversation-participants').append($(
                '<div class="conversation-participant-row">'
                +'  <a href="#" class="add-participant-'+params.conversation_id+'" id="add-participant-'+params.conversation_id+'">Add participant</a>'
                +'</div>'
            ));
                
            // bind add participants
            $('#add-participant-'+params.conversation_id).click(function(){
                manage_communications.show_add_participants_tab(params.conversation_id);
            });
        },
        
        //load add participant tab
        show_add_participants_tab : function(conversation_id){
            var manage_communications = this;
            manage_communications.selected_conversation_id = conversation_id;
            var header = $(
            '<div id="conversations-header"  class="tabbed-content-header">'
            +    '<h1>Add Participant</h1>'
            +'</div>' 
            );
            
            var content = $(
                '  <div id="conversation-add-participant-body" >'
                +' <div id="participant-list">'                
                +' </div>'
                +'  </div>' 
            );
                
            var footer = $(
            '<div id="conversation-add-participant-footer" class="conversation-footer">'
            +'<div id="participant-list-pagination" class="pagination-area"></div>'
            +'</div>'
            );
                
            var preloader = $(
              '<div class="preloader-participant-list">'
              +'    <span><img src="/assets/images/preloader.gif" /><br  />Loading participants</span>'
              +'</div>'
            );    
                
            //create tab for adding participants
            $('#messages-nav').tabs("add","#addParticipant","Add Participant");
            
            var add_participant_panel = $('#messages-nav').find("#addParticipant");
            
            add_participant_panel.addClass('tabbed-section');
            
            $('#conversations-panel').append(add_participant_panel);

            $('#messages-nav').tabs('select', $('#messages-nav').tabs("length")-1);
            
            add_participant_panel.append(header);
            
            add_participant_panel.append(content);
            
            add_participant_panel.append(footer);
            
            //add preloader
            $('#participant-list').html(preloader);
            
            this.search_users('load_users');
        },
        
        //load add participant modal
        
        
        search_users : function(callback){
             x4hubProxy.call([this, callback],
                '/ondemand/core/?method=CORE_USER_SEARCH',
                    {
                        
                    }
                );
        },
        
        load_users : function(response){
            //reset content
            $('#participant-list').html('');
            var manage_communications = this;
            
            if(response.data.rows.length>0){
                var users = response.data.rows;
                var header = $(
                '                  <div class="participant-search-row">'
                +'                      <div class="participant-search-header">Name</div>'
                //+'                      <div class="participant-search-header">Business</div>'
                +'                      <div class="participant-search-header">User</div>'
                +'                  </div>'
                );
                    
                //append header
                $('#participant-list').append(header);
                
                $.each(users, function(key,row){
                   var user_row = $(
                        '<div class="participant-search-row">'
                        +'  <div class="participant-search-item">'+row.surname+', '+row.firstname+'</div>'
                        //+'  <div class="participant-search-item">FF-One</div>'
                        +'  <div class="participant-search-item">'+row.createdusertext+'</div>'
                        +'  <div class="participant-search-item-end"><a href="#" id="add-participant-'+row.id+'" class="add-participant-anchor">&nbsp;</a></div>'
                        +'</div>'
                    );
                    
                    //Don't show self
                    if(row.contactperson!==myappmaster.users.details.contactperson){
                    $('#participant-list').append(user_row);
                    }
                        
                });
                
                //bind add participants
                
                $.each($('#participant-list').find( '.add-participant-anchor' ), function(counter, elem) {
                   $(elem).click(function() {
                       var user_id = myappmaster.find_id($(elem).attr('id'));
                       $(elem).parent().parent().append($(
                        //add preloader
                        '<div id="preloader-participants-add">'
                        +'    <span><img src="/assets/images/preloader2.gif" /></span>'
                        +'</div>'
                       )); 
                       manage_communications.add_conversation_participant(user_id,'add_conversation_participant_response');
                   });
                }); 
            }
        },
        
        add_conversation_participant : function(user_id,callback){
            x4hubProxy.call([this, callback],
            '/ondemand/messaging/?method=MESSAGING_CONVERSATION_PARTICIPANT_MANAGE',
                {
                    conversation : this.selected_conversation_id,
                    user: user_id
                    
                }
            );
            
        },
        
        add_conversation_participant_response : function(response){
            //close dialogs
            if(response.notes=='ADDED' || response.notes=='UPDATED'){
                myappmaster.add_message('Selected User has been added as participant.', 5);
                
                this.show_participants(this.selected_conversation_id);
            }
            
            $('#preloader-participants-add').remove();
            
        },
        
        remove_participant : function(user_id,conversation_id){
            var delete_participant = confirm("Are you sure you want to remove this participant");
            if(delete_participant==true){
                x4hubProxy.call([this, 'remove_participant_response',conversation_id],
                '/ondemand/messaging/?method=MESSAGING_CONVERSATION_PARTICIPANT_MANAGE',
                    {
                        conversation : conversation_id,
                        user: user_id,
                        status : 2
                    }
                );
                //console.log(conversation_id);
            }
        },
        
        remove_participant_response : function(response,conversation_id){
            if(response.notes=='UPDATED'){
                myappmaster.add_message('Participant has been removed.', 5);
                
                //remove participant
                $('#participant-'+myappmaster.messages.manage_communications.removed_participant_id)
                .parent().parent().remove();
                
            }else{
                alert('Error removing participant');
            }
        }
        
    },
    
    compose_message : {
        header : $(
            '<div id="conversations-header"  class="tabbed-content-header">'
            +' <div id="contacts-header-options">'
            //+'    <span><a href="#" class="edit-contact" id="edit-contact-'+contact_id+'">Edit</a></span>'
            +' </div>'
            +    '<h1>Create New Conversation</h1>'
            +'</div>' 
        ),
            
        content : $(
            '<div id="conversation-add-body">'
            +'  <div id="conversation-title"><label>Title:</label><input type="text" id="field-conversation-title" /></div>'
            +'  <h2>Group Access</h2>'
            +'  <p>Select what a member can do in this conversation</p>'
            +'  <p>'
            +'    <input id="field-conversation-access-all" type="radio" value="1" name="field-conversation-access">&nbsp; Add Posts and Comments</input>'
            +'  </p>'

            +'  <p>'
            +'    <input id="field-conversation-access-comments" type="radio" value="2" name="field-conversation-access">&nbsp; Add Comments Only</input>'
            +'  </p>'

            +'  <p>'
            +'    <input id="field-conversation-access-view" type="radio" value="3" name="field-conversation-access">&nbsp; View Only</input>'
            +'  </p>'

            +'  <p>'
            +'    <input id="field-conversation-access-post" type="radio" value="3" name="field-conversation-access">&nbsp; Add Posts Only</input>'
            +'  </p>'

            +'  <h2>Sharing</h2>'
            +'  <p>Select who can this conversation be shared with</p>'
            +'  <p>'
            +'    <input id="field-conversation-sharing-participants" type="radio" value="1" name="field-conversation-sharing">&nbsp; Added Participants</input>'
            +'  </p>'
            +'  <p>'
            +'    <input id="field-conversation-sharing-public" type="radio" value="2" name="field-conversation-sharing">&nbsp; Everyone (Public)</input>'
            +'  </p>'
            +'  <p>'
            +'    <input id="field-conversation-sharing-internal" type="radio" value="3" name="field-conversation-sharing">&nbsp; Internal (Private)</input>'
            +'  </p>'
            
            +'  <h2>Participants</h2>'
            +'  <div id="conversation-participants"></div>'
        
            +'</div>'
        ),
            
        footer : $(
            '<div id="conversation-add-footer">'
            +'<input type="button" id="save-conversation" value="Save Conversation" />'
            
            +'</div>'
        ),
            
        preloader : $(
            '<div class="conversation-add-preloader" id="edit-category-preloader">'
            +'<span><img src="/assets/images/preloader.gif?ver=0" /><br  /><span class="add-loader-text">Saving conversation</span></span>'
            +'</div>'
        ),    
            
        init : function(id){
            var compose_message = this;
            
            if(id!==undefined){
                
                var title = 'Edit Conversation';
                
                
            }else{
                
                title = "Create New Conversation";
                
            }
            this.header.find('h1').text(title);
            
            //create tab for new message
            $('#messages-nav').tabs("add","#composeMessage",title);

            var compose_message_panel = $('#messages-nav').find("#composeMessage");

            compose_message_panel.addClass("tabbed-section");
            
            
            
            $('#conversations-panel').append(compose_message_panel);

            $('#messages-nav').tabs('select', $('#messages-nav').tabs("length")-1);
            
            compose_message_panel.append(this.header);
            
            
            compose_message_panel.append(this.content);

            compose_message_panel.append(this.footer);
            
            // set default input fields
            if(id!==undefined){
                
                $("#field-conversation-title").val(myappmaster.messages.conversation_categories[id].title);
                
            }else{
                $("#field-conversation-title").val('');
            }
            
            $('input[name="field-conversation-access"][value='+myappmaster.messages.conversation_categories[id].participantcan+']')
            .attr('checked', true);
            $('input[name="field-conversation-sharing"][value='+myappmaster.messages.conversation_categories[id].sharing+']')
            .attr('checked', true);
            
            //load participants
            myappmaster.messages.manage_communications.show_participants(id);
            
            //bind buttons
            $('#save-conversation').button({
                
                create : function(event){
                    $(this).click(function(){
                        var title = $("#field-conversation-title").val();
                        var access = $("input[name='field-conversation-access']:checked").val();
                        var sharing = $("input[name='field-conversation-sharing']:checked").val();

                        if(title==''){
                            alert('You need to add a title to create a conversation.');
                        }else{
                            $('#conversation-add-body').append(compose_message.preloader);
                            
                            //save the conversation
                            X4HCommunication.create_conversation(title, access, sharing, id);
                        }
                    });
                }
            });
            
            //if user is an admin, allow delete
            if(myappmaster.users.details.systemadmin!==undefined&&myappmaster.users.details.systemadmin=="true"){
                if($('#delete-conversation').size()==0){
                    this.footer.append($('<input type="button" id="delete-conversation" value="Delete Conversation" />'));
                }
                $('#delete-conversation').button({
                
                    create : function(event){
                        $(this).click(function(){
                            var delete_conversation = confirm("Are you sure you want to remove this category?");
                            
                            if(delete_conversation==true){
                                
                                //preloader
                                $('#conversation-add-body').append($(
                                    '<div id="preloader-delete-conversation" class="conversation-add-preloader">'
                                      +'    <span><img src="/assets/images/preloader.gif" /><br  />deleting category</span>'
                                      +'</div>'
                                ));
                                    
                                myappmaster.messages.delete_conversation(id);    
                            }
                        });
                    }
                });
                
            }
            
        }
    },
    
    company_news : {
        
        init : function(){
            console.log('loading company news');
            this.get_company_news();
        },
        get_company_news : function(){
            var filters = [{
                    name: 'conversation',
                    comparison : 'EQUAL_TO',
                    value1: 12987 //Firstfolio Corporate Conversation id
            }];
            X4HCommunication.search_conversation_posts(null, filters, null, null, this,'load_company_news',
            {rows:50, container : 'post_rows'});
        },
        
        load_company_news : function(response){
            //console.log(response);
            var company_news = this;
            var company_news_content;
            if(response.data.rows.length>0){
                var posts = response.data.rows;
                var post_rows = '';
                $.each(posts,function(key,post){
                    
                    X4HCommunication.communications_panel.current_posts[post.id]=post;
                    
                    post_rows += '<tr>'
                    +'  <td id = "news-img"><img src="/assets/images/news02.png" vspace="8px"/></td>'
                    +'  <td id = "news-title">'
                    +'      <a href="javascript:void(0);" id="corporate-news-post-'+post.id+'" class="corporate-news-post-btn">'+post.subject+'</a><br />'
                    +'      <span>'+$.datepicker.formatDate('dd-mm-yy',new Date(post.createddate))+' | From <i>'+post.conversationtext+'</i></span>'
                    +'  </td>'
                    +'</tr>';
                
                });
                
                company_news_content = $(
                    '<table>'
                    +post_rows
                    +'</table>'
                );
                
            }else{
                company_news_content = $(
                    '<table>'
                    +'  <tr>'
                    +'  <td id="no-news">There are no Company News to display.</td>'
                    +'  </tr>'
                    +'</table>'
                );
            }
            
            $('#right-news').append(company_news_content);
            //bind the post
            company_news.bind_post();
        },
        
        bind_post : function(){
            $.each($('.corporate-news-post-btn'),function(key,elem){
                
                $(elem).click(function(){
                    var post_id = myappmaster.find_id($(this).attr('id'));
                    //launch tabs
                    $('#middle-nav').tabs('select','#tab-messages');
                    
                    /* remove other tabs */
                    for(var key=$('#messages-nav').tabs('length');key!=2;key--){
                        
                        $('#messages-nav').tabs("remove",(key-1));
                        
                    }
                    
                    X4HCommunication.communications_panel.selected_post = X4HCommunication.communications_panel.current_posts[post_id];
                    X4HCommunication.communications_panel.load_post(post_id);
                    
                });
            })
        }
    },
    
    conversation_search : {
        search_category : null,
        query : null,
        query_text : null,
        filters : null,
        comparison : 'TEXT_IS_LIKE',
        
        header : $(
            '<div id="search-messages-header">'
            +'<h1>Search Results</h1>'
            +'<a id = "compose-btn3" href="#"></a>'
            +'</div>'
        ),
            
        content : '<div id="search-message-list-container" class="tabbed-content-body">'
        
        +'        </div>',
    
        title : ' <div id = "message-title">'
        +'      <div id = "message-list-info">'

        +'          <div id = "message-list-subject">'
        +'              <strong>Subject</strong>'
        +'          </div>'

        +'          <div id = "message-list-author">'
        +'              <strong>Author</strong>'
        +'          </div>'

        +'          <div id = "message-list-source">'
        +'              <strong>Category</strong>'
        +'          </div>'

        +'          <div id = "message-list-date">'
        +'               <strong>Date</strong>'
        +'          </div>'    



        +'      </div></div>',
    
        preloader : '<div class="preloader-communications-list" id="preloader-search-messages">'
            +'    <span><img src="/assets/images/preloader.gif" /><br  />loading conversations</span>'
            +'</div>',

        footer : '<div class="conversation-footer">'
        +'<div id="search-message-list-container-pagination" class="pagination-area">'
        +        '</div>',
        
        create_tab : function(){
            if($( "#messages-nav").find('a[href=#searchCommunications]').length==0){
                $('#messages-nav').tabs("add","#searchCommunications",'Search - '+this.search_category);
                
                var search_panel = $('#messages-nav').find("#searchCommunications");

                search_panel.addClass("tabbed-section");
                
                $('#conversations-panel').append(search_panel);
                
                search_panel.append(this.header);
                
                search_panel.append(this.content);
                
                $('#search-message-list-container').append(this.preloader);
                
                search_panel.append(this.footer);
                
                $('#messages-nav').tabs('select', "#searchCommunications");
                
            }else{
                $('#messages-nav').tabs('select', "#searchCommunications");
            }
            
            //Hide create button
            $('#compose-btn3').hide();
        },
        
        init : function(){
            this.create_tab();
            this.search_messages();
        },
        
        search_messages : function(){
           this.filters = [{
                   name:           this.query,
                   comparison:     this.comparison,
                   value1:         this.query_text 
           }];
           
           $('#search-message-list-container-pagination').html();
          
          
          X4HCommunication.get_conversation_posts(null,
          this,'load_communication_posts',{
          filters : this.filters,
          container : 'search-message-list-container'
          });
        },
        
        load_communication_posts : function(response){
            var conversation_id;
            
            
            
            if(response.data.rows.length>0){
              
              $('#search-message-list-container').html('');  
              
              $('#search-message-list-container').append(this.title);
              
              var posts = response.data.rows;
              
              var conversation_array = [];
              
              //loop through posts
              $.each(posts,function(key,row){
                 //conversation_id=row.conversation;
                 conversation_array.push(row.conversation);
                 
                 myappmaster.messages.communications_panel.current_posts[row.id]=row;
                 //get the post subject, category and trim
               var post_subject = (row.subject=='')?"No subject":row.subject;
               var post_category = row.conversationtext;

               //trim to 20 chars max
               if(post_subject.length>35){
                    //post_subject = post_subject.slice(0,35)+'...';
               }
               
               if(post_category.length>20){
                    post_category = post_category.slice(0,20)+'...';
               }
               
               
               
                var post_row = $(
                    '<div id = "message-list">'

                    +'    <div id = "message-list-info">'

                    +'        <div id = "message-list-subject">'
                    +'          <span class = "message-post-row post-'+row.id+'" >'
                    +'            '+post_subject
                    +'          </span>'
                    +'        </div>'

                    +'        <div id = "message-list-author">'
                    +'           '+row.createdusertext
                    +'        </div>'

                    +'        <div id = "message-list-source">'
                    +'        <span class="message-category-row" id="message-category-row-'+row.conversation+'">'
                    +post_category+'</div>'
                
                    +'        <div id = "message-list-date">'
                    +'            '+row.createddate
                    +'        </div>'    



                    +'    </div>'
                    +'</div>'
                );
                
                $('#search-message-list-container').append(post_row);
              });
              $.each($( '.message-post-row' ), function(counter, elem) {
                   $(elem).click(function() {
                       var post_id = myappmaster.find_id($(elem).attr('class'));
                       myappmaster.messages.communications_panel.selected_post = myappmaster.messages.communications_panel.current_posts[post_id];
                       myappmaster.messages.communications_panel.load_post(post_id);
                       
                   });
              });
              
              $.each($( '.message-category-row' ), function(counter, elem) {
                   $(elem).unbind('click').click(function() {
                       var conversation_id = myappmaster.find_id($(elem).attr('id'));
                       var category = $(elem).text();
                       myappmaster.messages.conversation_search.search_category = category;
                       myappmaster.messages.conversation_search.query = 'conversationtext';
                       myappmaster.messages.conversation_search.query_text = category;
                       myappmaster.messages.conversation_search.comparison = 'EQUAL_TO';
                       myappmaster.messages.conversation_search.init();
                       
                   });
              });
              
              
              if(myappmaster.messages.conversation_search.query=='conversationtext' && $.unique(conversation_array).length==1){
                  //bind compose button
                $('#compose-btn3').unbind('click').click(function(){
                    conversation_id = $.unique(conversation_array)[0];
                    myappmaster.messages.communications_panel.create_post(null,{conversation: conversation_id});
                
                });
                $('#compose-btn3').show();
              }
            }else{
                $('#search-message-list-container').html('<div>There are no posts to display.</div>');
                //hide compose
                $('#compose-btn3').hide();
            }
        }
    }
};