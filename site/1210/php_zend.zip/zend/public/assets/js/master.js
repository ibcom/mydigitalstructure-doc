﻿var myappmaster = {
    // Declarations
    users: null,
    contacts: null,
    companies: null,
    proxy: null,
    news: null,
    messages : null,//communications: null (renamed),
    email: null,
    calendar: null,
    setup: null,
    
    defaultRowCount: 20,
    pagination_targets: [],
    pagination_bindings: {},
    
    // Set the objects in this class
    add_objects: function(proxy_class, user_class, contacts_class, news_class, communications_class, email_class, calendar_class, setup_class, companies_class) {
        this.proxy = proxy_class;
        this.users = user_class;
        this.contacts = contacts_class;
        this.news = news_class;
        this.messages = communications_class;
        this.email = email_class;
        this.calendar = calendar_class;
        this.setup = setup_class;
        this.companies = companies_class;
		
        //this.companies = new X4HCompanies();
    },
    
    // Global message display/removal 
    add_message: function(message, timeout) {
       var message_entity = $('<div class="message-entity"><img src="/assets/images/alert02.png" /><span class="content">' + message + '</span></div>');
       
       //append if message is new
       var hasMessage = false;
       $.each($('.message-entity'),function(key,row){
           if($(row).find('span').text()==message){
               hasMessage = true;
           }
       })
       
       if(!hasMessage){
          $('#notification-messages').append(message_entity);  
       }
       
                    
       
       if(parseInt(timeout) > 0) {
           timeout = (timeout * 1000)
           setTimeout(
                function() {
                    message_entity.remove();
                    //check content, remove notification if empty
                    if($('.message-entity').size()==0){
                        myappmaster.close_messages();
                    }
                },
                timeout
           );
       }
       $('#notification-messages').show();
    },
    
    close_messages: function() {
        console.log("Removing the messages segment");
        // Remove children message-entities
        $('#notification-messages').hide();
    },
    
    // Opens up the dashboard (including required loading)
    init_dashboard: function(x4h_user) {
        // Show the main content
        $('.not-logged-in').hide();
        $('.logged-in').show();        
        
        // Bind the logout button (img currently)
        $( '#spanInterfaceMasterLogoff').click(function(){
            x4hubProxy.logout();
        });
		
        // Bind the toggler
        $('.content-toggler').click(function(event){
            event.preventDefault();
            // Get the id of whatever is clicked            
            var tmp = $(this).attr('id').split('-');
            if(tmp.length == 2) {
                var container = 'content-' + tmp[1];
                //console.log("Switching to " + container);
                if(tmp[1] == 'setup')
                {
                        //If Admin was clicked
                        X4HSetup.create_setup_div();
                }
                $( '.content-display' ).hide();
                $('#' + container).show();
            }
        });
        
        // Add the datepicker
        $('.datepicker').datepicker({
            dateFormat: 'dd/mm/yy'
        });
	
        // Load in our content
        this.show_loading_screen();

        //Load calendar widget
        //will also initialize scheduled events to optimize call
        this.calendar.widget.init();
        
        //Load corporate upcoming events
        
        this.calendar.corporate_events.init();
        
        this.users.init(x4h_user);
        
        //Load company news
        this.messages.company_news.init();
        
        //Load advance search
        X4HASearchWidget.init();
        
		//** LOAD BIRTHDAY MODULE **
        
		/*
		var dToday = new Date();
		var dStart = dToday;
		//Find the current Monday
		//Check if the current day is greater then 1
		if(dToday.getDay() > 1)
		{
			var current_day = dToday.getDay()-1;
			//Count Backwards to get the current monday
			dToday.setTime(dToday.getTime() - current_day * 24 * 60 * 60 * 1000);
			var dStart = dToday;
		}
		else
		{
			if(dToday.getDay() == 1)
			{
				//Today is Monday and current
				var dStart = dToday;
			}
			else
			{
				//Count one forwards
				dToday.setTime(dToday.getTime() + 24 * 60 * 60 * 1000);	
				var dStart = dToday;	
			}
		}
		
		var dEnd = new Date();
		dEnd.setTime(dStart.getTime() + 6 * 24 * 60 * 60 * 1000);
			
		this.contacts.find_birthdays(dStart, dEnd, 'tabs-Bday-Thisweek');
		$( "#fspot-bday-tabs" ).tabs({
			select : function(event, ui){
				var tmp = ui.tab.hash;
				$(tmp).html('<div id="birthday-events-preloader" class="day-container">'
							+'<span>Loading Birthdays  <img src="/assets/images/preloader2.gif"></span>'
							+'</div>');
				if(tmp == '#tabs-Bday-Thisweek')
				{
					myappmaster.contacts.find_birthdays(dStart, dEnd, 'tabs-Bday-Thisweek');
				}
				else
				{
					var dWeekStart = new Date(dStart.getTime() + 7 * 24 * 60 * 60 * 1000);
					var dWeekEnd = new Date(dEnd.getTime() + 7 * 24 * 60 * 60 * 1000);
					myappmaster.contacts.find_birthdays(dWeekStart, dWeekEnd, 'tabs-Bday-Nextweek');
				}
			}
		});
		*/
		
		
		//** LOAD TO DO MODULE **
		/*myappmaster.calendar.load_todo();
		myappmaster.calendar.bind_todo_links();*/
				
		//** LOAD CONTACTS MODULE **
		/*$( "#left-sidebar-contact-tabs" ).tabs();
		$( "#left-sidebar-todo-tabs" ).tabs({
			select : function(event, ui){
				myappmaster.calendar.load_todo();
			}
		});*/
		
		/*
        this.news.init();
        this.email.init();
        this.calendars.init();
        this.contacts.init();
        */
        
        //this.companies.init();
        //this.communications.load_conversations();
		    
		//this.news.recent_activity();
        //this.setup.user_list();
        
        $('#notification-close').click(function(){
            myappmaster.close_messages();
            return false;
        });
		this.hide_loading_screen();
        
        //X4HContacts.manage_business(null, 'Firstfolio Clone', 'support@firstfolio.com.au', '651612241');
        //X4HContacts.manage_business(null, 'Firstfolio Clone2', '2support@firstfolio.com.au', '651612241');
        //X4HContacts.manage_business(null, 'Firstfolio Clone3', '3support@firstfolio.com.au', '651612241');
        //X4HContacts.manage_business(null, 'Firstfolio Clone4', '4support@firstfolio.com.au', '651612241');
        //X4HContacts.manage_business(null, 'Firstfolio Clone5', '5support@firstfolio.com.au', '651612241');
        
        
        /*
        X4HContacts.manage_person(null, 'asfsafasf', '24afasf', 'email@asfasf.com');
        X4HContacts.manage_person(null, 'asfsafasf', '24afasf', 'email@asfasf.com');
        X4HContacts.manage_person(null, 'asfsafasf', '24afasf', 'email@asfasf.com');
        X4HContacts.manage_person(null, 'asfsafasf', '24afasf', 'email@asfasf.com');
        */
       
       
       
       // Message testing
       /*
       this.add_message("HEELLO STRANGER 1");
       this.add_message("HEELLO STRANGER 2", 10);
       this.add_message("HEELLO STRANGER 3");
       this.add_message("HEELLO STRANGER 4", 20);
       */
       
    },
    // Shows the login screen
    init_login: function() {
        $('.logged-in').hide();
		$('.preloader').hide();
		$('.preloader-login').hide();
       // $('.not-logged-in').show();
	   	$('.not-logged-in').dialog('open');
        $( '#spanInterfaceMasterLogon').click(function(){
			$('.preloader-login').show();
            x4hubProxy.login($( '#inputInterfaceMasterLogonName').val(), $( '#inputInterfaceMasterLogonPassword').val());
        });
		//Bind Enter to login
		$('#inputInterfaceMasterLogonPassword').keypress(function(e) {
        if(e.which == 13) {
			$(this).blur();
            $('#spanInterfaceMasterLogon').focus().click();
        }
    });
    },
    
    // Open up a loading screen
    show_loading_screen: function() {
        //console.log("Spawning loading screen");
		$('.loading-myapp').dialog('open');
		//$('.preloader').show();
    },
    // Close loading screen
    hide_loading_screen: function() {
        //console.log("Despawning loading screen");
		$('.preloader').hide();
    },
    find_id: function(str) {
        var tmp = str.split('-');
        var count = tmp.length;
        if(count > 0) {
            return tmp[count - 1];
        }
        return 0;
    },
    html_decode: function(str) {
        
        //console.log('Pre: ' + str);
        str = str.replace(/&amp;/g, '&');
        str = str.replace(/&lt;/g, '<');
        str = str.replace(/&gt;/g, '>');
        str = str.replace(/&nbsp;/g, ' ');
        //console.log('Post: ' + str);
        return str;
    },
    validate_date: function(date) {
        if ( Object.prototype.toString.call(date) !== "[object Date]" )
            return false;
        return !isNaN(date.getTime());
    },
    generate_pagination_links: function(callback_container, callback_object, callback_function, callback_uri, callback_params, rows, start_row, total_rows) {
        
        /** added to extend pagination */
        if(typeof(callback_container)=='object'&&callback_container!==null){
            if(callback_container.container!==undefined){
                var callback_function_params = callback_container;
                callback_container = callback_container.container;
                
            }
        }else{
            callback_function_params = callback_container;
        }
                
                
        if($('#' + callback_container + '-pagination').length == 0) {
            //console.log("Pagination container doesnt exist for " + callback_container);
            return false;
        }

        var pagination_container = $('#' + callback_container + '-pagination');
        
        // Work out how many pages there are
        var page_count = ( rows + start_row == total_rows ? 1 : Math.ceil(total_rows / rows) );                       
        var row_count = callback_params.rows;
        var current_page = (start_row / row_count) + 1;
        //
        // Set the limits
        var first_page = (current_page - page_count < 1 ? 1 : current_page - page_count);
        var last_page = (current_page + page_count < page_count ? current_page + page_count : page_count);


        if(pagination_container.children('.pagination-link').length > 0) {
            return false;
        }
        pagination_container.append($('<div class="pagination-link pagination-first">First</div>'));
        pagination_container.append($('<div class="pagination-link pagination-prev"><</div>'));
        
        myappmaster.pagination_bindings[callback_container] = {
            container: pagination_container,
            callback: [callback_object, callback_function, callback_function_params],
            uri: callback_uri,
            params: callback_params,
            total: total_rows,
            page: current_page
        };
        
        
        for(var i = first_page; i <= last_page; i++) {
            var pagination_link = $('<div id="' + callback_container + '-page-' + i + '" class="pagination-link' + (current_page == i ? ' current-page' : '') + '">' + i + '</div>');
            pagination_container.append(pagination_link);
        }
        
        pagination_container.append($('<div class="pagination-link pagination-next">></div>'));
        pagination_container.append($('<div class="pagination-link pagination-last">Last</div>'));
        
        
        // Add a binding to all of this sets elements
        pagination_container.children('.pagination-link').click(function() {
            // Conditionals for fist/last/back/forward
            //var current_page = parseInt( myappmaster.pagination_bindings[callback_container].params.startrow / myappmaster.pagination_bindings[callback_container].total) + 1;
            var current_page = myappmaster.pagination_bindings[callback_container].page;
            var page_count = Math.ceil(myappmaster.pagination_bindings[callback_container].total / myappmaster.pagination_bindings[callback_container].params.rows);
            // Remove whatever had it in this list
            myappmaster.pagination_bindings[callback_container].container.children('.pagination-link').removeClass('current-page');
            $(this).addClass('current-page');

            var page = 1;
            if($(this).hasClass('pagination-first')) {
                page = 1;
            } else if($(this).hasClass('pagination-prev')) {
                page = (page == current_page ? 1 : (current_page - 1) );
            } else if($(this).hasClass('pagination-next')) {
                //page = (current_page + 1);
                // Added fix where pagination gets an error when pagination limit has reached
                page = (current_page == last_page ? last_page : (parseInt(current_page) + 1));
                
            } else if($(this).hasClass('pagination-last')) {
                page = page_count;
            } else {
                page = myappmaster.find_id( $(this).attr('id') );
            }
            
            myappmaster.pagination_bindings[callback_container].page =  page;
            myappmaster.pagination_bindings[callback_container].params.startrow = parseInt( (page * row_count) - row_count);
            x4hubProxy.call(
                myappmaster.pagination_bindings[callback_container].callback,
                myappmaster.pagination_bindings[callback_container].uri,
                myappmaster.pagination_bindings[callback_container].params
            );
        });
        
        return true;
    }
}

myappmaster.add_objects(x4hubProxy, X4HUser, X4HContacts, X4HNews, X4HCommunication, X4HEmail, X4HCalendar, X4HSetup, X4HCompanies);

//Ajax queue for multiple calls
var ajaxQueue = $({});

$.ajaxQueue = function(ajaxOpts) {
// hold the original complete function
var oldComplete = ajaxOpts.complete;

// queue our ajax request
ajaxQueue.queue(function(next) {

  // create a complete callback to fire the next event in the queue
  ajaxOpts.complete = function() {
    // fire the original complete if it was there
    if (oldComplete) oldComplete.apply(this, arguments);

    next(); // run the next query in the queue
  };

  // run the query
  $.ajax(ajaxOpts);
});
};

$.extend($.expr[':'], {
  'containsi': function(elem, i, match, array)
  {
    return (elem.textContent || elem.innerText || '').toLowerCase()
    .indexOf((match[3] || "").toLowerCase()) >= 0;
  }
});


