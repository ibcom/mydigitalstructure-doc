/* 
 * Handler for polled events
 * Email, Conversations and Calendar events
 * Requirements:
 * jquery.topzindex.min.js
 * jquery.topzindex.js
 * jquery.timers.js
 */

var pollHandler = {
    /* Set variables */
    
    /* update flag */
    check_for_updates : true,
             
    
    /* check for updates every 1 minute */
    update_duration : '60s',
    
    /* popup will display for 5mins (300s) */
    popup_duration  :   '300s',
    
    /* max number of rows for notification items */
    max_items : 2,
    
    time_notification: function(opopup){
        $(document).everyTime('1s',function(i){
                if(i==pollHandler.popup_duration){
                    pollHandler.hide_notification_popup(opopup);
                }
  
            },this.popup_duration);
    },
    
    hide_notification_popup : function(opopup){
        opopup.hide('slide',{direction: "down"},1000,function(){
            opopup.html('');
        });
        
        
        pollHandler.is_popup_visible = false;
    },
    
    popup_theme : {
        /* popup skin */
        'width':'350px',
        'height':'60px',
        'background':'#0D3558',
        'border-left':'1px solid #AAA',
        'border-top':'1px solid #AAA',
        'border-radius':'5px 0px 0px 0px',
        'position' :'fixed',
        'bottom':0,
        'right':0
    },
    
    /* popup item css */
    popup_item_theme : {
        'float'     :   'left',
        'width'     :   '100%',
        'margin'    :   '10px 0 0 10px',
        'color'     :   '#fff',
        'font-size' :   '12px' 
    },
    
    tracked_items : {
      'mail' : {
          'tracked_events' : {
            //new mail  
            'newmail' : function(){
                var newcount = 0;
                
                var tracked = false;
                
                strTemplate = null;
                
                if(!tracked){
                    return null;
                }
                /*check for new mail
                 * /ondemand/messaging/?method=MESSAGING_EMAIL_ACCOUNT_SEARCH
                 *
                 */
                
                /* For testing */
                var uri = 'tester.php/?method=MESSAGING_EMAIL_ACCOUNT_SEARCH';
                
                $.ajax({
                    url: uri,
                    type: 'get',
                    dataType: 'json',
                    async: false,
                    success: function(data) {
                        if(data == null || data == '') {
                            //this.error_handler();
                            //newcount = 0;
                        } else {
                            newcount = data.newcount;
                        }
                    }
                });
                
                
                if(newcount>0){
                    strTemplate = 'You have '+newcount+' new mail'+(newcount>1?'s':'')+'.';
                }

                return strTemplate;
            }
          }
      },
      'messages' : {
          'tracked_events' : {
              //new posts
              'newpost' : function(){
                var newpostcount = 0;
                strTemplate = null;
                var tracked = false;
                
                if(!tracked){
                    return null;
                }
                
                 /*check for new posts
                 * /ondemand/messaging/?method=MESSAGING_CONVERSATION_SUMMARY_SEARCH
                 *
                 */
                
                /* For testing */
                var uri = 'tester.php/?method=MESSAGING_CONVERSATION_SUMMARY_SEARCH';
                
                $.ajax({
                    url: uri,
                    type: 'get',
                    dataType: 'json',
                    async: false,
                    success: function(data) {
                        if(data == null || data == '') {
                            //this.error_handler();
                            //newcount = 0;
                        } else {
                            newpostcount = data.newpostcount;
                        }
                    }
                });
                
                if(newpostcount>0){
                    strTemplate = 'You have '+newpostcount+' new message'+(newpostcount>1?'s':'')+'.';
                }

                return strTemplate;
                
              },
              //new comment
              'newcomment' : function(){
                strTemplate = null;
                var newcommentcount = 0;
                var tracked = false;
                
                if(!tracked){
                    return null;
                }
                 /*check for new comments
                 * /ondemand/messaging/?method=MESSAGING_CONVERSATION_SUMMARY_SEARCH
                 *
                 */
                
                /* For testing */
                var uri = 'tester.php/?method=MESSAGING_CONVERSATION_SUMMARY_SEARCH';
                
                $.ajax({
                    url: uri,
                    type: 'get',
                    dataType: 'json',
                    async: false,
                    success: function(data) {
                        if(data == null || data == '') {
                            //this.error_handler();
                            //newcount = 0;
                        } else {
                            newcommentcount = data.newcommentcount;
                        }
                    }
                });
                
                if(newcommentcount>0){
                    strTemplate = 'There '+(newcommentcount>1?'are':'is')+' '+newcommentcount+' new comment'+(newcommentcount>1?'s':'')+' to your post.';
                }

                return strTemplate;
                
              }
          }
      },
      'calendar' : {
          calendar_events : null,
          
          new_events : 0,
          
          get_calendar_events_response : function(response){
              /* populate events */
              var calendar_events = pollHandler.tracked_items.calendar.calendar_events;
              
              if(calendar_events == null){
                  if(response.data.rows.length > 0) {
                     
                     pollHandler.tracked_items.calendar.calendar_events = response.data.rows;
                     
                     $.each(response.data.rows, function(key, row) {
                        if(row.status==2){
                            pollHandler.tracked_items.calendar.new_events+=1;
                        }
                     });
                     
                  }
              }else{
                   // reset new events
                   pollHandler.tracked_items.calendar.new_events = 0;
                   if(response.data.rows.length > 0) {
                       $.each(response.data.rows, function(key, row) {
                           var found = false;
                           $.each(calendar_events,function(ce_key,ce_row){
                               if(row.event==ce_row.event){
                                   found = true;
                                   if(ce_row.status!=2&&row.status==2){
                                       pollHandler.tracked_items.calendar.new_events+=1;
                                       
                                   }
                                   pollHandler.tracked_items.calendar.calendar_events[ce_key] = row;
                               }
                           });
                           if(!found){
                               //pollHandler.tracked_items.calendar.new_events+=1;
                               if(row.status==2){
                                    pollHandler.tracked_items.calendar.new_events+=1;
                                    pollHandler.tracked_items.calendar.calendar_events.push(row);
                               }
                           }
                       });
                   }
              }
          },
          
          'tracked_events' : {
              'newevent' : function(){
                  var newevent = 0;
                  strTemplate = null;
                  
                  var tracked = false;
                
                  if(!tracked){
                    return null;
                  }
                  
                  //console.log('step1')
                  pollHandler.proxy.call(
                    [pollHandler.tracked_items.calendar,'get_calendar_events_response'],
                    '/ondemand/event/?method=EVENT_ATTENDEE_SEARCH',
                    {
                        me : 1
                    }
                  );
                      
                  newevent = pollHandler.tracked_items.calendar.new_events;
                  
                  if(newevent>0){
                    strTemplate = 'You have been invited to '+newevent+' new event'+(newevent>1?'s':'')+'.';
                  }
                  
                  return strTemplate;
              },
              'event_changes': function(){
                  var eventchanges = 0;
                  strTemplate = null;
                  var newcommentcount = 0;
                  var tracked = false;
                  
                  if(!tracked){
                    return null;
                  }
                  
                  /* For testing */
                    var uri = 'tester.php/?method=EVENT_ATTENDEE_SEARCH';

                    $.ajax({
                        url: uri,
                        type: 'get',
                        dataType: 'json',
                        async: false,
                        success: function(data) {
                            if(data == null || data == '') {
                                //this.error_handler();
                                //newcount = 0;
                            } else {
                                eventchanges = data.eventchanges;
                            }
                        }
                    });
                  
                  
                  if(eventchanges>0){
                    strTemplate = eventchanges+' event'+(eventchanges>1?'s have':' has')+' changed.';
                  }
                  
                  return strTemplate;
              }
          }
      }
    },
    
    
    /* element that will be added with notification */
    target_element  :   null,
    
    /* objects containing updates */
    updates :  [],
    
    is_popup_visible : false,
    
    
    /* initialize handler */
    init : function(options){
        this.target_element = options.target_element;
        this.notify();
    },
    
    /* main notification handler */
    notify : function(){

       /* check for updates */
       var latest_updates = this.get_updates();
       
       if(latest_updates.length>0){
           $.each(latest_updates,function(key,update){
               pollHandler.updates.push(update);
           });
       }
       
       /*if updates are available, show notification*/
       if(this.updates.length>0){
           this.show_popup(this.target_element,this.updates);
       }
        
        
        
       $(this).oneTime(this.update_duration,function(){
           this.notify();
       });
       
       
    },
    
    get_updates : function(){
        oUpdates = this.tracked_items;
        aNotifications = [];
        $.each(oUpdates,function(key,update_item){
            $.each(update_item.tracked_events,function(eKey,tEvent){
                atEvent = tEvent();
                if(atEvent!==null){
                   aNotifications.push(atEvent);
                }
            });
        });
        
       return aNotifications;
    },
    
    set_popup_contents : function(notifications){
        aNotificationHtml = [];
        $.each(notifications,function(key,notification){
            aNotificationHtml.push('<div>'+notification+'</div>');
        });
        return aNotificationHtml;
    },
    
    show_popup : function(target_element,notifications){
       
        opopup = $(target_element).find('#notification-popup');
        if((opopup.length>0)==false){
            
            opopup = $('<div id="notification-popup" style="display:none"></div>');
            $(target_element).append(opopup);
            
            /* apply this for targetted elements */
            /* opopup.position({
            my: "right bottom",
            at: "right bottom",
            of: target_element
            }); */
            
            /* set to highest z-index */
            opopup.topZIndex();
            opopup.css(pollHandler.popup_theme);
            
            
        }
        
        aNotifications = this.set_popup_contents(notifications);
        
        if(this.is_popup_visible==false){
            
            $.each(aNotifications,function(key,notification){
                
                if(key<pollHandler.max_items){
                    opopup.prepend(notification);
                    
                }
                
            });
            
            
            
            
            /* remove displayed notifications */
            this.updates.splice(0,this.max_items);
            
            if(!opopup.is(":visible")){
                this.is_popup_visible = true;
                
                opopup.show('slide',{direction: "down"},1000,function(){
                    /* time the notification based on given duration */
                    opopup.oneTime(pollHandler.popup_duration,function(){
                        pollHandler.hide_notification_popup(opopup);
                    });
                });
                
            }
            
            
        }else{
            
            /* animate new notifications */
            $.each(aNotifications,function(key,notification){
                if(key<pollHandler.max_items){
                    opopup.oneTime(key*1000,function(){
                        opopup.queue(function(){
                            opopup.prepend($(notification).hide().fadeIn(1000));
                            opopup.dequeue();
                            var popup_item = opopup.find('div');
                            popup_item.css(pollHandler.popup_item_theme);
            
                        });
                        
                    });
                    
                }
                
            });
            
            
            /* remove displayed notifications */
            this.updates.splice(0,this.max_items);
            
           
        }
            
        var popup_item = opopup.find('div');
        popup_item.css(pollHandler.popup_item_theme);
           
       
    },
    /* copy of x4hubProxy to handle ajax async requests */
    proxy : {
        call : function(callback, uri, params) {        

            var callback_object = x4hubProxy;
            var callback_function = callback;
            var callback_container = null;

            if(params == null) {
                params = {};
            }

            if( $.isArray(callback) ) {                
                callback_object = callback[0];
                callback_function = callback[1];
                if(callback.length == 3 ) {
                    callback_container = callback[2];
                }
            } else {
                x4hubProxy.error_handler();
                return false;
            }
                
        
            // Add data to array if they don't exist
            if(params != null && params instanceof Object) {
                params.target = x4hubProxy.site_url + uri;
                params.ff_one_id = x4hubProxy.ff_one_id;
                params.sid = x4hubProxy.sid;
            }
        
        
        //x4hubProxy.start_loading();
        
            $.ajax({
                url: x4hubProxy.proxy_host,
                data : params,
                type: 'get',
                dataType: 'json',
                async: true,
                success: function(data) {
                    if(data == null || data == '') {
                        x4hubProxy.error_handler();
                    } else {
                        callback_object[callback_function](data, callback_container);

                    }
                }
            });
        } 
    }
    
    
}
