Backbone.emulateHTTP = true;
Backbone.emulateJSON = true;
window.MyApp = {
	Views: {},
    Routers: {},
    Models: {},
    proxy: null,
    initialize: function() {
    	this.proxy = new mydd_proxy();
    	this.proxy.check_cookie();
    },
    init_application: function() {	
		// Define application wide collections
    	MyApp.Models.contactPeople = new MyApp.Models.ContactPersonCollection();
    	MyApp.Models.contactBusinesses = new MyApp.Models.ContactBusinessesCollection();
    	
    	// Initialise routers
        new MyApp.Routers.Application();
        new MyApp.Routers.Contacts();
        Backbone.history.start();
        
        // Load in children
    	// Begin early loading of models
		MyApp.Models.contactPeople.rowLimit = 1000;
		MyApp.Models.contactPeople.X4HSearch(
			MyApp.Models.contactPeople.field_list,
			null, 
			null,
			[{name:'surname', direction:'asc'}, {name:'firstname', direction:'asc'}]
		);
		
		MyApp.Models.contactBusinesses.rowLimit = 1000;
		MyApp.Models.contactBusinesses.X4HSearch(
			MyApp.Models.contactBusinesses.field_list,
			null,
			null,
			[{name:'tradename', direction:'asc'}]
		);
    },
    init_login: function() {
    	// Handle all login loading
    }
}
