MyApp.Models.ContactGroup = X4HModel.extend({
	field_list: [],
	
	url: function() {
		var url =  MyApp.proxy.buildUrl('/ondemand/contact/?method=CONTACT_PERSON_MANAGE');
		return url;
	},
	
	methodToUrl: {
		'read'		: '/ondemand/contact/?method=CONTACT_PERSON_SEARCH',
		'create'	: '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
		'update'	: '/ondemand/contact/?method=CONTACT_PERSON_MANAGE',
		'delete'	: '/ondemand/contact/?method=CONTACT_PERSON_MANAGE'
	}
});

MyApp.Models.ContactPersonCollection = X4HCollection.extend({
	field_list: [],
	model: MyApp.Models.ContactGroup,
	url: function() {
		var url =  MyApp.proxy.buildUrl('/ondemand/contact/?method=CONTACT_PERSON_SEARCH');
		return url;
	}
});