MyApp.Views.ApplicationWindow = Backbone.View.extend({
    events: {
        /*"click button.prev" : "pagePrevious",
        "click button.next" : "pageNext",*/
    },
    initialize: function() {
		console.log("Application Window");
		
		// Load in the profile data/view
    },
    render: function() {
    	return this;
    }		
});
