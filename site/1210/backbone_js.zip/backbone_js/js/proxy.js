function mydd_proxy() {
    this.site_id = 1320;
	this.site_url = 'https://myapp.1blankspace.com';
    this.proxy_host = 'http://myapp/proxy/';
    this.myapp_one_id = 1;
    this.sid = 0;
    this.user = 0;
	
	this.save_cookie = function(sid, user) {
        $.cookie('mds_sid', sid);
        $.cookie('mds_user', user);
        
        this.sid = sid;
        this.user = user;
    }
    
    
    this.check_cookie = function(myapp_user_id) {     
        proxy = this;
        this.myapp_one_id = myapp_user_id;
        this.sid = $.cookie('mds_sid');
        this.user = $.cookie('mds_user');
        
        var uri = 'http://MyApp.1blankspace.com/ondemand/core/?method=CORE_GET_USER_DETAILS';
        $.getJSON(
            this.proxy_host,
            {
                target: uri,
                myapp_one_id: this.myapp_one_id,
                sid: this.sid
            }
        )
        .success(function(response) {
            if(response == null || response == '') {
                this.error_handler();
            } else {
                if(response.status != 'OK' || response.notes != 'RETURNED') {
                	// SHow the login Screen
                	MyApp.init_login();
                } else {
                	console.log('Logged in: Initializing App');
                    MyApp.init_application();
                }
            }
        })
        .error(function(response) {
        	// Error - can happen at times with a login attempt with expired cookie not handled properly
        	// Show the login screen
	    	// SHow the login Screen
	    	MyApp.init_login();
        });
        
    }
    
    this.login = function(username, password) {
        $('#interfaceMasterLogonStatus').html("");
        if(username == '' || username == null) {
			console.log('Please enter a username');
            return false;
        }
        
        if(password == '' || password == null) {
        	console.log('Please enter a password');
            return false;
        }
        
        
        x4hub = this;
        $.getJSON(
            this.proxy_host + '?target=http://MyApp.1blankspace.com/ondemand/logon/',
            {
                logon: username, 
                password: password,
                myapp_one_id: this.myapp_one_id
            },
            function(data) {
                if( data.status == 'ER' ) {
                    // We have an error taking effecttime 
                    var errorMessage = '';
                    switch(data.error.errornotes) {
                        case 'LOGONFAILED': {
                            errorMessage = 'Invalid username and/or password';
                            break;
                        }
                        default: {
                            errorMessage = "Error: " + data.error.errornotes;
                            break;
                        }
                    }
                    console.log(errorMessage);
                } else if( data.status = 'OK' ) {
                    if(data.passwordStatus == 'OK') {
                        // Log the user in
                        x4hub.save_cookie(data.sid, data.user)
                        MyApp.init_application();
                    }
                }
            }
        );
    }
    
    this.buildUrl = function(target_url) {
    	return this.proxy_host + '?target=' + this.site_url + target_url + '&sid=' + this.sid + '&site=' + this.site_id;
    }
}
