MyApp.Routers.Contacts = Backbone.Router.extend({
	initialize: function() {
		//var contact_window = new MyApp.Views.Contacts({el: $('#contacts')}).render();
		if(typeof MyApp.Views.contacts === 'undefined') {
			MyApp.Views.contacts = new MyApp.Views.Contacts({el: $('#contents')});
		}		
	},
    routes: {
    	"contacts"					: "index",
    	"contacts/people"			: "people",
    	"contacts/groups"			: "groups",
    	"contacts/businesses"		: "businesses"
    },

    index: function() {
    	this.people();
    },
    
    people: function() {
    	MyApp.Views.contacts.render();
    	console.log('rendering the people');
    	new MyApp.Views.ContactPeople({el: $('#content-contacts')}).render();
    },
    
    groups: function() {
    	MyApp.Views.contacts.render();
    },
    
    businesses: function() {
    	MyApp.Views.contacts.render();
    	new MyApp.Views.ContactBusinesses({el: $('#content-contacts')}).render();
    }
});