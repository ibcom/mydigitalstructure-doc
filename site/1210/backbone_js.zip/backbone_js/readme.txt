﻿This is a pretty cut down version to demonstrate how to basically wrap the js interface around a standard backbone.js model (with CRUID standard calls)



The models/x4model.js has a basic structure that can be used to build up objects (including some provisos for pagination: We were toying with the idea of loading 1000 objects at a time and allowing pagination to be lighting fast over a few pages and then loading the next 1000 etc so you always got a few pages worth of data in a single load.

Just a note on this: Memory management is a battle with this strategy and would suit sub < 1000 items at a time for best usage.



Notes:


Initialising: Json2.js and underscore.js need to be loaded before backbone.js


application.js defines the namespace that is used for the backbone app.


<script src="/assets/js/json2.js"></script>
<script src="/assets/js/underscore.js"></script>
<script src="/assets/js/backbone.js"></script>

<script>
$(function() {FFOne.initialize();});

</script>


 