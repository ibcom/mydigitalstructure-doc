﻿(function () {
    'use strict';
    WinJS.Application.onactivated = function (e) {
        if (e.detail.kind === Windows.ApplicationModel.Activation.ActivationKind.launch) {
            var LoginURL = 'https://secure.mydigitalspacelive.com/ondemand/logon/?logon=';
            var DivLoginBox = document.getElementById("LoginBox");
            var DivContent = document.getElementById("content");
            var ButtonS = document.getElementById("LoginSubminButton");
            var ResultBox = document.getElementById("res");
            var DivlistContactGroups = document.getElementById("listContactGroups");
            var DivcotentTableRightList = document.getElementById("cotentTableRightList");
            var listContactGroupsURL = 'https://secure.mydigitalspacelive.com/ondemand/setup/?method=SETUP_CONTACT_PERSON_GROUP_SEARCH&rf=JSON';
            var loadListContentURL = 'https://secure.mydigitalspacelive.com/ondemand/contact/?method=CONTACT_PERSON_SEARCH&rf=JSON';
            var editContentURL = 'https://secure.mydigitalspacelive.com/ondemand/contact/?method=CONTACT_PERSON_MANAGE&rf=JSON';
            contactStart();
            // testing@ondemand
        }
        /* start */
        function contactStart() {
            if (!get_cookie("usersid")) {
                contactLoginForm();
            } else {
                contactContentLoad();
            }
        }
        /* contact first page */
        function contactContentLoad() {
            ResultBox.innerHTML = '';
            DivLoginBox.className = 'box';
            ResultBox.className = 'box';
            DivContent.className = 'box show';
            var sidUser = get_cookie('usersid');
            var url1 = listContactGroupsURL + '&sid=' + sidUser;
            $('#DivCotentTableRight').height(($('body').height()) - (200));
            $('#header').append('<input type="submit" id="addNewButton" value="Add New Contact" class="box" />')
            $('#addNewButton').click(function () { addNewContact(); });
            WinJS.xhr({ url: url1 }).then(function (r) {
                var result = r.responseText;
                var obj = JSON.parse(result)
                var aaa = obj.data.rows;
                var lh = '<select id="SelectlistContactGroups" size="10"><option value="all">All</option>';
                for (var i = 0; i < aaa.length; i++) {
                    lh += '<option value="' + aaa[i].id + '">' + aaa[i].title + '</option>';
                }
                lh += '</select>';
                DivlistContactGroups.innerHTML = lh;
                document.getElementById("SelectlistContactGroups").addEventListener("change", function () {
                    var groupID = document.getElementById("SelectlistContactGroups").value;
                    loadListContent(groupID);
                });
            });
        }
        /**/
        function loadListContent(groupID) {
            var sidUser = get_cookie('usersid');

            $('#addNewButton').hide();
            DivcotentTableRightList.innerHTML = ('<tr><td colspan="5">loading...</td></tr>');

            var url2 = loadListContentURL + '&sid=' + sidUser;
            if (groupID == 'all') {
                var option = {
                    url: url2,
                    type: "POST"
                }

                WinJS.xhr(option).then(function (r) {
                    var result = r.responseText;
                    var obj = JSON.parse(result)
                    var aaa = obj.data.rows;
                    var lh = '';
                    for (var i = 0; i < aaa.length; i++) {
                        lh += '<tr id="contactLine_' + aaa[i].id + '"><td class="td_f_name">' + aaa[i].firstname + '</td><td class="td_s_name">' + aaa[i].surname + '</td><td class="td_email">' + aaa[i].email + '</td><td class="td_phone">' + aaa[i].workphone /*+ '<br>' + aaa[i].mobile*/ + '</td><td><button class="contactEditButton" value="' + aaa[i].id + '">Edit</button> <button class="contactDeleteButton" value="' + aaa[i].id + '">Delete</button></td></tr>';
                    }
                    lh += '';
                    DivcotentTableRightList.innerHTML = lh;
                    $('#addNewButton').show();
                    $(".contactDeleteButton").click(function () {
                        deleteContact($(this).val());
                        $('#contactLine_' + $(this).val()).addClass('active');
                    })
                    $(".contactEditButton").click(function () {
                        editContact($(this).val());
                        $('#contactLine_' + $(this).val()).addClass('active');
                    })

                });

            } else {
                var sData = "<advancedSearch><field><name>firstname</name></field><field><name>surname</name></field><field><name>email</name></field><field><name>workphone</name></field>" + 
				            "<filter><name>persongroup</name><comparison>EQUAL_TO</comparison><value1>" + groupID + "</value1><value2></value2><value3></value3></filter>" + 
				            "<sort><name>surname</name><direction>asc</direction></sort><options><rf>JSON</rf><startrow>0</startrow><rows>20</rows><returnparameters></returnparameters></options></advancedSearch>";
				$.ajax(
                {
                    url: url2 + '&advanced=1',
                    type: "POST",
                    data: sData,
                    dataType: 'json',
                    success: ShowGroupList
                });

            }
        }

        function ShowGroupList(r) {
            var aaa = r.data.rows;
            var lh = '';
            for (var i = 0; i < aaa.length; i++) {
                lh += '<tr id="contactLine_' + aaa[i].id + '"><td class="td_f_name">' + aaa[i].firstname + '</td><td class="td_s_name">' + aaa[i].surname + '</td><td class="td_email">' + aaa[i].email + '</td><td class="td_phone">' + aaa[i].workphone /*+ '<br>' + aaa[i].mobile*/ + '</td><td><button class="contactEditButton" value="' + aaa[i].id + '">Edit</button> <button class="contactDeleteButton" value="' + aaa[i].id + '">Delete</button></td></tr>';
            }
            lh += '';
            DivcotentTableRightList.innerHTML = lh;
            $('#addNewButton').show();
            $(".contactDeleteButton").click(function () {
                deleteContact($(this).val());
                $('#contactLine_' + $(this).val()).addClass('active');
            })
            $(".contactEditButton").click(function () {
                editContact($(this).val());
                $('#contactLine_' + $(this).val()).addClass('active');
            })
        }

        /* delete contact */
        function deleteContact(obgID) {
            $("body").append('<div id="deletePopUp" class="DivPopUpBox"><div class="bg"><div class="content center"><p>Do You Wish To Delete This Contact?</p><p><input type="submit" value="Delete" id="deletePopUp_Yes" />  <input type="reset" value="Cansel" id="deletePopUp_No" /></p></div></div></div>');
            $("#deletePopUp_No").click(function () {
                $("#deletePopUp").remove();
                $('#contactLine_' + obgID).removeClass('active');
            })
            $("#deletePopUp_Yes").click(function () {
                var sidUser = get_cookie('usersid');
                var data = new FormData();
                var url = editContentURL + '&sid=' + sidUser + '&remove=1&id=' + obgID;
                data.append('id', obgID);
                data.append('remove', 1);
                var option = {
                    url: url,
                    type: "POST" /*,
                    data: data*/
                }
                WinJS.xhr(option).then(function (r) {
                    var result = r.responseText;
                    var obj = JSON.parse(result)
                    if (obj.status == "OK") {
                        $('#contactLine_' + obgID).remove();
                        $('#deletePopUp').remove();
                        $('#contactLine_' + obgID).removeClass('active');
                    } else {
                        errorContactEdit(obgID);
                    }
                })
                
            })
        }
        /* error PopUp */
        function errorContactEdit(obgID) {
            $('.DivPopUpBox .content').addClass('error').html('<h2>ERROR</h2><p><input type="reset" value="Cansel" id="errorPopUp_No" /></p>');
            $("#errorPopUp_No").click(function () {
                $(".DivPopUpBox").remove();
                $('#contactLine_' + obgID).removeClass('active');
            })
        }
        /* edit contact */
        function editContact(obgID) {
            var phoneNum = $('#contactLine_' + obgID + ' .td_phone').text();
            var oldEmail = $('#contactLine_' + obgID + ' .td_email').text();
            var oldSname = $('#contactLine_' + obgID + ' .td_s_name').text();
            var oldName = $('#contactLine_' + obgID + ' .td_f_name').text();
            $("body").append('<div id="addNewPopUp" class="DivPopUpBox"><div class="bg"><div class="content center"><h3>Add New contact</h3><table><tr><td class="left">FIRST NAME</td><td class="left">SURNAME</td><td class="left">EMAIL</td><td class="left">PHONE</td></tr><tr><td class="left"><input type="text" id="addNewFirstName" value="'+ oldName +'" /></td><td class="left"><input type="text" id="addNewSurname" value="'+ oldSname +'" /></td><td class="left"><input type="text" id="addNewEmail" value="'+ oldEmail +'" /></td><td class="left"><input type="text" id="addNewPhone" value="'+ phoneNum +'" /></td></tr></table><p><input type="submit" value="Save" id="addNewPopUp_Yes" />  <input type="reset" value="Cansel" id="addNewPopUp_No" /></p></div></div></div>');
            $("#addNewPopUp_No").click(function () {
                $('#contactLine_' + obgID).removeClass('active');
                $(".DivPopUpBox").remove();
            })
            $("#addNewPopUp_Yes").click(function () {
                var sidUser = get_cookie('usersid');
                var data = new FormData();
                var url = editContentURL + '&sid=' + sidUser + '&id=' + obgID + '&FirstName=' + $('#addNewFirstName').val() + '&Surname=' + $('#addNewSurname').val() + '&Email=' + $('#addNewEmail').val() + '&WorkPhone=' + $('#addNewPhone').val();
                var option = {
                    url: url,
                    type: "POST"/*,
                    data: data*/
                }
                WinJS.xhr(option).then(function (r) {
                    var result = r.responseText;
                    var obj = JSON.parse(result)
                    if (obj.status == "OK") {
                        $('#contactLine_' + obgID + ' .td_f_name').html( $('#addNewFirstName').val());
                        $('#contactLine_' + obgID + ' .td_s_name').html($('#addNewSurname').val());
                        $('#contactLine_' + obgID + ' .td_email').html($('#addNewEmail').val());
                        $('#contactLine_' + obgID + ' .td_phone').html($('#addNewPhone').val());
                        $(".DivPopUpBox").remove();
                        $('#contactLine_' + obgID).removeClass('active');
                    } else {
                        errorContactEdit(obgID);
                    }
                })
            })
        }
        /* add New Contact */
        function addNewContact() {
            $("body").append('<div id="addNewPopUp" class="DivPopUpBox"><div class="bg"><div class="content center"><h3>Add New contact</h3><table><tr><td class="left">FIRST NAME</td><td class="left">SURNAME</td><td class="left">EMAIL</td><td class="left">PHONE</td></tr><tr><td class="left"><input type="text" id="addNewFirstName" /></td><td class="left"><input type="text" id="addNewSurname" /></td><td class="left"><input type="text" id="addNewEmail" /></td><td class="left"><input type="text" id="addNewPhone" /></td></tr></table><p><input type="submit" value="Save" id="addNewPopUp_Yes" />  <input type="reset" value="Cansel" id="addNewPopUp_No" /></p></div></div></div>');
            $("#addNewPopUp_No").click(function () {
                $(".DivPopUpBox").remove();
            })
            $("#addNewPopUp_Yes").click(function () {
                var sidUser = get_cookie('usersid');
                var data = new FormData();
                var url = editContentURL + '&sid=' + sidUser + '&FirstName=' + $('#addNewFirstName').val() + '&Surname=' + $('#addNewSurname').val() + '&Email=' + $('#addNewEmail').val() + '&WorkPhone=' + $('#addNewPhone').val();
                var option = {
                    url: url,
                    type: "POST"/*,
                    data: data*/
                }
                WinJS.xhr(option).then(function (r) {
                    var result = r.responseText;
                    var obj = JSON.parse(result)
                    if (obj.status == "OK") {
                        $('#cotentTableRightList').prepend('<tr id="contactLine_' + obj.id + '"><td class="td_f_name">' + $('#addNewFirstName').val() + '</td><td class="td_s_name">' + $('#addNewSurname').val() + '</td><td class="td_email">' + $('#addNewEmail').val() + '</td><td class="td_phone">' + $('#addNewPhone').val() + '</td><td><button class="contactEditButton" value="' + obj.id + '">Edit</button> <button class="contactDeleteButton" value="' + obj.id + '">Delete</button></td></tr>');
                        $(".DivPopUpBox").remove();                        
                    } else {
                        errorContactEdit(obgID);
                    }
                })
            })
        }
        /* login form */
        function contactLoginForm() {
            DivLoginBox.className = 'box show';
            ResultBox.className = 'box';
            ButtonS.addEventListener("click", function () {
                var LogNam = document.getElementById("inputLoginName").value;
                var usPas = document.getElementById("userPassword").value;
                var url = LoginURL + LogNam + '&password=' + usPas;
                ResultBox.className = 'box show';
                ResultBox.innerHTML = 'loading...';
                WinJS.xhr({ url: url }).then(function (r) {
                    var result = r.responseText;
                    var obj = JSON.parse(result)
                    if (obj.status == "OK" && obj.passwordStatus == "OK") {
                        set_cookie("usersid", obj.sid);
                        contactContentLoad();
                    } else {
                        ResultBox.innerHTML = '<span class="error">Login Name or Password is incorrect</span>';
                    }
                });
            });
        }
        /* cookie */
        function get_cookie(cookie_name) {
            var results = document.cookie.match('(^|;) ?' + cookie_name + '=([^;]*)(;|$)'); if (results) { return (unescape(results[2])); } else { return null; }
        }
        function delete_cookie(cookie_name) {
            var cookie_date = new Date (); cookie_date.setTime(cookie_date.getTime() - 1); document.cookie = cookie_name += "=; expires=" + cookie_date.toGMTString();
        }
        function set_cookie(name, value, exp_y, exp_m, exp_d, path, secure) {
            var cookie_string = name + "=" + escape(value); if (exp_y) { var expires = new Date (exp_y, exp_m, exp_d); cookie_string += "; expires=" + expires.toGMTString(); } if (path)  { cookie_string += "; path=" + escape(path); } if (secure) { cookie_string += "; secure"; } document.cookie = cookie_string;
        }
        
    }
    WinJS.Application.start();
})();

